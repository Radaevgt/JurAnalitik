# Скрипт для перезапуска всех сервисов
docker-compose restart