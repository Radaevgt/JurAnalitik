# Скрипт для просмотра логов всех сервисов
docker-compose logs -f