# Скрипт для запуска всех сервисов
docker-compose up -d