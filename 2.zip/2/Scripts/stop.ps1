# Скрипт для остановки всех сервисов
docker-compose down