import os
import re
import json
import time
from flask import Flask, render_template, request, redirect, url_for, jsonify, Response, session
from dotenv import load_dotenv
from PyPDF2 import PdfReader
from docx import Document
import io
import threading
import secrets

# Загрузка переменных окружения из .env файла
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', secrets.token_hex(32))

# Инициализация модуля аутентификации и базы данных
from auth import auth_bp, get_current_user, get_current_user_data, get_user_id_by_session, is_user_authenticated
from database import AppDatabase

app.register_blueprint(auth_bp)

# Инициализация базы данных
app_db = AppDatabase()

# Хранилище для отслеживания прогресса (остается в памяти - это нормально для временных данных)
progress_storage = {}

@app.route('/')
def index():
    """Главная страница - теперь с дашбордом если пользователь авторизован"""
    current_user = get_current_user()
    
    if current_user:
        # Получаем статистику пользователя
        user_stats = app_db.get_user_stats(current_user)
        
        # Получаем последние документы
        user_data = get_current_user_data()
        if user_data:
            recent_documents = app_db.documents.get_user_documents(user_data['id'], limit=5)
        else:
            recent_documents = []
        
        return render_template('dashboard.html', 
                             current_user=current_user,
                             user_stats=user_stats,
                             recent_documents=recent_documents)
    else:
        return render_template('index.html', current_user=None)

@app.route('/documents')
def documents_list():
    """Список всех документов пользователя"""
    if not is_user_authenticated():
        return redirect(url_for('auth.login'))
    
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('auth.login'))
    
    # Получаем все документы пользователя
    documents = app_db.documents.get_user_documents(user_data['id'])
    
    return render_template('documents_list.html', 
                         current_user=get_current_user(),
                         documents=documents)

@app.route('/document/<int:document_id>')
def view_document(document_id):
    """Просмотр конкретного документа и его анализов"""
    if not is_user_authenticated():
        return redirect(url_for('auth.login'))
    
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('auth.login'))
    
    # Получаем документ с проверкой владельца
    document = app_db.documents.get_document_by_id(document_id, user_data['id'])
    if not document:
        return "Документ не найден", 404
    
    # Получаем все анализы этого документа
    analyses = app_db.analyses.get_document_analyses(document_id)
    
    # Группируем анализы по типам для удобства отображения
    analyses_by_type = {}
    for analysis in analyses:
        analysis_type = analysis['analysis_type']
        if analysis_type not in analyses_by_type:
            analyses_by_type[analysis_type] = []
        analyses_by_type[analysis_type].append(analysis)
    
    return render_template('document_view.html',
                         current_user=get_current_user(),
                         document=document,
                         analyses=analyses,
                         analyses_by_type=analyses_by_type)

@app.route('/document/<int:document_id>/delete', methods=['POST'])
def delete_document(document_id):
    """Удаление документа"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    user_data = get_current_user_data()
    if not user_data:
        return jsonify({"error": "Пользователь не найден"}), 401
    
    success = app_db.documents.delete_document(document_id, user_data['id'])
    
    if success:
        return jsonify({"success": True, "message": "Документ удален"})
    else:
        return jsonify({"error": "Не удалось удалить документ"}), 400

# ==========================================
# НОВЫЕ ЭНДПОИНТЫ ДЛЯ АНАЛИЗА
# ==========================================

@app.route('/document/<int:document_id>/analyze/<analysis_type>', methods=['POST'])
def analyze_document_by_type(document_id, analysis_type):
    """Запуск конкретного типа анализа для документа"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    user_data = get_current_user_data()
    if not user_data:
        return jsonify({"error": "Пользователь не найден"}), 401
    
    # Проверяем что документ принадлежит пользователю
    document = app_db.documents.get_document_by_id(document_id, user_data['id'])
    if not document:
        return jsonify({"error": "Документ не найден"}), 404
    
    # Проверяем валидность типа анализа
    valid_types = ['risk', 'business', 'compliance', 'terminology', 'structural']
    if analysis_type not in valid_types:
        return jsonify({"error": f"Неподдерживаемый тип анализа: {analysis_type}"}), 400
    
    try:
        # Создаем уникальный ID для отслеживания прогресса
        import uuid
        task_id = str(uuid.uuid4())
        
        # Инициализируем прогресс
        progress_storage[task_id] = {
            "step": 1,
            "percentage": 10,
            "message": f"Начинаем {analysis_type} анализ...",
            "status": "processing"
        }
        
        print(f"🔍 Запускаем {analysis_type} анализ документа {document['original_filename']}")
        
        # Обновляем прогресс
        update_progress(task_id, 2, 30, f"Подготовка к {analysis_type} анализу...")
        
        # Выполняем анализ
        start_time = time.time()
        report = process_document_with_type(document['full_content'], analysis_type, task_id)
        processing_time = time.time() - start_time
        
        # Сохраняем результаты анализа в БД
        update_progress(task_id, 3, 90, "Сохранение результатов...")
        analysis_id = app_db.analyses.save_analysis(
            document_id=document_id,
            analysis_type=f"{analysis_type}_analysis",
            results_data={
                'report_text': report,
                'task_id': task_id,
                'analysis_type': analysis_type
            },
            ai_provider='deepseek',
            processing_time=processing_time
        )
        
        # Завершаем прогресс
        update_progress(task_id, 4, 100, f"{analysis_type.title()} анализ завершен!", "completed")
        
        print(f"✅ {analysis_type} анализ завершен успешно")
        
        return jsonify({
            "success": True,
            "task_id": task_id,
            "analysis_id": analysis_id,
            "analysis_type": analysis_type,
            "report": report
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        
        # Обновляем прогресс с ошибкой
        if task_id in progress_storage:
            progress_storage[task_id] = {
                "step": 0,
                "percentage": 0,
                "message": f"Ошибка {analysis_type} анализа: {str(e)}",
                "status": "error"
            }
        
        return jsonify({"error": f"Ошибка {analysis_type} анализа: {str(e)}"}), 500

@app.route('/document/<int:document_id>/compare/<int:document_id2>', methods=['POST'])
def compare_documents(document_id, document_id2):
    """Сравнительный анализ двух документов"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    user_data = get_current_user_data()
    if not user_data:
        return jsonify({"error": "Пользователь не найден"}), 401
    
    # Проверяем что оба документа принадлежат пользователю
    doc1 = app_db.documents.get_document_by_id(document_id, user_data['id'])
    doc2 = app_db.documents.get_document_by_id(document_id2, user_data['id'])
    
    if not doc1 or not doc2:
        return jsonify({"error": "Один или оба документа не найдены"}), 404
    
    try:
        # Создаем уникальный ID для отслеживания прогресса
        import uuid
        task_id = str(uuid.uuid4())
        
        # Инициализируем прогресс
        progress_storage[task_id] = {
            "step": 1,
            "percentage": 10,
            "message": "Начинаем сравнительный анализ...",
            "status": "processing"
        }
        
        print(f"📊 Сравниваем документы {doc1['original_filename']} и {doc2['original_filename']}")
        
        # Обновляем прогресс
        update_progress(task_id, 2, 50, "Выполняем сравнительный анализ...")
        
        # Выполняем сравнение через AI
        start_time = time.time()
        report = ai_provider.compare_documents(doc1['full_content'], doc2['full_content'])
        processing_time = time.time() - start_time
        
        # Сохраняем результат для первого документа
        update_progress(task_id, 3, 90, "Сохранение результатов...")
        analysis_id = app_db.analyses.save_analysis(
            document_id=document_id,
            analysis_type='comparison_analysis',
            results_data={
                'report_text': report,
                'task_id': task_id,
                'compared_with_document_id': document_id2,
                'compared_with_filename': doc2['original_filename']
            },
            ai_provider='deepseek',
            processing_time=processing_time
        )
        
        # Завершаем прогресс
        update_progress(task_id, 4, 100, "Сравнительный анализ завершен!", "completed")
        
        return jsonify({
            "success": True,
            "task_id": task_id,
            "analysis_id": analysis_id,
            "report": report
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Ошибка сравнительного анализа: {str(e)}"}), 500

@app.route('/upload', methods=['POST'])
def upload_file():
    """Обработка загрузки файлов с сохранением в БД"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    user_data = get_current_user_data()
    if not user_data:
        return jsonify({"error": "Пользователь не найден"}), 401
    
    if 'file' not in request.files:
        return jsonify({"error": "Файл не найден в запросе"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Не выбран файл"}), 400
    
    # Проверка формата файла
    if not re.search(r'\.(pdf|docx|txt)$', file.filename, re.IGNORECASE):
        return jsonify({"error": "Неподдерживаемый формат файла. Используйте PDF, DOCX или TXT"}), 400
    
    # Создаем уникальный ID для отслеживания прогресса
    import uuid
    task_id = str(uuid.uuid4())
    
    try:
        # Инициализируем прогресс
        progress_storage[task_id] = {
            "step": 1,
            "percentage": 0,
            "message": "Загрузка файла...",
            "status": "processing"
        }
        
        print(f"📁 Обрабатываем файл: {file.filename} (Task ID: {task_id})")
        
        # Обновляем прогресс: загрузка завершена
        update_progress(task_id, 1, 25, "Извлечение текста из документа...")
        
        # Извлечение текста из файла
        file_content = extract_text_from_file(file, task_id)
        file_size = len(file.read())
        file.seek(0)  # Возвращаем указатель в начало
        
        # Сохраняем документ в БД
        update_progress(task_id, 2, 40, "Сохранение документа в базу данных...")
        document_id = app_db.documents.save_document(
            user_id=user_data['id'],
            filename=f"{task_id}_{file.filename}",  # Уникальное имя файла
            original_filename=file.filename,
            content=file_content,
            file_size=file_size
        )
        
        if not document_id:
            raise Exception("Не удалось сохранить документ в базу данных")
        
        # Обновляем прогресс: базовый анализ
        update_progress(task_id, 2, 50, "Выполняем базовый анализ рисков...")
        
        # Выполняем базовый анализ рисков
        start_time = time.time()
        report = process_document_with_type(file_content, 'risk', task_id)
        processing_time = time.time() - start_time
        
        # Сохраняем результаты анализа в БД
        update_progress(task_id, 3, 90, "Сохранение результатов анализа...")
        analysis_id = app_db.analyses.save_analysis(
            document_id=document_id,
            analysis_type='risk_analysis',
            results_data={
                'report_text': report,
                'task_id': task_id,
                'file_size': file_size,
                'original_filename': file.filename
            },
            ai_provider='deepseek',
            processing_time=processing_time
        )
        
        # Обновляем прогресс: анализ завершен
        update_progress(task_id, 4, 100, "Анализ завершен!", "completed")
        
        print("✅ Файл успешно обработан и сохранен в БД")
        
        return jsonify({
            "filename": file.filename,
            "report": report,
            "task_id": task_id,
            "document_id": document_id,
            "analysis_id": analysis_id
        })
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        # Обновляем прогресс с ошибкой
        if task_id in progress_storage:
            progress_storage[task_id] = {
                "step": 0,
                "percentage": 0,
                "message": f"Ошибка: {str(e)}",
                "status": "error"
            }
        return jsonify({"error": f"Ошибка обработки файла: {str(e)}"}), 500

@app.route('/progress/<task_id>')
def get_progress(task_id):
    """Получение текущего прогресса обработки"""
    def generate():
        while task_id in progress_storage:
            progress = progress_storage[task_id]
            yield f"data: {json.dumps(progress)}\n\n"
            
            # Если обработка завершена или произошла ошибка, завершаем поток
            if progress.get("status") in ["completed", "error"]:
                # Удаляем из хранилища через некоторое время
                def cleanup():
                    time.sleep(30)  # Ждем 30 секунд
                    if task_id in progress_storage:
                        del progress_storage[task_id]
                
                threading.Thread(target=cleanup).start()
                break
            
            time.sleep(0.5)  # Обновляем каждые 500мс
    
    return Response(generate(), mimetype='text/event-stream')

def update_progress(task_id, step, percentage, message, status="processing"):
    """Обновление прогресса обработки"""
    if task_id in progress_storage:
        progress_storage[task_id] = {
            "step": step,
            "percentage": percentage,
            "message": message,
            "status": status
        }
        print(f"📊 Прогресс [{task_id}]: Шаг {step}, {percentage}% - {message}")

def extract_text_from_file(file, task_id):
    """Извлечение текста из файлов PDF, DOCX и TXT"""
    filename = file.filename.lower()
    file_bytes = file.read()
    
    print(f"📄 Извлекаем текст из {filename}")
    
    if filename.endswith('.pdf'):
        reader = PdfReader(io.BytesIO(file_bytes))
        text = ""
        total_pages = len(reader.pages)
        
        for page_num, page in enumerate(reader.pages, 1):
            page_text = page.extract_text()
            text += page_text
            
            # Обновляем прогресс извлечения текста
            progress = 25 + (page_num / total_pages) * 15  # 25-40%
            update_progress(task_id, 2, progress, f"Обработка страницы {page_num} из {total_pages}...")
            
            print(f"📖 Обработана страница {page_num}/{total_pages}, символов: {len(page_text)}")
        
        print(f"📚 PDF обработан: {total_pages} страниц, {len(text)} символов")
        return text
    
    elif filename.endswith('.docx'):
        doc = Document(io.BytesIO(file_bytes))
        paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
        text = "\n".join(paragraphs)
        print(f"📝 DOCX обработан: {len(paragraphs)} абзацев, {len(text)} символов")
        return text
    
    else:  # TXT файл
        text = file_bytes.decode('utf-8')
        print(f"📃 TXT обработан: {len(text)} символов")
        return text

# Импортируем расширенный провайдер
from providers import EnhancedDeepSeekProvider

# Инициализация расширенного DeepSeek провайдера
print("🚀 Запуск ЮрАналитик с расширенным DeepSeek...")
ai_provider = EnhancedDeepSeekProvider()

def process_document_with_type(content, analysis_type, task_id):
    """Обработка документа с выбранным типом анализа"""
    try:
        print(f"📄 Начинаем {analysis_type} анализ документа ({len(content):,} символов)")
        
        # Обновляем прогресс: начинаем ИИ-анализ
        analysis_names = {
            'risk': 'анализ рисков',
            'business': 'бизнес-анализ',
            'compliance': 'комплаенс-анализ', 
            'terminology': 'терминологический анализ',
            'structural': 'структурный анализ'
        }
        
        analysis_name = analysis_names.get(analysis_type, 'анализ')
        update_progress(task_id, 3, 50, f"Выполняем {analysis_name}...")
        
        # Проверяем размер документа
        if len(content) > 50000:
            print("⚠️ Документ очень большой, обрезаем до 50000 символов")
            content = content[:50000] + "\n\n[Документ обрезан для анализа]"
            update_progress(task_id, 3, 55, f"Документ обрезан, продолжаем {analysis_name}...")
        
        # Симулируем прогресс ИИ-анализа
        update_progress(task_id, 3, 60, f"DeepSeek выполняет {analysis_name}...")
        
        # Выполняем анализ с выбранным типом
        result = ai_provider.analyze_document(content, analysis_type)
        
        # Анализ завершен
        update_progress(task_id, 3, 90, f"Формируем отчет {analysis_name}...")
        
        print(f"🎉 {analysis_name.title()} завершен")
        return result
        
    except Exception as e:
        print(f"❌ Ошибка {analysis_type} анализа: {str(e)}")
        update_progress(task_id, 0, 0, f"Ошибка {analysis_type} анализа: {str(e)}", "error")
        
        # Возвращаем отчет об ошибке
        return f"""# ❌ Ошибка {analysis_type} анализа

## Техническая проблема
Не удалось выполнить {analysis_type} анализ документа.

**Ошибка:** {str(e)}

## 📊 Базовая информация
**Размер документа:** {len(content):,} символов
**Количество слов:** {len(content.split()):,}
**Тип анализа:** {analysis_type}

## 🔧 Рекомендации
1. Проверьте настройки DeepSeek API
2. Убедитесь что баланс положительный
3. Попробуйте повторить через несколько минут

---
*Обратитесь к разработчику если проблема повторяется*"""

# ==========================================
# API ENDPOINTS
# ==========================================

@app.route('/api/user/stats')
def api_user_stats():
    """API для получения статистики пользователя"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    current_user = get_current_user()
    stats = app_db.get_user_stats(current_user)
    return jsonify(stats)

@app.route('/api/documents')
def api_documents():
    """API для получения списка документов"""
    if not is_user_authenticated():
        return jsonify({"error": "Требуется авторизация"}), 401
    
    user_data = get_current_user_data()
    if not user_data:
        return jsonify({"error": "Пользователь не найден"}), 401
    
    documents = app_db.documents.get_user_documents(user_data['id'])
    return jsonify({"documents": documents})

@app.route('/api/analysis-types')
def api_analysis_types():
    """API для получения доступных типов анализа"""
    types = [
        {
            "id": "risk",
            "name": "Анализ рисков",
            "description": "Выявление юридических и финансовых рисков",
            "icon": "🔍"
        },
        {
            "id": "business", 
            "name": "Бизнес-анализ",
            "description": "Анализ финансовых условий и коммерческих аспектов",
            "icon": "💰"
        },
        {
            "id": "compliance",
            "name": "Комплаенс-анализ", 
            "description": "Проверка соответствия законодательству РФ",
            "icon": "⚖️"
        },
        {
            "id": "terminology",
            "name": "Терминологический анализ",
            "description": "Анализ терминов и определений",
            "icon": "📖"
        },
        {
            "id": "structural",
            "name": "Структурный анализ",
            "description": "Проверка структуры и полноты документа",
            "icon": "🏗️"
        }
    ]
    return jsonify({"analysis_types": types})

if __name__ == '__main__':
    print("=" * 50)
    print("🌟 ЮрАналитик - Анализ документов с ИИ")
    print("🤖 Провайдер: Enhanced DeepSeek API")
    print("📁 Поддержка: PDF, DOCX, TXT файлы")
    print("📊 Функции: 5 типов анализа + сравнение")
    print("🔒 Авторизация: Добавлена")
    print("💾 База данных: SQLite")
    print("=" * 50)
    
    # Проверяем наличие API ключа при запуске
    if os.getenv('DEEPSEEK_API_KEY'):
        print("✅ DeepSeek API ключ найден")
    else:
        print("⚠️ DeepSeek API ключ НЕ найден в .env файле")
        print("💡 Добавьте: DEEPSEEK_API_KEY=sk-ваш_ключ")
    
    print("🌐 Запускаем веб-сервер с расширенным анализом...")
    app.run(debug=True)
