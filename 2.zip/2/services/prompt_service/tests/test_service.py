import pytest
from datetime import datetime
from typing import Dict, Any

from ..src.service import PromptService, InMemoryPromptCache
from ..src.prompts.risk_analysis import RiskAnalysisPrompt
from ..src.prompts.business_analysis import BusinessAnalysisPrompt

@pytest.fixture
def cache() -> InMemoryPromptCache:
    """Фикстура для кэша"""
    return InMemoryPromptCache()

@pytest.fixture
def service(cache: InMemoryPromptCache) -> PromptService:
    """Фикстура для сервиса промптов"""
    service = PromptService(cache=cache)
    
    # Добавляем тестовые промпты
    risk_prompt = RiskAnalysisPrompt()
    business_prompt = BusinessAnalysisPrompt()
    
    service.add_prompt(risk_prompt)
    service.add_prompt(business_prompt)
    
    return service

def test_list_prompts(service: PromptService):
    """Тест получения списка промптов"""
    prompts = service.list_prompts()
    assert len(prompts) == 2
    assert "risk_analysis" in prompts
    assert "business_analysis" in prompts

def test_get_prompt(service: PromptService):
    """Тест получения промпта по имени"""
    prompt = service.get_prompt("risk_analysis")
    assert prompt.name == "risk_analysis"
    assert prompt.description == "Анализ рисков в юридических документах"

def test_get_nonexistent_prompt(service: PromptService):
    """Тест получения несуществующего промпта"""
    with pytest.raises(KeyError):
        service.get_prompt("nonexistent")

def test_format_prompt(service: PromptService):
    """Тест форматирования промпта"""
    params = {
        "document": "Тестовый документ",
        "document_type": "Договор",
        "jurisdiction": "РФ"
    }
    
    result = service.format_prompt("risk_analysis", **params)
    assert "Тестовый документ" in result
    assert "Финансовые риски" in result
    assert "Юридические риски" in result

def test_prompt_versioning(service: PromptService):
    """Тест версионирования промптов"""
    prompt = service.get_prompt("risk_analysis")
    
    # Проверяем версии
    versions = prompt.list_versions()
    assert "1.0.0" in versions
    assert "1.1.0" in versions
    
    # Проверяем текущую версию
    assert prompt.current_version.version == "1.1.0"
    
    # Проверяем получение конкретной версии
    v1 = prompt.get_version("1.0.0")
    assert v1 is not None
    assert v1.version == "1.0.0"

def test_prompt_caching(service: PromptService, cache: InMemoryPromptCache):
    """Тест кэширования промптов"""
    params = {
        "document": "Тестовый документ",
        "document_type": "Договор",
        "jurisdiction": "РФ"
    }
    
    # Первый запрос - результат кэшируется
    result1 = service.format_prompt("risk_analysis", **params)
    
    # Проверяем наличие в кэше
    cache_key = f"risk_analysis:{str(params)}"
    cached = cache.get(cache_key)
    assert cached == result1
    
    # Второй запрос - берется из кэша
    result2 = service.format_prompt("risk_analysis", **params)
    assert result2 == result1

def test_add_duplicate_prompt(service: PromptService):
    """Тест добавления дубликата промпта"""
    prompt = RiskAnalysisPrompt()
    with pytest.raises(ValueError):
        service.add_prompt(prompt)

def test_remove_prompt(service: PromptService):
    """Тест удаления промпта"""
    service.remove_prompt("risk_analysis")
    assert "risk_analysis" not in service.list_prompts()
    
    with pytest.raises(KeyError):
        service.get_prompt("risk_analysis")