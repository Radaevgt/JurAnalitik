import pytest
from unittest.mock import Mock
from src.prompts.base import BasePrompt

class TestPrompt(BasePrompt):
    """Тестовый класс промпта для проверки базового класса"""
    def __init__(self):
        super().__init__("test_prompt")
        self.template = "Analyze this {text} with {parameter}"
    
    def validate_parameters(self, parameters: dict) -> bool:
        return "text" in parameters and "parameter" in parameters

@pytest.fixture
def prompt():
    return TestPrompt()

def test_prompt_initialization(prompt):
    assert prompt.name == "test_prompt"
    assert prompt.template == "Analyze this {text} with {parameter}"
    assert hasattr(prompt, "validate_parameters")

def test_process_prompt_success(prompt):
    # Подготовка
    parameters = {
        "text": "sample text",
        "parameter": "test parameter"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert result == "Analyze this sample text with test parameter"

def test_process_prompt_missing_parameter(prompt):
    # Подготовка
    parameters = {
        "text": "sample text"
        # Отсутствует parameter
    }
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        prompt.process(parameters)
    assert "Invalid parameters" in str(exc_info.value)

def test_process_prompt_invalid_parameter_type(prompt):
    # Подготовка
    parameters = {
        "text": 123,  # Должен быть строкой
        "parameter": "test"
    }
    
    # Проверка
    with pytest.raises(TypeError) as exc_info:
        prompt.process(parameters)
    assert "Parameter must be string" in str(exc_info.value)

def test_prompt_metadata(prompt):
    # Выполнение
    metadata = prompt.get_metadata()
    
    # Проверка
    assert metadata["name"] == "test_prompt"
    assert "template" in metadata
    assert "required_parameters" in metadata
    assert "version" in metadata

def test_prompt_validation_hook(prompt):
    # Подготовка
    validation_hook = Mock(return_value=True)
    prompt.add_validation_hook(validation_hook)
    parameters = {
        "text": "sample",
        "parameter": "test"
    }
    
    # Выполнение
    prompt.process(parameters)
    
    # Проверка
    validation_hook.assert_called_once_with(parameters)

def test_prompt_processing_hook(prompt):
    # Подготовка
    processing_hook = Mock(return_value="Modified result")
    prompt.add_processing_hook(processing_hook)
    parameters = {
        "text": "sample",
        "parameter": "test"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert result == "Modified result"
    processing_hook.assert_called_once()

def test_prompt_template_validation():
    # Подготовка
    class InvalidPrompt(BasePrompt):
        def __init__(self):
            super().__init__("invalid")
            self.template = "Invalid template {missing}"
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        InvalidPrompt()
    assert "Invalid template" in str(exc_info.value)

def test_prompt_parameter_extraction(prompt):
    # Выполнение
    params = prompt.get_required_parameters()
    
    # Проверка
    assert "text" in params
    assert "parameter" in params
    assert len(params) == 2

def test_prompt_version_control(prompt):
    # Подготовка
    new_template = "New template {text} with {parameter}"
    
    # Выполнение
    prompt.update_template(new_template)
    
    # Проверка
    assert prompt.template == new_template
    assert prompt.version > 1.0  # Версия должна увеличиться

def test_prompt_history(prompt):
    # Подготовка
    parameters = {
        "text": "test",
        "parameter": "value"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    history = prompt.get_processing_history()
    
    # Проверка
    assert len(history) == 1
    assert history[0]["parameters"] == parameters
    assert history[0]["result"] == result