import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
from src.api import app
from src.service import PromptService

@pytest.fixture
def mock_service():
    return Mock(spec=PromptService)

@pytest.fixture
def client(mock_service):
    app.dependency_overrides[PromptService] = lambda: mock_service
    return TestClient(app)

def test_health_check(client):
    # Выполнение
    response = client.get("/v1/health")
    
    # Проверка
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_get_prompts(client, mock_service):
    # Подготовка
    mock_service.get_all_prompts.return_value = {
        "risk_analysis": {"name": "risk_analysis", "version": "1.0"},
        "business_analysis": {"name": "business_analysis", "version": "1.0"}
    }
    
    # Выполнение
    response = client.get("/v1/prompts")
    
    # Проверка
    assert response.status_code == 200
    prompts = response.json()["prompts"]
    assert len(prompts) == 2
    assert prompts["risk_analysis"]["name"] == "risk_analysis"
    assert prompts["business_analysis"]["name"] == "business_analysis"

def test_get_prompt_info(client, mock_service):
    # Подготовка
    mock_service.get_prompt_metadata.return_value = {
        "name": "risk_analysis",
        "version": "1.0",
        "template": "Template text",
        "parameters": ["text", "context"]
    }
    
    # Выполнение
    response = client.get("/v1/prompts/risk_analysis")
    
    # Проверка
    assert response.status_code == 200
    info = response.json()
    assert info["name"] == "risk_analysis"
    assert info["version"] == "1.0"
    assert "template" in info
    assert "parameters" in info

def test_get_nonexistent_prompt(client, mock_service):
    # Подготовка
    mock_service.get_prompt_metadata.side_effect = ValueError("Prompt not found")
    
    # Выполнение
    response = client.get("/v1/prompts/nonexistent")
    
    # Проверка
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()

def test_process_prompt_success(client, mock_service):
    # Подготовка
    mock_service.process_prompt.return_value = "Processed result"
    request_data = {
        "parameters": {
            "text": "Sample text",
            "context": "Test context"
        }
    }
    
    # Выполнение
    response = client.post("/v1/prompts/risk_analysis/process", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    assert response.json()["result"] == "Processed result"
    mock_service.process_prompt.assert_called_once_with(
        "risk_analysis",
        request_data["parameters"]
    )

def test_process_prompt_validation_error(client, mock_service):
    # Подготовка
    mock_service.validate_prompt_parameters.return_value = False
    request_data = {
        "parameters": {
            "invalid": "data"
        }
    }
    
    # Выполнение
    response = client.post("/v1/prompts/risk_analysis/process", json=request_data)
    
    # Проверка
    assert response.status_code == 422
    assert "validation" in response.json()["detail"].lower()

def test_process_prompt_error(client, mock_service):
    # Подготовка
    mock_service.process_prompt.side_effect = Exception("Processing error")
    request_data = {
        "parameters": {
            "text": "Sample text"
        }
    }
    
    # Выполнение
    response = client.post("/v1/prompts/risk_analysis/process", json=request_data)
    
    # Проверка
    assert response.status_code == 500
    assert "error" in response.json()["detail"].lower()

def test_bulk_process_prompts(client, mock_service):
    # Подготовка
    mock_service.bulk_process_prompts.return_value = [
        "Result 1",
        "Result 2"
    ]
    request_data = {
        "requests": [
            {
                "prompt": "risk_analysis",
                "parameters": {"text": "Text 1"}
            },
            {
                "prompt": "business_analysis",
                "parameters": {"text": "Text 2"}
            }
        ]
    }
    
    # Выполнение
    response = client.post("/v1/prompts/bulk-process", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    results = response.json()["results"]
    assert len(results) == 2
    assert results[0] == "Result 1"
    assert results[1] == "Result 2"
    mock_service.bulk_process_prompts.assert_called_once_with(
        request_data["requests"]
    )

def test_unauthorized_access(client):
    # Выполнение без токена авторизации
    response = client.post("/v1/prompts/risk_analysis/process", json={})
    
    # Проверка
    assert response.status_code == 401
    assert "unauthorized" in response.json()["detail"].lower()

def test_metrics(client):
    # Выполнение
    response = client.get("/v1/metrics")
    
    # Проверка
    assert response.status_code == 200
    metrics = response.json()
    assert "requests_total" in metrics
    assert "processing_time_avg" in metrics
    assert "errors_total" in metrics