import pytest
from unittest.mock import Mock
from src.prompts.risk_analysis import RiskAnalysisPrompt

@pytest.fixture
def prompt():
    return RiskAnalysisPrompt()

def test_prompt_initialization(prompt):
    assert prompt.name == "risk_analysis"
    assert "legal risks" in prompt.template.lower()
    assert prompt.is_initialized()

def test_validate_parameters_success(prompt):
    # Подготовка
    parameters = {
        "text": "Sample contract text",
        "context": "Commercial agreement",
        "risk_types": ["legal", "financial"],
        "language": "ru"
    }
    
    # Проверка
    assert prompt.validate_parameters(parameters) is True

def test_validate_parameters_missing_required(prompt):
    # Подготовка
    parameters = {
        "context": "Commercial agreement",  # Отсутствует обязательный параметр text
        "risk_types": ["legal"]
    }
    
    # Проверка
    assert prompt.validate_parameters(parameters) is False

def test_validate_parameters_invalid_risk_types(prompt):
    # Подготовка
    parameters = {
        "text": "Sample text",
        "risk_types": ["invalid_type"]  # Неподдерживаемый тип риска
    }
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        prompt.process(parameters)
    assert "Invalid risk type" in str(exc_info.value)

def test_process_prompt_with_all_risk_types(prompt):
    # Подготовка
    parameters = {
        "text": "Sample contract",
        "risk_types": ["legal", "financial", "operational"],
        "language": "ru"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert "legal" in result.lower()
    assert "financial" in result.lower()
    assert "operational" in result.lower()
    assert parameters["text"] in result

def test_process_prompt_with_context(prompt):
    # Подготовка
    parameters = {
        "text": "Sample contract",
        "context": "This is a software development agreement",
        "risk_types": ["legal"],
        "language": "ru"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert "software development" in result.lower()
    assert parameters["text"] in result

def test_prompt_language_handling(prompt):
    # Подготовка - русский язык
    ru_parameters = {
        "text": "Текст договора",
        "risk_types": ["legal"],
        "language": "ru"
    }
    
    # Подготовка - английский язык
    en_parameters = {
        "text": "Contract text",
        "risk_types": ["legal"],
        "language": "en"
    }
    
    # Выполнение и проверка
    ru_result = prompt.process(ru_parameters)
    en_result = prompt.process(en_parameters)
    
    assert "риски" in ru_result.lower()
    assert "risks" in en_result.lower()

def test_risk_severity_levels(prompt):
    # Подготовка
    parameters = {
        "text": "Sample text",
        "risk_types": ["legal"],
        "severity_levels": ["high", "medium", "low"]
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert "severity" in result.lower()
    assert "high" in result.lower()
    assert "medium" in result.lower()
    assert "low" in result.lower()

def test_custom_risk_categories(prompt):
    # Подготовка
    parameters = {
        "text": "Sample text",
        "risk_types": ["legal"],
        "custom_categories": ["intellectual_property", "data_protection"]
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert "intellectual property" in result.lower()
    assert "data protection" in result.lower()

def test_risk_analysis_format(prompt):
    # Подготовка
    parameters = {
        "text": "Sample text",
        "risk_types": ["legal"],
        "format": "structured"
    }
    
    # Выполнение
    result = prompt.process(parameters)
    
    # Проверка
    assert "risk_id" in result.lower()
    assert "description" in result.lower()
    assert "severity" in result.lower()
    assert "mitigation" in result.lower()

def test_prompt_version_compatibility(prompt):
    # Подготовка
    old_parameters = {
        "text": "Sample text",
        "risks": ["legal"]  # Старый формат параметра
    }
    
    new_parameters = {
        "text": "Sample text",
        "risk_types": ["legal"]  # Новый формат параметра
    }
    
    # Проверка обратной совместимости
    assert prompt.validate_parameters(old_parameters)
    assert prompt.validate_parameters(new_parameters)