import pytest
from unittest.mock import Mock, patch
from src.service import PromptService
from src.prompts.base import BasePrompt

class TestPrompt(BasePrompt):
    """Тестовый промпт для проверки сервиса"""
    def __init__(self):
        super().__init__("test_prompt")
        self.template = "Test template with {parameter}"

@pytest.fixture
def mock_prompt():
    return Mock(spec=TestPrompt)

@pytest.fixture
def service():
    return PromptService()

def test_service_initialization(service):
    assert service is not None
    assert hasattr(service, 'prompts')
    assert isinstance(service.prompts, dict)

def test_register_prompt(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    
    # Выполнение
    service.register_prompt(mock_prompt)
    
    # Проверка
    assert "test_prompt" in service.prompts
    assert service.prompts["test_prompt"] == mock_prompt

def test_register_duplicate_prompt(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    service.register_prompt(mock_prompt)
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        service.register_prompt(mock_prompt)
    assert "Prompt already registered" in str(exc_info.value)

def test_get_prompt(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    service.register_prompt(mock_prompt)
    
    # Выполнение
    prompt = service.get_prompt("test_prompt")
    
    # Проверка
    assert prompt == mock_prompt

def test_get_nonexistent_prompt(service):
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        service.get_prompt("nonexistent")
    assert "Prompt not found" in str(exc_info.value)

def test_process_prompt(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    mock_prompt.process.return_value = "Processed result"
    service.register_prompt(mock_prompt)
    
    parameters = {"parameter": "value"}
    
    # Выполнение
    result = service.process_prompt("test_prompt", parameters)
    
    # Проверка
    assert result == "Processed result"
    mock_prompt.process.assert_called_once_with(parameters)

def test_get_all_prompts(service):
    # Подготовка
    prompt1 = TestPrompt()
    prompt2 = TestPrompt()
    prompt2.name = "another_prompt"
    
    service.register_prompt(prompt1)
    service.register_prompt(prompt2)
    
    # Выполнение
    prompts = service.get_all_prompts()
    
    # Проверка
    assert len(prompts) == 2
    assert "test_prompt" in prompts
    assert "another_prompt" in prompts

def test_prompt_metadata(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    mock_prompt.get_metadata.return_value = {
        "name": "test_prompt",
        "version": "1.0",
        "template": "Test template"
    }
    service.register_prompt(mock_prompt)
    
    # Выполнение
    metadata = service.get_prompt_metadata("test_prompt")
    
    # Проверка
    assert metadata["name"] == "test_prompt"
    assert metadata["version"] == "1.0"
    assert metadata["template"] == "Test template"

def test_validate_parameters(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    mock_prompt.validate_parameters.return_value = True
    service.register_prompt(mock_prompt)
    
    parameters = {"parameter": "value"}
    
    # Выполнение
    result = service.validate_prompt_parameters("test_prompt", parameters)
    
    # Проверка
    assert result is True
    mock_prompt.validate_parameters.assert_called_once_with(parameters)

def test_bulk_process_prompts(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    mock_prompt.process.return_value = "Processed result"
    service.register_prompt(mock_prompt)
    
    requests = [
        {"prompt": "test_prompt", "parameters": {"param1": "value1"}},
        {"prompt": "test_prompt", "parameters": {"param2": "value2"}}
    ]
    
    # Выполнение
    results = service.bulk_process_prompts(requests)
    
    # Проверка
    assert len(results) == 2
    assert all(result == "Processed result" for result in results)
    assert mock_prompt.process.call_count == 2

def test_prompt_error_handling(service, mock_prompt):
    # Подготовка
    mock_prompt.name = "test_prompt"
    mock_prompt.process.side_effect = Exception("Processing error")
    service.register_prompt(mock_prompt)
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        service.process_prompt("test_prompt", {})
    assert "Processing error" in str(exc_info.value)