import pytest
from fastapi.testclient import TestClient
from ..src.api import app, get_service
from ..src.service import PromptService, InMemoryPromptCache
from ..src.prompts.risk_analysis import RiskAnalysisPrompt

@pytest.fixture
def service() -> PromptService:
    """Фикстура для сервиса промптов"""
    service = PromptService(cache=InMemoryPromptCache())
    service.add_prompt(RiskAnalysisPrompt())
    return service

@pytest.fixture
def client(service: PromptService) -> TestClient:
    """Фикстура для тестового клиента"""
    app.dependency_overrides[get_service] = lambda: service
    return TestClient(app)

def test_list_prompts(client: TestClient):
    """Тест получения списка промптов"""
    response = client.get("/api/v1/prompts")
    assert response.status_code == 200
    prompts = response.json()
    assert len(prompts) == 1
    assert "risk_analysis" in prompts

def test_get_prompt(client: TestClient):
    """Тест получения информации о промпте"""
    response = client.get("/api/v1/prompts/risk_analysis")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "risk_analysis"
    assert data["description"] == "Анализ рисков в юридических документах"
    assert "1.0.0" in data["versions"]
    assert "1.1.0" in data["versions"]

def test_get_nonexistent_prompt(client: TestClient):
    """Тест получения несуществующего промпта"""
    response = client.get("/api/v1/prompts/nonexistent")
    assert response.status_code == 404

def test_format_prompt(client: TestClient):
    """Тест форматирования промпта"""
    params = {
        "parameters": {
            "document": "Тестовый документ",
            "document_type": "Договор",
            "jurisdiction": "РФ"
        }
    }
    response = client.post("/api/v1/prompts/risk_analysis/format", json=params)
    assert response.status_code == 200
    data = response.json()
    assert "result" in data
    assert "Тестовый документ" in data["result"]

def test_format_prompt_invalid_params(client: TestClient):
    """Тест форматирования промпта с неверными параметрами"""
    params = {
        "parameters": {
            "invalid": "params"
        }
    }
    response = client.post("/api/v1/prompts/risk_analysis/format", json=params)
    assert response.status_code == 400

def test_list_versions(client: TestClient):
    """Тест получения списка версий промпта"""
    response = client.get("/api/v1/prompts/risk_analysis/versions")
    assert response.status_code == 200
    data = response.json()
    assert "versions" in data
    assert "1.0.0" in data["versions"]
    assert "1.1.0" in data["versions"]
    assert data["current_version"] == "1.1.0"

def test_get_version(client: TestClient):
    """Тест получения конкретной версии промпта"""
    response = client.get("/api/v1/prompts/risk_analysis/versions/1.0.0")
    assert response.status_code == 200
    data = response.json()
    assert data["version"] == "1.0.0"
    assert "content" in data
    assert "created_at" in data

def test_get_nonexistent_version(client: TestClient):
    """Тест получения несуществующей версии промпта"""
    response = client.get("/api/v1/prompts/risk_analysis/versions/999.0.0")
    assert response.status_code == 404