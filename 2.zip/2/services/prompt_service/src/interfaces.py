from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime

class IPrompt(ABC):
    """Интерфейс для промптов"""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Получить имя промпта"""
        pass
        
    @property
    @abstractmethod
    def description(self) -> str:
        """Получить описание промпта"""
        pass
        
    @abstractmethod
    def format(self, **kwargs: Any) -> str:
        """Форматировать промпт с параметрами"""
        pass
        
    @abstractmethod
    def get_version(self, version: str) -> Optional[Any]:
        """Получить версию промпта"""
        pass
        
    @abstractmethod
    def list_versions(self) -> Dict[str, datetime]:
        """Получить список версий"""
        pass

class IPromptCache(ABC):
    """Интерфейс для кэширования промптов"""
    
    @abstractmethod
    def get(self, key: str) -> Optional[str]:
        """Получить промпт из кэша"""
        pass
        
    @abstractmethod
    def set(self, key: str, value: str, ttl: int = 3600) -> None:
        """Сохранить промпт в кэш"""
        pass
        
    @abstractmethod
    def delete(self, key: str) -> None:
        """Удалить промпт из кэша"""
        pass

class IPromptService(ABC):
    """Интерфейс сервиса промптов"""
    
    @abstractmethod
    def get_prompt(self, name: str) -> IPrompt:
        """Получить промпт по имени"""
        pass
        
    @abstractmethod
    def list_prompts(self) -> List[str]:
        """Получить список доступных промптов"""
        pass
        
    @abstractmethod
    def format_prompt(self, name: str, **kwargs: Any) -> str:
        """Форматировать промпт с параметрами"""
        pass
        
    @abstractmethod
    def add_prompt(self, prompt: IPrompt) -> None:
        """Добавить новый промпт"""
        pass
        
    @abstractmethod
    def remove_prompt(self, name: str) -> None:
        """Удалить промпт"""
        pass