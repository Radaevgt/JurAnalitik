from typing import Dict, List, Any, Optional
from .interfaces import IPromptService, IPrompt, IPromptCache
from .prompts.base import BasePrompt

class PromptService(IPromptService):
    """Сервис для управления промптами"""
    
    def __init__(self, cache: Optional[IPromptCache] = None):
        self._prompts: Dict[str, IPrompt] = {}
        self._cache = cache
        
    def get_prompt(self, name: str) -> IPrompt:
        """Получить промпт по имени"""
        if name not in self._prompts:
            raise KeyError(f"Промпт '{name}' не найден")
        return self._prompts[name]
        
    def list_prompts(self) -> List[str]:
        """Получить список доступных промптов"""
        return list(self._prompts.keys())
        
    def format_prompt(self, name: str, **kwargs: Any) -> str:
        """Форматировать промпт с параметрами"""
        prompt = self.get_prompt(name)
        
        # Проверяем кэш если он доступен
        if self._cache:
            cache_key = f"{name}:{str(kwargs)}"
            cached = self._cache.get(cache_key)
            if cached:
                return cached
                
        # Форматируем промпт
        result = prompt.format(**kwargs)
        
        # Сохраняем в кэш если он доступен
        if self._cache:
            self._cache.set(cache_key, result)
            
        return result
        
    def add_prompt(self, prompt: IPrompt) -> None:
        """Добавить новый промпт"""
        if prompt.name in self._prompts:
            raise ValueError(f"Промпт с именем '{prompt.name}' уже существует")
        self._prompts[prompt.name] = prompt
        
    def remove_prompt(self, name: str) -> None:
        """Удалить промпт"""
        if name not in self._prompts:
            raise KeyError(f"Промпт '{name}' не найден")
        del self._prompts[name]

class InMemoryPromptCache(IPromptCache):
    """Реализация кэша промптов в памяти"""
    
    def __init__(self):
        self._cache: Dict[str, str] = {}
        
    def get(self, key: str) -> Optional[str]:
        """Получить промпт из кэша"""
        return self._cache.get(key)
        
    def set(self, key: str, value: str, ttl: int = 3600) -> None:
        """Сохранить промпт в кэш"""
        self._cache[key] = value
        
    def delete(self, key: str) -> None:
        """Удалить промпт из кэша"""
        if key in self._cache:
            del self._cache[key]