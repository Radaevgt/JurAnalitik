from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route('/health')
def health_check():
    return {'status': 'ok'}

@app.route('/prompts/risk', methods=['POST'])
def get_risk_prompt():
    data = request.json
    return jsonify({
        'prompt': f"Проанализируйте риски в следующем документе: {data['text']}"
    })

@app.route('/prompts/business', methods=['POST'])
def get_business_prompt():
    data = request.json
    return jsonify({
        'prompt': f"Проведите бизнес-анализ документа: {data['text']}"
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8002))
    app.run(host='0.0.0.0', port=port)