from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class PromptVersion:
    """Класс для хранения версии промпта"""
    version: str
    created_at: datetime
    content: str
    metadata: Dict[str, Any] = None
    
class BasePrompt(ABC):
    """Базовый класс для всех промптов"""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self._versions: Dict[str, PromptVersion] = {}
        self._current_version: Optional[str] = None
        
    @property
    def current_version(self) -> Optional[PromptVersion]:
        """Получить текущую версию промпта"""
        if not self._current_version:
            return None
        return self._versions.get(self._current_version)
    
    def add_version(self, version: str, content: str, metadata: Dict[str, Any] = None) -> None:
        """Добавить новую версию промпта"""
        if version in self._versions:
            raise ValueError(f"Версия {version} уже существует")
            
        prompt_version = PromptVersion(
            version=version,
            created_at=datetime.now(),
            content=content,
            metadata=metadata or {}
        )
        self._versions[version] = prompt_version
        self._current_version = version
        
    def get_version(self, version: str) -> Optional[PromptVersion]:
        """Получить конкретную версию промпта"""
        return self._versions.get(version)
        
    def list_versions(self) -> Dict[str, datetime]:
        """Получить список всех версий с датами создания"""
        return {v.version: v.created_at for v in self._versions.values()}

    def set_current_version(self, version: str) -> None:
        """Установить текущую версию промпта"""
        if version not in self._versions:
            raise ValueError(f"Версия {version} не существует")
        self._current_version = version
        
    @abstractmethod
    def format(self, **kwargs: Any) -> str:
        """
        Форматировать промпт с переданными параметрами
        
        Args:
            **kwargs: Параметры для форматирования промпта
            
        Returns:
            str: Отформатированный текст промпта
        """
        pass