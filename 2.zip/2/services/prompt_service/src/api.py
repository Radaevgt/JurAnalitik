from typing import Dict, Any, List
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from services.common.middleware.fastapi_monitoring import setup_monitoring
from .service import PromptService, InMemoryPromptCache
from .interfaces import IPrompt

app = FastAPI(title="Prompt Service API")

# Настройка мониторинга
setup_monitoring(app)

class PromptResponse(BaseModel):
    """Модель ответа с промптом"""
    name: str
    description: str
    versions: List[str]
    current_version: str

class PromptRequest(BaseModel):
    """Модель запроса для форматирования промпта"""
    parameters: Dict[str, Any]

def get_service() -> PromptService:
    """Получить экземпляр сервиса промптов"""
    # В реальном приложении здесь была бы инициализация из конфига
    cache = InMemoryPromptCache()
    return PromptService(cache=cache)

@app.get("/api/v1/prompts", response_model=List[str])
async def list_prompts(service: PromptService = Depends(get_service)) -> List[str]:
    """Получить список доступных промптов"""
    return service.list_prompts()

@app.get("/api/v1/prompts/{name}", response_model=PromptResponse)
async def get_prompt(name: str, service: PromptService = Depends(get_service)) -> PromptResponse:
    """Получить информацию о промпте"""
    try:
        prompt = service.get_prompt(name)
        return PromptResponse(
            name=prompt.name,
            description=prompt.description,
            versions=list(prompt.list_versions().keys()),
            current_version=prompt.current_version.version if prompt.current_version else ""
        )
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Промпт '{name}' не найден")

@app.post("/api/v1/prompts/{name}/format")
async def format_prompt(
    name: str,
    request: PromptRequest,
    service: PromptService = Depends(get_service)
) -> Dict[str, str]:
    """Форматировать промпт с параметрами"""
    try:
        result = service.format_prompt(name, **request.parameters)
        return {"result": result}
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Промпт '{name}' не найден")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/v1/prompts/{name}/versions")
async def list_versions(
    name: str,
    service: PromptService = Depends(get_service)
) -> Dict[str, Any]:
    """Получить список версий промпта"""
    try:
        prompt = service.get_prompt(name)
        versions = prompt.list_versions()
        return {
            "versions": versions,
            "current_version": prompt.current_version.version if prompt.current_version else None
        }
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Промпт '{name}' не найден")

@app.get("/api/v1/prompts/{name}/versions/{version}")
async def get_version(
    name: str,
    version: str,
    service: PromptService = Depends(get_service)
) -> Dict[str, Any]:
    """Получить конкретную версию промпта"""
    try:
        prompt = service.get_prompt(name)
        version_info = prompt.get_version(version)
        if not version_info:
            raise HTTPException(
                status_code=404,
                detail=f"Версия '{version}' промпта '{name}' не найдена"
            )
        return {
            "version": version_info.version,
            "created_at": version_info.created_at,
            "content": version_info.content
        }
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Промпт '{name}' не найден")