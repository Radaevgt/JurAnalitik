from prometheus_client import Counter, Histogram, REGISTRY, generate_latest
from typing import Callable
from flask import Flask, Response, request
import time

# Метрики для HTTP запросов
REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP request count',
    ['method', 'endpoint', 'status']
)

REQUEST_LATENCY = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency in seconds',
    ['method', 'endpoint']
)

ERROR_COUNT = Counter(
    'http_errors_total',
    'Total HTTP errors count',
    ['method', 'endpoint', 'error_type']
)

def setup_monitoring(app: Flask) -> None:
    """Настройка мониторинга для Flask приложения"""
    
    # Endpoint для метрик Prometheus
    @app.route('/metrics')
    def metrics():
        return Response(generate_latest(REGISTRY), mimetype='text/plain')

    # Middleware для сбора метрик
    @app.before_request
    def before_request() -> None:
        request.start_time = time.time()

    @app.after_request
    def after_request(response: Response) -> Response:
        # Получаем endpoint без параметров запроса
        endpoint = request.path.rstrip('/')
        
        # Измеряем время выполнения запроса
        latency = time.time() - request.start_time
        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=endpoint
        ).observe(latency)

        # Увеличиваем счетчик запросов
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=endpoint,
            status=response.status_code
        ).inc()

        return response

    @app.errorhandler(Exception)
    def handle_error(error: Exception) -> Response:
        # Увеличиваем счетчик ошибок
        endpoint = request.path.rstrip('/')
        ERROR_COUNT.labels(
            method=request.method,
            endpoint=endpoint,
            error_type=error.__class__.__name__
        ).inc()
        
        # Передаем ошибку дальше для обработки другими обработчиками
        raise error