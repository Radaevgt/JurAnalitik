import time
from typing import Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from services.common.logging.logger import ServiceLogger

class LoggingMiddleware(BaseHTTPMiddleware):
    """Middleware для логирования HTTP запросов и ответов"""

    def __init__(self, app, service_name: str):
        super().__init__(app)
        self.logger = ServiceLogger(
            service_name=service_name,
            log_level="INFO",
            log_file=f"logs/{service_name}.log"
        )

    async def dispatch(
        self,
        request: Request,
        call_next: Callable
    ) -> Response:
        """
        Обработка запроса с логированием
        
        Args:
            request: Входящий HTTP запрос
            call_next: Следующий обработчик в цепочке
            
        Returns:
            Response: HTTP ответ
        """
        # Логируем начало запроса
        start_time = time.time()
        
        # Собираем информацию о запросе
        request_info = {
            "method": request.method,
            "url": str(request.url),
            "client_ip": request.client.host,
            "headers": dict(request.headers),
            "path_params": request.path_params,
            "query_params": dict(request.query_params)
        }

        # Пытаемся получить тело запроса
        try:
            body = await request.body()
            if body:
                request_info["body"] = body.decode()
        except Exception:
            request_info["body"] = "Could not read body"

        self.logger.info(
            f"Incoming request to {request.url.path}",
            **request_info
        )

        try:
            # Выполняем запрос
            response = await call_next(request)

            # Вычисляем время выполнения
            process_time = time.time() - start_time

            # Логируем успешный ответ
            self.logger.info(
                f"Request completed: {request.url.path}",
                status_code=response.status_code,
                process_time=f"{process_time:.3f}s",
                response_headers=dict(response.headers)
            )

            return response

        except Exception as e:
            # Вычисляем время до ошибки
            process_time = time.time() - start_time

            # Логируем ошибку
            self.logger.error(
                f"Request failed: {request.url.path}",
                exc_info=e,
                process_time=f"{process_time:.3f}s",
                **request_info
            )
            raise

class ErrorLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware для логирования необработанных исключений"""

    def __init__(self, app, service_name: str):
        super().__init__(app)
        self.logger = ServiceLogger(
            service_name=service_name,
            log_level="ERROR",
            log_file=f"logs/{service_name}_errors.log"
        )

    async def dispatch(
        self,
        request: Request,
        call_next: Callable
    ) -> Response:
        try:
            return await call_next(request)
        except Exception as e:
            # Логируем необработанное исключение
            self.logger.error(
                "Unhandled exception",
                exc_info=e,
                url=str(request.url),
                method=request.method,
                headers=dict(request.headers)
            )
            raise

# Пример использования в FastAPI приложении:
"""
from fastapi import FastAPI
from services.common.middleware.logging_middleware import (
    LoggingMiddleware,
    ErrorLoggingMiddleware
)

app = FastAPI()

# Добавляем middleware
app.add_middleware(
    LoggingMiddleware,
    service_name="analysis_service"
)
app.add_middleware(
    ErrorLoggingMiddleware,
    service_name="analysis_service"
)
"""