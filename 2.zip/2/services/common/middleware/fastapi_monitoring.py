from prometheus_client import Counter, Histogram, REGISTRY, generate_latest
from fastapi import FastAPI, Request, Response
from typing import Callable
import time

# Метрики для HTTP запросов
REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP request count',
    ['method', 'endpoint', 'status']
)

REQUEST_LATENCY = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency in seconds',
    ['method', 'endpoint']
)

ERROR_COUNT = Counter(
    'http_errors_total',
    'Total HTTP errors count',
    ['method', 'endpoint', 'error_type']
)

def setup_monitoring(app: FastAPI) -> None:
    """Настройка мониторинга для FastAPI приложения"""
    
    @app.get("/metrics")
    async def metrics():
        return Response(generate_latest(REGISTRY), media_type="text/plain")

    @app.middleware("http")
    async def monitoring_middleware(request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        try:
            response = await call_next(request)
            
            # Получаем endpoint без параметров запроса
            endpoint = request.url.path.rstrip('/')
            
            # Измеряем время выполнения запроса
            latency = time.time() - start_time
            REQUEST_LATENCY.labels(
                method=request.method,
                endpoint=endpoint
            ).observe(latency)

            # Увеличиваем счетчик запросов
            REQUEST_COUNT.labels(
                method=request.method,
                endpoint=endpoint,
                status=response.status_code
            ).inc()

            return response

        except Exception as e:
            # Увеличиваем счетчик ошибок
            endpoint = request.url.path.rstrip('/')
            ERROR_COUNT.labels(
                method=request.method,
                endpoint=endpoint,
                error_type=e.__class__.__name__
            ).inc()
            raise e