import logging
import sys
import json
from datetime import datetime
from typing import Any, Dict, Optional
from pathlib import Path

class JsonFormatter(logging.Formatter):
    """Форматтер для логов в JSON формате"""
    
    def format(self, record: logging.LogRecord) -> str:
        """Форматирование записи лога в JSON"""
        log_object = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "service": getattr(record, "service", "unknown"),
            "message": record.getMessage(),
            "logger": record.name,
            "path": record.pathname,
            "line": record.lineno
        }

        # Добавляем информацию об исключении, если оно есть
        if record.exc_info:
            log_object["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": self.formatException(record.exc_info)
            }

        # Добавляем дополнительные поля
        if hasattr(record, "extra_fields"):
            log_object.update(record.extra_fields)

        return json.dumps(log_object)

class ServiceLogger:
    """Класс для настройки логирования сервиса"""

    def __init__(
        self,
        service_name: str,
        log_level: str = "INFO",
        log_file: Optional[str] = None,
        json_format: bool = True
    ):
        """
        Инициализация логгера
        
        Args:
            service_name: Имя сервиса
            log_level: Уровень логирования
            log_file: Путь к файлу логов
            json_format: Использовать JSON формат
        """
        self.service_name = service_name
        self.logger = logging.getLogger(service_name)
        self.logger.setLevel(getattr(logging, log_level.upper()))

        # Создаем форматтер
        if json_format:
            formatter = JsonFormatter()
        else:
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(service)s: %(message)s'
            )

        # Добавляем вывод в консоль
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

        # Добавляем вывод в файл, если указан
        if log_file:
            # Создаем директорию для логов, если её нет
            log_path = Path(log_file).parent
            log_path.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)

    def _log(
        self,
        level: int,
        message: str,
        extra_fields: Optional[Dict[str, Any]] = None,
        exc_info: Optional[Exception] = None
    ) -> None:
        """
        Внутренний метод для логирования
        
        Args:
            level: Уровень логирования
            message: Сообщение
            extra_fields: Дополнительные поля для JSON
            exc_info: Информация об исключении
        """
        extra = {
            "service": self.service_name,
            "extra_fields": extra_fields or {}
        }
        self.logger.log(level, message, extra=extra, exc_info=exc_info)

    def debug(self, message: str, **kwargs) -> None:
        """Лог уровня DEBUG"""
        self._log(logging.DEBUG, message, kwargs)

    def info(self, message: str, **kwargs) -> None:
        """Лог уровня INFO"""
        self._log(logging.INFO, message, kwargs)

    def warning(self, message: str, **kwargs) -> None:
        """Лог уровня WARNING"""
        self._log(logging.WARNING, message, kwargs)

    def error(
        self,
        message: str,
        exc_info: Optional[Exception] = None,
        **kwargs
    ) -> None:
        """Лог уровня ERROR"""
        self._log(logging.ERROR, message, kwargs, exc_info)

    def critical(
        self,
        message: str,
        exc_info: Optional[Exception] = None,
        **kwargs
    ) -> None:
        """Лог уровня CRITICAL"""
        self._log(logging.CRITICAL, message, kwargs, exc_info)

# Пример использования:
"""
logger = ServiceLogger(
    service_name="analysis_service",
    log_level="DEBUG",
    log_file="logs/analysis_service.log",
    json_format=True
)

try:
    # Какой-то код
    logger.info("Начало анализа документа", document_id="123")
except Exception as e:
    logger.error(
        "Ошибка при анализе документа",
        exc_info=e,
        document_id="123",
        status="failed"
    )
"""