# Локальное развертывание

## Требования
- Python 3.8+
- Docker и Docker Compose
- Make (опционально)
- PowerShell (для Windows)

## Установка
1. Клонировать репозиторий
2. Установить зависимости для каждого сервиса
3. Настроить конфигурационные файлы

## Запуск
### Через Make
```bash
make up      # запуск всех сервисов
make down    # остановка
make logs    # просмотр логов
```

### Через PowerShell (Windows)
```powershell
.\scripts\start.ps1  # запуск
.\scripts\stop.ps1   # остановка
.\scripts\logs.ps1   # логи
```

## Проверка
1. Открыть http://localhost:8000 - AI Gateway
2. Открыть http://localhost:9090 - Prometheus

## Устранение проблем
- Описание типичных ошибок
- Решения частых проблем