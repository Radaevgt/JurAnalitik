# Руководство по развертыванию

## Требования к системе
- Docker 20.10+
- Docker Compose 2.0+
- 4GB RAM минимум
- 20GB свободного места на диске

## Подготовка окружения

### 1. Клонирование репозитория
```bash
git clone <repository-url>
cd project-directory
```

### 2. Настройка переменных окружения
```bash
cp .env.example .env
```
Отредактируйте файл .env, указав необходимые значения:
- API_KEYS для провайдеров AI
- Настройки безопасности
- Параметры кэширования

## Развертывание сервисов

### Локальное развертывание
```bash
docker-compose up -d
```

### Продакшн развертывание
1. Настройка SSL-сертификатов
2. Конфигурация обратного прокси
3. Запуск с продакшн конфигурацией:
```bash
docker-compose -f docker-compose.prod.yml up -d
```

## Конфигурация сервисов

### AI Gateway
- Порт: 8000
- Конфигурация: services/ai_gateway/config/config.yaml
- Логи: /var/log/ai_gateway/

### Provider Service
- Порт: 8001
- Конфигурация: services/provider_service/config/config.yaml
- Логи: /var/log/provider_service/

### Prompt Service
- Порт: 8002
- Конфигурация: services/prompt_service/config/config.yaml
- Логи: /var/log/prompt_service/

### Analysis Service
- Порт: 8003
- Конфигурация: services/analysis_service/config/config.yaml
- Логи: /var/log/analysis_service/

## Мониторинг

### Метрики
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000

### Логирование
- ELK Stack
- Kibana: http://localhost:5601

### Трейсинг
- Jaeger UI: http://localhost:16686

## Обновление системы
```bash
git pull
docker-compose down
docker-compose up -d --build
```

## Резервное копирование
- Настройка периодического бэкапа конфигураций
- Сохранение логов
- Экспорт метрик

## Устранение неполадок
1. Проверка логов: `docker-compose logs -f [service_name]`
2. Проверка статуса: `docker-compose ps`
3. Перезапуск сервиса: `docker-compose restart [service_name]`

## Контакты поддержки
- Email: support@example.com
- Slack: #deployment-support