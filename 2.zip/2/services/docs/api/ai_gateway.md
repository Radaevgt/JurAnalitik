# AI Gateway API

## Общая информация
- Base URL: `http://localhost:8000`
- Формат: JSON
- Аутентификация: Bearer token

## Endpoints

### Отправка запроса к AI провайдеру
```http
POST /v1/completion
```

#### Запрос
```json
{
  "provider": "string",  // Имя провайдера (deepseek, enhanced_deepseek)
  "prompt": "string",    // Текст промпта
  "options": {          // Опциональные параметры
    "temperature": 0.7,
    "max_tokens": 1000,
    "stream": false
  }
}
```

#### Ответ
```json
{
  "id": "string",
  "response": "string",
  "usage": {
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0
  }
}
```

### Получение статуса сервиса
```http
GET /v1/health
```

#### Ответ
```json
{
  "status": "ok",
  "version": "string",
  "providers": ["deepseek", "enhanced_deepseek"]
}
```

### Получение метрик
```http
GET /v1/metrics
```

#### Ответ
```json
{
  "requests_total": 0,
  "requests_success": 0,
  "requests_failed": 0,
  "average_response_time": 0
}
```

## Коды ошибок

| Код | Описание |
|-----|----------|
| 400 | Неверный запрос |
| 401 | Не авторизован |
| 403 | Доступ запрещен |
| 404 | Ресурс не найден |
| 429 | Слишком много запросов |
| 500 | Внутренняя ошибка сервера |

## Ограничения
- Максимальное количество запросов: 100 в минуту
- Максимальный размер запроса: 10MB
- Таймаут: 30 секунд

## Примеры

### Отправка запроса
```bash
curl -X POST http://localhost:8000/v1/completion \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "provider": "deepseek",
    "prompt": "Analyze this text",
    "options": {
      "temperature": 0.7
    }
  }'
```

## Безопасность
- Все запросы должны использовать HTTPS
- Токены должны храниться безопасно
- Логирование всех запросов