# Analysis Service API

## Общая информация
- Base URL: `http://localhost:8003`
- Формат: JSON
- Аутентификация: Bearer token

## Endpoints

### Запуск анализа документа
```http
POST /v1/analyze
```

#### Запрос
```json
{
  "document": {
    "content": "string",
    "type": "text/plain",
    "name": "document.txt"
  },
  "analyzers": [
    "risk",
    "business",
    "compliance",
    "terminology",
    "structural"
  ],
  "options": {
    "language": "ru",
    "format": "markdown",
    "detailed": true
  }
}
```

#### Ответ
```json
{
  "task_id": "string",
  "status": "processing",
  "estimated_time": 120
}
```

### Получение результатов анализа
```http
GET /v1/analyze/{task_id}
```

#### Ответ
```json
{
  "task_id": "string",
  "status": "completed",
  "results": {
    "risk_analysis": {
      "score": 0.75,
      "risks": [
        {
          "type": "legal",
          "severity": "high",
          "description": "string"
        }
      ]
    },
    "business_analysis": {
      "entities": [
        {
          "type": "company",
          "name": "string",
          "role": "string"
        }
      ]
    },
    "compliance_analysis": {
      "compliant": true,
      "regulations": [
        {
          "code": "string",
          "status": "compliant"
        }
      ]
    }
  },
  "metadata": {
    "processing_time": 45,
    "word_count": 1000,
    "language": "ru"
  }
}
```

### Получение списка доступных анализаторов
```http
GET /v1/analyzers
```

#### Ответ
```json
{
  "analyzers": [
    {
      "id": "risk",
      "name": "Анализ рисков",
      "description": "Выявление юридических рисков",
      "supported_formats": ["text/plain", "application/pdf"]
    },
    {
      "id": "business",
      "name": "Бизнес-анализ",
      "description": "Анализ бизнес-сущностей и отношений",
      "supported_formats": ["text/plain", "application/pdf"]
    }
  ]
}
```

### Получение форматов вывода
```http
GET /v1/formats
```

#### Ответ
```json
{
  "formats": [
    {
      "id": "markdown",
      "name": "Markdown",
      "description": "Форматированный текст в Markdown"
    },
    {
      "id": "html",
      "name": "HTML",
      "description": "HTML документ с форматированием"
    },
    {
      "id": "json",
      "name": "JSON",
      "description": "Структурированные данные в JSON"
    }
  ]
}
```

## Коды ошибок

| Код | Описание |
|-----|----------|
| 400 | Неверный запрос |
| 401 | Не авторизован |
| 403 | Доступ запрещен |
| 404 | Ресурс не найден |
| 415 | Неподдерживаемый формат |
| 422 | Ошибка валидации |
| 500 | Внутренняя ошибка сервера |

## Ограничения
- Максимальный размер документа: 10MB
- Поддерживаемые форматы: text/plain, application/pdf, application/docx
- Максимальное время анализа: 300 секунд
- Rate limit: 10 запросов в минуту

## Примеры

### Отправка документа на анализ
```bash
curl -X POST http://localhost:8003/v1/analyze \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "document": {
      "content": "Текст документа",
      "type": "text/plain"
    },
    "analyzers": ["risk", "business"],
    "options": {
      "language": "ru",
      "format": "markdown"
    }
  }'
```

## Безопасность
- Обязательная аутентификация
- Шифрование данных при передаче
- Изоляция данных разных пользователей