# Provider Service API

## Общая информация
- Base URL: `http://localhost:8001`
- Формат: JSON
- Аутентификация: Bearer token

## Endpoints

### Получение списка доступных провайдеров
```http
GET /v1/providers
```

#### Ответ
```json
{
  "providers": [
    {
      "id": "deepseek",
      "name": "DeepSeek",
      "version": "1.0",
      "capabilities": ["completion", "chat"],
      "status": "active"
    },
    {
      "id": "enhanced_deepseek",
      "name": "Enhanced DeepSeek",
      "version": "2.0",
      "capabilities": ["completion", "chat", "analysis"],
      "status": "active"
    }
  ]
}
```

### Получение информации о провайдере
```http
GET /v1/providers/{provider_id}
```

#### Ответ
```json
{
  "id": "deepseek",
  "name": "DeepSeek",
  "version": "1.0",
  "capabilities": ["completion", "chat"],
  "status": "active",
  "config": {
    "max_tokens": 4096,
    "supported_languages": ["en", "ru"],
    "features": ["streaming", "function_calling"]
  }
}
```

### Выполнение запроса через провайдера
```http
POST /v1/providers/{provider_id}/completion
```

#### Запрос
```json
{
  "prompt": "string",
  "options": {
    "temperature": 0.7,
    "max_tokens": 1000,
    "stream": false
  }
}
```

#### Ответ
```json
{
  "id": "string",
  "provider": "string",
  "response": "string",
  "usage": {
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0
  }
}
```

### Проверка статуса провайдера
```http
GET /v1/providers/{provider_id}/health
```

#### Ответ
```json
{
  "status": "ok",
  "latency": 150,
  "error_rate": 0.001,
  "requests_per_minute": 100
}
```

## Коды ошибок

| Код | Описание |
|-----|----------|
| 400 | Неверный запрос |
| 401 | Не авторизован |
| 403 | Доступ запрещен |
| 404 | Провайдер не найден |
| 429 | Превышен лимит запросов |
| 500 | Ошибка провайдера |
| 503 | Провайдер недоступен |

## Ограничения
- Rate limit: 100 запросов в минуту
- Максимальный размер промпта: 32KB
- Таймаут: 60 секунд

## Примеры

### Получение списка провайдеров
```bash
curl -X GET http://localhost:8001/v1/providers \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Отправка запроса к провайдеру
```bash
curl -X POST http://localhost:8001/v1/providers/deepseek/completion \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Analyze this text",
    "options": {
      "temperature": 0.7
    }
  }'
```

## Безопасность
- Все запросы должны быть аутентифицированы
- API ключи провайдеров хранятся в зашифрованном виде
- Поддержка rate limiting для защиты от DoS атак