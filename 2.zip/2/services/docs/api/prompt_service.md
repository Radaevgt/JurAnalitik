# Prompt Service API

## Общая информация
- Base URL: `http://localhost:8002`
- Формат: JSON
- Аутентификация: Bearer token

## Endpoints

### Получение списка доступных промптов
```http
GET /v1/prompts
```

#### Ответ
```json
{
  "prompts": [
    {
      "id": "risk_analysis",
      "name": "Анализ рисков",
      "version": "1.0",
      "category": "analysis",
      "description": "Промпт для анализа юридических рисков"
    },
    {
      "id": "business_analysis",
      "name": "Бизнес-анализ",
      "version": "1.0",
      "category": "analysis",
      "description": "Промпт для бизнес-анализа документов"
    }
  ]
}
```

### Получение конкретного промпта
```http
GET /v1/prompts/{prompt_id}
```

#### Ответ
```json
{
  "id": "risk_analysis",
  "name": "Анализ рисков",
  "version": "1.0",
  "category": "analysis",
  "description": "Промпт для анализа юридических рисков",
  "template": "Проанализируй следующий текст на предмет юридических рисков: {{text}}",
  "parameters": {
    "text": {
      "type": "string",
      "required": true,
      "description": "Текст для анализа"
    }
  },
  "metadata": {
    "author": "Legal Team",
    "created_at": "2025-01-01",
    "updated_at": "2025-07-14"
  }
}
```

### Генерация промпта
```http
POST /v1/prompts/{prompt_id}/generate
```

#### Запрос
```json
{
  "parameters": {
    "text": "Текст договора для анализа"
  },
  "options": {
    "language": "ru",
    "format": "markdown"
  }
}
```

#### Ответ
```json
{
  "id": "gen_123",
  "prompt": "Проанализируй следующий текст на предмет юридических рисков: Текст договора для анализа",
  "metadata": {
    "template_id": "risk_analysis",
    "version": "1.0",
    "generated_at": "2025-07-14T12:00:00Z"
  }
}
```

### Создание нового промпта
```http
POST /v1/prompts
```

#### Запрос
```json
{
  "name": "Новый анализ",
  "category": "analysis",
  "description": "Описание нового типа анализа",
  "template": "Шаблон промпта с {{параметром}}",
  "parameters": {
    "параметр": {
      "type": "string",
      "required": true,
      "description": "Описание параметра"
    }
  }
}
```

## Коды ошибок

| Код | Описание |
|-----|----------|
| 400 | Неверный запрос |
| 401 | Не авторизован |
| 403 | Доступ запрещен |
| 404 | Промпт не найден |
| 422 | Ошибка валидации |
| 500 | Внутренняя ошибка сервера |

## Ограничения
- Максимальная длина шаблона: 4096 символов
- Максимальное количество параметров: 10
- Rate limit: 1000 запросов в минуту

## Примеры

### Получение списка промптов
```bash
curl -X GET http://localhost:8002/v1/prompts \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Генерация промпта
```bash
curl -X POST http://localhost:8002/v1/prompts/risk_analysis/generate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "parameters": {
      "text": "Текст для анализа"
    }
  }'
```

## Безопасность
- Аутентификация через Bearer токены
- Валидация всех входных данных
- Логирование использования промптов