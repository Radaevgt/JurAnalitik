from flask import Flask, request, jsonify
from analyzers.risk_analyzer import RiskAnalyzer
from analyzers.business_analyzer import BusinessAnalyzer
import os

app = Flask(__name__)
risk_analyzer = RiskAnalyzer()
business_analyzer = BusinessAnalyzer()

@app.route('/health')
def health_check():
    return {'status': 'ok'}

@app.route('/analyze/risk', methods=['POST'])
def analyze_risk():
    data = request.json
    result = risk_analyzer.analyze(data['text'])
    return jsonify(result)

@app.route('/analyze/business', methods=['POST'])
def analyze_business():
    data = request.json
    result = business_analyzer.analyze(data['text'])
    return jsonify(result)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8003))
    app.run(host='0.0.0.0', port=port)