from fastapi import FastAPI, Depends
from services.common.middleware.logging_middleware import (
    LoggingMiddleware,
    ErrorLoggingMiddleware
)
from services.analysis_service.src.api.routes import analyzers, formatters
from services.analysis_service.src.api.middleware.auth import verify_token
from services.analysis_service.src.api.middleware.error_handler import (
    register_error_handlers
)

app = FastAPI(
    title="Analysis Service",
    description="Сервис для анализа юридических документов",
    version="1.0.0"
)

# Добавляем middleware для логирования
app.add_middleware(
    LoggingMiddleware,
    service_name="analysis_service"
)
app.add_middleware(
    ErrorLoggingMiddleware,
    service_name="analysis_service"
)

# Регистрируем обработчики ошибок
register_error_handlers(app)

# Подключаем роуты
app.include_router(
    analyzers.router,
    prefix="/api/v1/analyzers",
    tags=["analyzers"],
    dependencies=[Depends(verify_token)]
)

app.include_router(
    formatters.router,
    prefix="/api/v1/formatters",
    tags=["formatters"],
    dependencies=[Depends(verify_token)]
)

# Создаем директорию для логов при запуске
import os
os.makedirs("logs", exist_ok=True)

@app.on_event("startup")
async def startup_event():
    """Действия при запуске сервиса"""
    from services.common.logging.logger import ServiceLogger
    
    logger = ServiceLogger(
        service_name="analysis_service",
        log_level="INFO",
        log_file="logs/analysis_service.log"
    )
    logger.info("Analysis Service started")

@app.on_event("shutdown")
async def shutdown_event():
    """Действия при остановке сервиса"""
    from services.common.logging.logger import ServiceLogger
    
    logger = ServiceLogger(
        service_name="analysis_service",
        log_level="INFO",
        log_file="logs/analysis_service.log"
    )
    logger.info("Analysis Service stopped")