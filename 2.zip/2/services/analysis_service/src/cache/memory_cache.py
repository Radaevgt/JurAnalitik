from typing import Any, Optional, Dict, Tuple
from datetime import datetime, timedelta

from .base import BaseCache

class MemoryCache(BaseCache):
    """
    Реализация кэша в памяти с поддержкой TTL.
    Хранит данные в словаре Python.
    """
    
    def __init__(self):
        self._cache: Dict[str, Tuple[Any, Optional[datetime]]] = {}
    
    async def get(self, key: str) -> Optional[Any]:
        if not await self.has(key):
            return None
            
        value, expires_at = self._cache[key]
        if expires_at and datetime.now() > expires_at:
            await self.delete(key)
            return None
            
        return value
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        try:
            expires_at = None
            if ttl is not None:
                expires_at = datetime.now() + timedelta(seconds=ttl)
                
            self._cache[key] = (value, expires_at)
            return True
        except Exception:
            return False
    
    async def delete(self, key: str) -> bool:
        try:
            if key in self._cache:
                del self._cache[key]
                return True
            return False
        except Exception:
            return False
    
    async def clear(self) -> bool:
        try:
            self._cache.clear()
            return True
        except Exception:
            return False
    
    async def has(self, key: str) -> bool:
        if key not in self._cache:
            return False
            
        value, expires_at = self._cache[key]
        if expires_at and datetime.now() > expires_at:
            await self.delete(key)
            return False
            
        return True