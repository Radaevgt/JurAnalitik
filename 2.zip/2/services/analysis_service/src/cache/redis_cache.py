from typing import Any, Optional
import json
import aioredis
from datetime import timedelta

from .base import BaseCache

class RedisCache(BaseCache):
    """
    Реализация кэша с использованием Redis.
    Поддерживает TTL и сериализацию данных в JSON.
    """
    
    def __init__(self, redis_url: str):
        """
        Инициализация Redis кэша.
        
        Args:
            redis_url: URL подключения к Redis серверу
        """
        self._redis = aioredis.from_url(redis_url)
        
    async def get(self, key: str) -> Optional[Any]:
        """
        Получить значение из Redis по ключу.
        
        Args:
            key: Ключ для поиска значения
            
        Returns:
            Any: Десериализованное значение или None если не найдено
        """
        try:
            value = await self._redis.get(key)
            if value is None:
                return None
            return json.loads(value)
        except Exception:
            return None
            
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Сохранить значение в Redis.
        
        Args:
            key: Ключ для сохранения
            value: Значение для кэширования
            ttl: Время жизни в секундах
            
        Returns:
            bool: True если успешно сохранено
        """
        try:
            serialized = json.dumps(value)
            if ttl is not None:
                await self._redis.setex(key, ttl, serialized)
            else:
                await self._redis.set(key, serialized)
            return True
        except Exception:
            return False
            
    async def delete(self, key: str) -> bool:
        """
        Удалить значение из Redis по ключу.
        
        Args:
            key: Ключ для удаления
            
        Returns:
            bool: True если успешно удалено
        """
        try:
            await self._redis.delete(key)
            return True
        except Exception:
            return False
            
    async def clear(self) -> bool:
        """
        Очистить весь кэш Redis.
        
        Returns:
            bool: True если успешно очищено
        """
        try:
            await self._redis.flushdb()
            return True
        except Exception:
            return False
            
    async def has(self, key: str) -> bool:
        """
        Проверить существование ключа в Redis.
        
        Args:
            key: Ключ для проверки
            
        Returns:
            bool: True если ключ существует
        """
        try:
            return await self._redis.exists(key) > 0
        except Exception:
            return False