import asyncio
from typing import Any, Dict, Tuple, Optional, Coroutine
from enum import Enum
from collections import OrderedDict

class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class TaskManager:
    """
    Менеджер асинхронных задач.
    Управляет выполнением задач с ограничением количества одновременно выполняемых задач.
    """
    
    def __init__(self, max_concurrent_tasks: int = 10):
        """
        Инициализация менеджера задач.
        
        Args:
            max_concurrent_tasks: Максимальное количество одновременно выполняемых задач
        """
        self._tasks: Dict[str, Dict] = OrderedDict()
        self._semaphore = asyncio.Semaphore(max_concurrent_tasks)
        
    async def _execute_task(self, task_id: str, coro: Coroutine) -> None:
        """
        Выполнить задачу с обработкой ошибок.
        
        Args:
            task_id: ID задачи
            coro: Корутина для выполнения
        """
        try:
            async with self._semaphore:
                self._tasks[task_id]["status"] = TaskStatus.RUNNING
                result = await coro
                self._tasks[task_id].update({
                    "status": TaskStatus.COMPLETED,
                    "result": result
                })
        except Exception as e:
            self._tasks[task_id].update({
                "status": TaskStatus.FAILED,
                "result": str(e)
            })
            
    def add_task(self, task_id: str, coro: Coroutine) -> None:
        """
        Добавить новую задачу в очередь.
        
        Args:
            task_id: ID задачи
            coro: Корутина для выполнения
        """
        self._tasks[task_id] = {
            "status": TaskStatus.PENDING,
            "result": None
        }
        
        # Запускаем задачу асинхронно
        asyncio.create_task(self._execute_task(task_id, coro))
        
    def get_task_status(self, task_id: str) -> Tuple[str, Optional[Any]]:
        """
        Получить статус и результат задачи.
        
        Args:
            task_id: ID задачи
            
        Returns:
            Tuple[str, Any]: Статус и результат задачи
            
        Raises:
            KeyError: если задача не найдена
        """
        if task_id not in self._tasks:
            raise KeyError(f"Задача {task_id} не найдена")
            
        task = self._tasks[task_id]
        return task["status"], task["result"]
        
    def cleanup_completed_tasks(self, max_tasks: int = 1000) -> None:
        """
        Очистить завершенные задачи, оставив только последние max_tasks.
        
        Args:
            max_tasks: Максимальное количество хранимых задач
        """
        while len(self._tasks) > max_tasks:
            # Удаляем самую старую завершенную задачу
            for task_id, task in self._tasks.items():
                if task["status"] in (TaskStatus.COMPLETED, TaskStatus.FAILED):
                    self._tasks.pop(task_id)
                    break