from typing import Dict
from fastapi import APIRouter, Depends, HTTPException, status
from ..schemas import FormatterRequest
from ..middleware.auth import auth_middleware, service_auth_middleware
from ...service import AnalysisService
from ...decorators.async_task import async_task, get_task_result

router = APIRouter(prefix="/formatters", tags=["formatters"])
analysis_service = AnalysisService()

@router.post("/format")
@async_task
async def format_results(
    request: FormatterRequest,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Асинхронно форматировать результаты анализа в указанный формат
    """
    formatter = analysis_service.get_formatter(request.format_type)
    if not formatter:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Форматтер {request.format_type} не найден"
        )
    
    formatted_result = await formatter.format(
        data=request.analysis_results,
        options=request.options
    )
    return {"formatted_output": formatted_result}

@router.get("/types")
async def get_available_formatters(
    token: str = Depends(auth_middleware)
) -> Dict[str, str]:
    """
    Получить список доступных форматтеров с их описанием
    """
    formatters = analysis_service.get_available_formatter_types()
    return {
        formatter_type: formatter.description 
        for formatter_type, formatter in formatters.items()
    }

@router.get("/preview/{format_type}")
async def get_formatter_preview(
    format_type: str,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Получить пример форматирования для указанного типа
    """
    try:
        preview = await analysis_service.get_formatter_preview(format_type)
        return {"preview": preview}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )

@router.get("/tasks/{task_id}")
async def get_task_status(
    task_id: str,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Получить статус и результат выполнения асинхронной задачи
    """
    return get_task_result(task_id)