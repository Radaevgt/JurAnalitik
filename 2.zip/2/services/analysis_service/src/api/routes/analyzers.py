from typing import List, Dict
from fastapi import APIRouter, Depends, HTTPException, status
from ..schemas import AnalysisRequest, AnalysisResponse, AnalyzerRequest
from ..middleware.auth import auth_middleware, service_auth_middleware
from ...service import AnalysisService
from ...core.base_analyzer import BaseAnalyzer
from ...decorators.async_task import async_task, get_task_result

router = APIRouter(prefix="/analyzers", tags=["analyzers"])
analysis_service = AnalysisService()

@router.post("/analyze")
@async_task
async def analyze_document(
    request: AnalysisRequest,
    token: str = Depends(auth_middleware)
) -> AnalysisResponse:
    """
    Асинхронно выполнить анализ документа с использованием указанных анализаторов
    """
    return await analysis_service.analyze_document(
        text=request.document_text,
        analysis_types=request.analysis_types,
        format_type=request.format_type,
        options=request.options
    )

@router.post("/{analyzer_type}")
@async_task
async def analyze_with_specific_analyzer(
    analyzer_type: str,
    request: AnalyzerRequest,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Асинхронно выполнить анализ с использованием конкретного анализатора
    """
    analyzer = analysis_service.get_analyzer(analyzer_type)
    if not analyzer:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Анализатор {analyzer_type} не найден"
        )
    
    result = await analyzer.analyze(
        text=request.text,
        options=request.options
    )
    return {"results": result}

@router.get("/types", response_model=List[str])
async def get_available_analyzers(
    token: str = Depends(auth_middleware)
) -> List[str]:
    """
    Получить список доступных типов анализаторов
    """
    return analysis_service.get_available_analyzer_types()

@router.get("/status/{task_id}", response_model=Dict)
async def get_analysis_status(
    task_id: str,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Получить статус выполнения анализа по ID задачи
    """
    try:
        status = await analysis_service.get_analysis_status(task_id)
        return {"status": status}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )

@router.get("/tasks/{task_id}")
async def get_task_status(
    task_id: str,
    token: str = Depends(auth_middleware)
) -> Dict:
    """
    Получить статус и результат выполнения асинхронной задачи
    """
    return get_task_result(task_id)