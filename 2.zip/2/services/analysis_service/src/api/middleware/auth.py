from typing import Optional
from fastapi import Request, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

class AuthMiddleware(HTTPBearer):
    """Middleware для аутентификации запросов"""
    
    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)
        
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        """Проверка аутентификации для каждого запроса"""
        credentials: Optional[HTTPAuthorizationCredentials] = await super().__call__(request)
        
        if credentials:
            if not self.verify_token(credentials.credentials):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Неверный токен аутентификации",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            return credentials
        
        return None
    
    def verify_token(self, token: str) -> bool:
        """Проверка валидности токена"""
        # TODO: Реализовать проверку токена через внешний сервис аутентификации
        # Временная реализация для разработки
        return token == "test_token"

class ServiceAuthMiddleware(HTTPBearer):
    """Middleware для аутентификации между сервисами"""
    
    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)
        
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        """Проверка аутентификации для межсервисных запросов"""
        credentials: Optional[HTTPAuthorizationCredentials] = await super().__call__(request)
        
        if credentials:
            if not self.verify_service_token(credentials.credentials):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Неверный токен сервиса",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            return credentials
        
        return None
    
    def verify_service_token(self, token: str) -> bool:
        """Проверка валидности токена сервиса"""
        # TODO: Реализовать проверку токена через конфигурацию сервисов
        # Временная реализация для разработки
        return token in ["prompt_service_token", "provider_service_token", "ai_gateway_token"]

auth_middleware = AuthMiddleware()
service_auth_middleware = ServiceAuthMiddleware()