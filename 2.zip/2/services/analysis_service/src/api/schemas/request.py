from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class AnalysisRequest(BaseModel):
    """Базовая модель запроса на анализ документа"""
    document_text: str = Field(..., description="Текст документа для анализа")
    analysis_types: List[str] = Field(..., description="Типы анализа для выполнения")
    format_type: str = Field(..., description="Формат вывода результатов")
    options: Optional[Dict] = Field(default={}, description="Дополнительные параметры анализа")

class AnalyzerRequest(BaseModel):
    """Модель запроса для конкретного анализатора"""
    text: str = Field(..., description="Текст для анализа")
    options: Optional[Dict] = Field(default={}, description="Параметры анализа")

class FormatterRequest(BaseModel):
    """Модель запроса для форматирования результатов"""
    analysis_results: Dict = Field(..., description="Результаты анализа для форматирования")
    format_type: str = Field(..., description="Требуемый формат вывода")
    options: Optional[Dict] = Field(default={}, description="Параметры форматирования")