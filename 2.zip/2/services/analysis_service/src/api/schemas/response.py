from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field

class AnalysisError(BaseModel):
    """Модель ошибки анализа"""
    code: str = Field(..., description="Код ошибки")
    message: str = Field(..., description="Сообщение об ошибке")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Дополнительные детали ошибки")

class AnalysisResult(BaseModel):
    """Модель результата анализа"""
    analyzer_type: str = Field(..., description="Тип анализатора")
    status: str = Field(..., description="Статус выполнения анализа")
    results: Dict[str, Any] = Field(..., description="Результаты анализа")
    errors: Optional[List[AnalysisError]] = Field(default=None, description="Ошибки при анализе")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Метаданные анализа")

class AnalysisResponse(BaseModel):
    """Модель ответа на запрос анализа"""
    request_id: str = Field(..., description="Идентификатор запроса")
    status: str = Field(..., description="Общий статус анализа")
    results: List[AnalysisResult] = Field(..., description="Результаты всех анализов")
    formatted_output: Optional[str] = Field(default=None, description="Отформатированный результат")
    errors: Optional[List[AnalysisError]] = Field(default=None, description="Общие ошибки")
    execution_time: float = Field(..., description="Время выполнения анализа в секундах")