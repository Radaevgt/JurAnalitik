from flask import Flask
from services.common.middleware.monitoring import setup_monitoring

def create_app() -> Flask:
    app = Flask(__name__)
    
    # Настройка мониторинга
    setup_monitoring(app)
    
    # Регистрация маршрутов
    from .routes import analyzers, formatters
    app.register_blueprint(analyzers.bp)
    app.register_blueprint(formatters.bp)
    
    return app