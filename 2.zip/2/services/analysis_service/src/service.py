from typing import Dict, Any, Optional, List
from services.common.logging.logger import ServiceLogger
from services.analysis_service.src.analyzers.base import BaseAnalyzer
from services.analysis_service.src.formatters.base import BaseFormatter
from services.analysis_service.src.core.base_repository import BaseRepository
from services.analysis_service.src.clients.prompt_service import PromptServiceClient
from services.analysis_service.src.clients.provider_service import ProviderServiceClient

class AnalysisService:
    """Основной сервис для анализа документов"""

    def __init__(self):
        """Инициализация сервиса"""
        self.logger = ServiceLogger(
            service_name="analysis_service",
            log_level="INFO",
            log_file="logs/analysis_service.log"
        )
        self.prompt_client = PromptServiceClient()
        self.provider_client = ProviderServiceClient()
        self.analyzers: Dict[str, BaseAnalyzer] = {}
        self.formatters: Dict[str, BaseFormatter] = {}
        self.repository: Optional[BaseRepository] = None

    async def initialize(self) -> None:
        """Инициализация сервиса при запуске"""
        try:
            self.logger.info("Initializing Analysis Service")
            await self.prompt_client.initialize()
            await self.provider_client.initialize()
            self.logger.info("Analysis Service initialized successfully")
        except Exception as e:
            self.logger.error(
                "Failed to initialize Analysis Service",
                exc_info=e
            )
            raise

    async def register_analyzer(
        self,
        analyzer_id: str,
        analyzer: BaseAnalyzer
    ) -> None:
        """Регистрация анализатора"""
        self.logger.info(f"Registering analyzer: {analyzer_id}")
        self.analyzers[analyzer_id] = analyzer

    async def register_formatter(
        self,
        format_id: str,
        formatter: BaseFormatter
    ) -> None:
        """Регистрация форматтера"""
        self.logger.info(f"Registering formatter: {format_id}")
        self.formatters[format_id] = formatter

    async def analyze_text(
        self,
        text: str,
        analyzer_id: str,
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Анализ текста с использованием указанного анализатора
        
        Args:
            text: Текст для анализа
            analyzer_id: Идентификатор анализатора
            options: Дополнительные параметры анализа
            
        Returns:
            Dict[str, Any]: Результаты анализа
        """
        try:
            self.logger.info(
                "Starting text analysis",
                analyzer_id=analyzer_id,
                text_length=len(text),
                options=options
            )

            # Проверяем наличие анализатора
            analyzer = self.analyzers.get(analyzer_id)
            if not analyzer:
                error_msg = f"Analyzer not found: {analyzer_id}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

            # Получаем промпт для анализа
            prompt = await self.prompt_client.process_prompt(
                prompt_type=f"{analyzer_id}_analysis",
                params={"text": text, **(options or {})}
            )
            self.logger.debug("Generated prompt for analysis", prompt_length=len(prompt))

            # Получаем результат от языковой модели
            model_response = await self.provider_client.get_completion(
                provider="deepseek",
                prompt=prompt
            )
            self.logger.debug(
                "Received model response",
                response_length=len(model_response["response"])
            )

            # Анализируем результат
            result = await analyzer.analyze(
                text=text,
                model_response=model_response["response"],
                options=options
            )

            # Если указан формат вывода
            if options and "format" in options:
                formatter = self.formatters.get(options["format"])
                if formatter:
                    result["formatted_output"] = await formatter.format(result)

            self.logger.info(
                "Analysis completed successfully",
                analyzer_id=analyzer_id,
                result_size=len(str(result))
            )
            return result

        except Exception as e:
            self.logger.error(
                "Error during text analysis",
                exc_info=e,
                analyzer_id=analyzer_id,
                text_length=len(text)
            )
            raise

    async def get_available_analyzers(self) -> List[str]:
        """Получение списка доступных анализаторов"""
        return list(self.analyzers.keys())

    async def get_available_formatters(self) -> List[str]:
        """Получение списка доступных форматтеров"""
        return list(self.formatters.keys())

    async def close(self) -> None:
        """Закрытие сервиса"""
        try:
            self.logger.info("Shutting down Analysis Service")
            await self.prompt_client.close()
            await self.provider_client.close()
            self.logger.info("Analysis Service shut down successfully")
        except Exception as e:
            self.logger.error(
                "Error during Analysis Service shutdown",
                exc_info=e
            )
            raise