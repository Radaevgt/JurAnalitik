"""
Analysis Service - Interfaces
Определяет основные интерфейсы для анализаторов и форматтеров
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from enum import Enum

class AnalysisType(Enum):
    """Типы анализа"""
    RISK = "risk"
    BUSINESS = "business" 
    COMPLIANCE = "compliance"
    TERMINOLOGY = "terminology"
    STRUCTURAL = "structural"

@dataclass
class AnalysisResult:
    """Результат анализа"""
    type: AnalysisType
    score: float
    findings: List[Dict[str, Any]]
    metadata: Optional[Dict[str, Any]] = None

class IAnalyzer(ABC):
    """Интерфейс анализатора"""
    
    @abstractmethod
    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ контента
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа
        """
        pass

    @abstractmethod
    def validate_result(self, result: AnalysisResult) -> bool:
        """
        Проверяет корректность результата анализа
        
        Args:
            result: Результат для проверки
            
        Returns:
            bool: True если результат валиден
        """
        pass

class IFormatter(ABC):
    """Интерфейс форматтера результатов"""
    
    @abstractmethod
    def format(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат
        """
        pass

class IRepository(ABC):
    """Интерфейс хранилища результатов анализа"""
    
    @abstractmethod
    async def save_result(self, result: AnalysisResult) -> str:
        """
        Сохраняет результат анализа
        
        Args:
            result: Результат для сохранения
            
        Returns:
            str: Идентификатор сохраненного результата
        """
        pass

    @abstractmethod
    async def get_result(self, result_id: str) -> Optional[AnalysisResult]:
        """
        Получает результат анализа по идентификатору
        
        Args:
            result_id: Идентификатор результата
            
        Returns:
            Optional[AnalysisResult]: Результат анализа или None если не найден
        """
        pass

    @abstractmethod
    async def list_results(self, analysis_type: Optional[AnalysisType] = None) -> List[AnalysisResult]:
        """
        Получает список результатов анализа
        
        Args:
            analysis_type: Опциональный фильтр по типу анализа
            
        Returns:
            List[AnalysisResult]: Список результатов анализа
        """
        pass

class IAnalysisService(ABC):
    """Интерфейс сервиса анализа"""
    
    @abstractmethod
    async def analyze(self, content: str, analysis_types: List[AnalysisType]) -> List[AnalysisResult]:
        """
        Выполняет анализ контента
        
        Args:
            content: Текст для анализа
            analysis_types: Список типов анализа для выполнения
            
        Returns:
            List[AnalysisResult]: Список результатов анализа
        """
        pass

    @abstractmethod
    def format_results(self, results: List[AnalysisResult], format_type: str) -> str:
        """
        Форматирует результаты анализа
        
        Args:
            results: Список результатов для форматирования
            format_type: Тип форматирования (markdown, html, json)
            
        Returns:
            str: Отформатированные результаты
        """
        pass