from functools import wraps
from typing import Any, Callable, Optional
import inspect
from .cache import cache

def cached(ttl: Optional[int] = None) -> Callable:
    """
    Декоратор для кэширования результатов функций.
    
    Args:
        ttl: Время жизни кэша в секундах. Если не указано, используется значение из конфигурации.
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Получаем имена параметров функции
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Генерируем ключ кэша
            cache_key = cache.generate_key(
                func.__module__,
                func.__name__,
                *bound_args.args,
                **bound_args.kwargs
            )
            
            # Пытаемся получить результат из кэша
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Если в кэше нет, вычисляем результат
            result = await func(*args, **kwargs)
            
            # Сохраняем результат в кэш
            cache.set(cache_key, result)
            
            return result
            
        return wrapper
    return decorator

def invalidate_cache(func: Callable) -> Callable:
    """
    Декоратор для инвалидации кэша при изменении данных.
    Очищает весь кэш после выполнения функции.
    """
    @wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        result = await func(*args, **kwargs)
        cache.clear()
        return result
    return wrapper