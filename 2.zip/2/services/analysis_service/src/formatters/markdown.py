"""
Analysis Service - Markdown Formatter
Форматтер для вывода результатов анализа в формате Markdown
"""
from typing import List, Dict, Any

from ..core.base_formatter import BaseFormatter
from ..interfaces import AnalysisResult

class MarkdownFormatter(BaseFormatter):
    """Форматтер для вывода результатов в формате Markdown"""

    def __init__(self):
        """Инициализация Markdown форматтера"""
        super().__init__()
        self._default_title = "# Результаты анализа"

    def _format_result(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа в Markdown
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат в формате Markdown
        """
        lines = [
            self._default_title,
            "",
            f"## Тип анализа: {result.type.value}",
            "",
            f"### Общая оценка: {self._format_score(result.score)}",
            "",
            "### Основные находки:"
        ]

        # Группируем находки по типу
        findings_by_type: Dict[str, List[Dict[str, Any]]] = {}
        for finding in result.findings:
            finding_type = finding.get("type", "other")
            if finding_type not in findings_by_type:
                findings_by_type[finding_type] = []
            findings_by_type[finding_type].append(finding)

        # Форматируем находки по группам
        for finding_type, findings in findings_by_type.items():
            lines.extend([
                "",
                f"#### {finding_type.capitalize()}:",
                ""
            ])
            lines.extend(self._format_findings(findings))

        # Добавляем метаданные, если они есть
        if result.metadata:
            lines.extend([
                "",
                "### Дополнительная информация:",
                ""
            ])
            lines.extend(self._format_metadata(result.metadata))

        return "\n".join(lines)

    def _format_finding(self, finding: Dict[str, Any]) -> str:
        """
        Форматирует отдельную находку в Markdown
        
        Args:
            finding: Находка для форматирования
            
        Returns:
            str: Отформатированная находка
        """
        lines = []
        
        # Основная информация
        if "pattern" in finding and "match" in finding:
            lines.append(f"- Найдено совпадение `{finding['match']}` по шаблону `{finding['pattern']}`")
        elif "term" in finding:
            lines.append(f"- Термин: `{finding['term']}`")
        elif "name" in finding:
            lines.append(f"- Название: `{finding['name']}`")
        else:
            lines.append("- " + str(finding))

        # Позиция в тексте
        if "position" in finding:
            lines.append(f"  - Позиция: {finding['position']}")

        # Дополнительные детали
        if "details" in finding:
            lines.append(f"  - Детали: {finding['details']}")
        if "variant" in finding:
            lines.append(f"  - Вариант: `{finding['variant']}`")

        return "\n".join(lines)

    def _format_metadata_value(self, value: Any) -> str:
        """
        Форматирует значение метаданных в Markdown
        
        Args:
            value: Значение для форматирования
            
        Returns:
            str: Отформатированное значение
        """
        if isinstance(value, dict):
            return "\n    " + "\n    ".join(
                f"- {k}: {self._format_metadata_value(v)}"
                for k, v in value.items()
            )
        elif isinstance(value, list):
            return "\n    " + "\n    ".join(
                f"- {self._format_metadata_value(item)}"
                for item in value
            )
        elif isinstance(value, float):
            return f"{value:.2%}" if 0 <= value <= 1 else f"{value:.2f}"
        else:
            return str(value)

    def _format_metadata(self, metadata: Dict[str, Any]) -> List[str]:
        """
        Форматирует метаданные в Markdown
        
        Args:
            metadata: Метаданные для форматирования
            
        Returns:
            List[str]: Список отформатированных строк метаданных
        """
        lines = []
        for key, value in metadata.items():
            formatted_value = self._format_metadata_value(value)
            if "\n" in formatted_value:
                lines.append(f"- **{key}**:{formatted_value}")
            else:
                lines.append(f"- **{key}**: {formatted_value}")
        return lines