"""
Analysis Service - Base Formatter
Базовый класс для всех форматтеров результатов анализа
"""
from abc import abstractmethod
from typing import Dict, Any, List

from ..interfaces import IFormatter, AnalysisResult

class BaseFormatter(IFormatter):
    """
    Базовый класс форматтера, предоставляющий общую функциональность
    """
    
    def __init__(self):
        """Инициализация форматтера"""
        self._templates: Dict[str, str] = {}
        self._init_templates()

    @abstractmethod
    def _init_templates(self) -> None:
        """
        Инициализирует шаблоны для форматирования.
        Должен быть реализован в подклассах.
        """
        pass

    def format(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат
        """
        # Форматируем основную информацию
        formatted = self._format_header(result)
        
        # Добавляем метрики
        formatted += self._format_metrics(result)
        
        # Добавляем находки
        formatted += self._format_findings(result.findings)
        
        # Добавляем итоговую информацию
        formatted += self._format_footer(result)
        
        return formatted

    @abstractmethod
    def _format_header(self, result: AnalysisResult) -> str:
        """
        Форматирует заголовок результата
        
        Args:
            result: Результат анализа
            
        Returns:
            str: Отформатированный заголовок
        """
        pass

    @abstractmethod
    def _format_metrics(self, result: AnalysisResult) -> str:
        """
        Форматирует метрики анализа
        
        Args:
            result: Результат анализа
            
        Returns:
            str: Отформатированные метрики
        """
        pass

    @abstractmethod
    def _format_findings(self, findings: List[Dict[str, Any]]) -> str:
        """
        Форматирует список находок
        
        Args:
            findings: Список находок для форматирования
            
        Returns:
            str: Отформатированные находки
        """
        pass

    @abstractmethod
    def _format_footer(self, result: AnalysisResult) -> str:
        """
        Форматирует подвал результата
        
        Args:
            result: Результат анализа
            
        Returns:
            str: Отформатированный подвал
        """
        pass

    def _escape_special_chars(self, text: str) -> str:
        """
        Экранирует специальные символы в зависимости от формата
        
        Args:
            text: Текст для экранирования
            
        Returns:
            str: Текст с экранированными символами
        """
        return text

    def _format_score(self, score: float) -> str:
        """
        Форматирует числовой скор в процентный формат
        
        Args:
            score: Скор от 0 до 1
            
        Returns:
            str: Отформатированный скор в виде процентов
        """
        return f"{score * 100:.1f}%"