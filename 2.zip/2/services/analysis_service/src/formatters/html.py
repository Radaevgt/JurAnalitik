"""
Analysis Service - HTML Formatter
Форматтер для вывода результатов анализа в формате HTML
"""
from typing import List, Dict, Any
import html

from ..core.base_formatter import BaseFormatter
from ..interfaces import AnalysisResult

class HTMLFormatter(BaseFormatter):
    """Форматтер для вывода результатов в формате HTML"""

    def __init__(self):
        """Инициализация HTML форматтера"""
        super().__init__()
        self._default_title = "Результаты анализа"
        
        # CSS стили для оформления
        self._styles = """
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
            h1 { color: #2c3e50; }
            h2 { color: #34495e; margin-top: 20px; }
            h3 { color: #7f8c8d; }
            .score { font-size: 1.2em; font-weight: bold; }
            .finding { margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 4px; }
            .finding-type { color: #2980b9; }
            .metadata { color: #7f8c8d; font-size: 0.9em; }
            .code { font-family: monospace; background: #f1f1f1; padding: 2px 4px; border-radius: 2px; }
            .position { color: #95a5a6; }
        </style>
        """

    def _format_result(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа в HTML
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат в формате HTML
        """
        # Группируем находки по типу
        findings_by_type: Dict[str, List[Dict[str, Any]]] = {}
        for finding in result.findings:
            finding_type = finding.get("type", "other")
            if finding_type not in findings_by_type:
                findings_by_type[finding_type] = []
            findings_by_type[finding_type].append(finding)

        # Формируем HTML
        html_parts = [
            "<!DOCTYPE html>",
            "<html>",
            "<head>",
            "<meta charset='utf-8'>",
            f"<title>{html.escape(self._default_title)}</title>",
            self._styles,
            "</head>",
            "<body>",
            f"<h1>{html.escape(self._default_title)}</h1>",
            f"<h2>Тип анализа: {html.escape(result.type.value)}</h2>",
            "<div class='score'>",
            f"Общая оценка: {self._format_score(result.score)}",
            "</div>",
            "<h2>Основные находки:</h2>"
        ]

        # Добавляем находки по группам
        for finding_type, findings in findings_by_type.items():
            html_parts.extend([
                f"<h3 class='finding-type'>{html.escape(finding_type.capitalize())}</h3>",
                "<div class='findings'>"
            ])
            html_parts.extend(self._format_findings(findings))
            html_parts.append("</div>")

        # Добавляем метаданные
        if result.metadata:
            html_parts.extend([
                "<h2>Дополнительная информация:</h2>",
                "<div class='metadata'>"
            ])
            html_parts.extend(self._format_metadata(result.metadata))
            html_parts.append("</div>")

        html_parts.extend([
            "</body>",
            "</html>"
        ])

        return "\n".join(html_parts)

    def _format_finding(self, finding: Dict[str, Any]) -> str:
        """
        Форматирует отдельную находку в HTML
        
        Args:
            finding: Находка для форматирования
            
        Returns:
            str: Отформатированная находка в HTML
        """
        parts = ["<div class='finding'>"]
        
        # Основная информация
        if "pattern" in finding and "match" in finding:
            parts.append(
                f"Найдено совпадение <code class='code'>{html.escape(finding['match'])}</code> "
                f"по шаблону <code class='code'>{html.escape(finding['pattern'])}</code>"
            )
        elif "term" in finding:
            parts.append(f"Термин: <code class='code'>{html.escape(finding['term'])}</code>")
        elif "name" in finding:
            parts.append(f"Название: <code class='code'>{html.escape(finding['name'])}</code>")
        else:
            parts.append(html.escape(str(finding)))

        # Позиция в тексте
        if "position" in finding:
            parts.append(
                f"<div class='position'>Позиция: {finding['position']}</div>"
            )

        # Дополнительные детали
        if "details" in finding:
            parts.append(
                f"<div>Детали: {html.escape(finding['details'])}</div>"
            )
        if "variant" in finding:
            parts.append(
                f"<div>Вариант: <code class='code'>{html.escape(finding['variant'])}</code></div>"
            )

        parts.append("</div>")
        return "\n".join(parts)

    def _format_metadata_value(self, value: Any) -> str:
        """
        Форматирует значение метаданных в HTML
        
        Args:
            value: Значение для форматирования
            
        Returns:
            str: Отформатированное значение в HTML
        """
        if isinstance(value, dict):
            return "<ul>" + "".join(
                f"<li>{html.escape(str(k))}: {self._format_metadata_value(v)}</li>"
                for k, v in value.items()
            ) + "</ul>"
        elif isinstance(value, list):
            return "<ul>" + "".join(
                f"<li>{self._format_metadata_value(item)}</li>"
                for item in value
            ) + "</ul>"
        elif isinstance(value, float):
            formatted = f"{value:.2%}" if 0 <= value <= 1 else f"{value:.2f}"
            return html.escape(formatted)
        else:
            return html.escape(str(value))

    def _format_metadata(self, metadata: Dict[str, Any]) -> List[str]:
        """
        Форматирует метаданные в HTML
        
        Args:
            metadata: Метаданные для форматирования
            
        Returns:
            List[str]: Список отформатированных строк метаданных в HTML
        """
        return [
            "<dl>" +
            "".join(
                f"<dt>{html.escape(key)}</dt><dd>{self._format_metadata_value(value)}</dd>"
                for key, value in metadata.items()
            ) +
            "</dl>"
        ]