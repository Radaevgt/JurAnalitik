"""
Analysis Service - JSON Formatter
Форматтер для вывода результатов анализа в формате JSON
"""
from typing import Dict, Any
import json
from datetime import datetime

from ..core.base_formatter import BaseFormatter
from ..interfaces import AnalysisResult

class JSONFormatter(BaseFormatter):
    """Форматтер для вывода результатов в формате JSON"""

    def __init__(self):
        """Инициализация JSON форматтера"""
        super().__init__()
        self._indent = 2
        self._ensure_ascii = False

    def _format_result(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа в JSON
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат в формате JSON
        """
        # Создаем базовую структуру JSON
        json_data = {
            "type": result.type.value,
            "score": result.score,
            "score_formatted": self._format_score(result.score),
            "timestamp": datetime.now().isoformat(),
            "findings": self._format_findings_json(result.findings)
        }

        # Добавляем метаданные, если они есть
        if result.metadata:
            json_data["metadata"] = self._format_metadata_json(result.metadata)

        # Форматируем с отступами для читаемости
        return json.dumps(
            json_data,
            indent=self._indent,
            ensure_ascii=self._ensure_ascii,
            default=str  # Для сериализации нестандартных типов
        )

    def _format_findings_json(self, findings: list) -> list:
        """
        Форматирует находки для JSON
        
        Args:
            findings: Список находок
            
        Returns:
            list: Отформатированные находки
        """
        formatted_findings = []
        
        # Группируем находки по типу
        findings_by_type: Dict[str, list] = {}
        for finding in findings:
            finding_type = finding.get("type", "other")
            if finding_type not in findings_by_type:
                findings_by_type[finding_type] = []
            findings_by_type[finding_type].append(finding)

        # Форматируем каждую группу
        for finding_type, type_findings in findings_by_type.items():
            group = {
                "type": finding_type,
                "count": len(type_findings),
                "items": []
            }
            
            for finding in type_findings:
                formatted_finding = self._format_finding_json(finding)
                group["items"].append(formatted_finding)
                
            formatted_findings.append(group)

        return formatted_findings

    def _format_finding_json(self, finding: Dict[str, Any]) -> Dict[str, Any]:
        """
        Форматирует отдельную находку для JSON
        
        Args:
            finding: Находка для форматирования
            
        Returns:
            Dict[str, Any]: Отформатированная находка
        """
        formatted = {}
        
        # Копируем базовые поля
        for key in ["type", "position", "details"]:
            if key in finding:
                formatted[key] = finding[key]

        # Форматируем специфичные поля
        if "pattern" in finding and "match" in finding:
            formatted["match"] = {
                "pattern": finding["pattern"],
                "text": finding["match"]
            }
        if "term" in finding:
            formatted["term"] = finding["term"]
        if "name" in finding:
            formatted["name"] = finding["name"]
        if "variant" in finding:
            formatted["variant"] = finding["variant"]

        return formatted

    def _format_metadata_json(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Форматирует метаданные для JSON
        
        Args:
            metadata: Метаданные для форматирования
            
        Returns:
            Dict[str, Any]: Отформатированные метаданные
        """
        formatted = {}
        
        for key, value in metadata.items():
            if isinstance(value, dict):
                formatted[key] = self._format_metadata_json(value)
            elif isinstance(value, list):
                formatted[key] = [
                    self._format_metadata_json(item) if isinstance(item, dict) else item
                    for item in value
                ]
            elif isinstance(value, float) and 0 <= value <= 1:
                formatted[key] = {
                    "value": value,
                    "formatted": self._format_score(value)
                }
            else:
                formatted[key] = value
                
        return formatted