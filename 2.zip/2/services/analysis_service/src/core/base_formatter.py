"""
Analysis Service - Base Formatter
Базовый абстрактный класс для форматтеров
"""
from abc import abstractmethod
from typing import List, Dict, Any

from ..interfaces import IFormatter, AnalysisResult

class BaseFormatter(IFormatter):
    """Базовый класс для всех форматтеров результатов анализа"""

    def __init__(self):
        """Инициализация форматтера"""
        self._default_title = "Результаты анализа"
        self._default_score_format = "{:.2%}"

    def format(self, result: AnalysisResult) -> str:
        """
        Форматирует результат анализа
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат
        """
        if not isinstance(result, AnalysisResult):
            raise ValueError("Invalid result type")

        return self._format_result(result)

    @abstractmethod
    def _format_result(self, result: AnalysisResult) -> str:
        """
        Реализация форматирования конкретным форматтером
        
        Args:
            result: Результат для форматирования
            
        Returns:
            str: Отформатированный результат
        """
        pass

    def _format_score(self, score: float) -> str:
        """
        Форматирует числовую оценку
        
        Args:
            score: Оценка для форматирования
            
        Returns:
            str: Отформатированная оценка
        """
        return self._default_score_format.format(score)

    def _format_findings(self, findings: List[Dict[str, Any]]) -> List[str]:
        """
        Форматирует список находок
        
        Args:
            findings: Список находок для форматирования
            
        Returns:
            List[str]: Список отформатированных находок
        """
        formatted = []
        for finding in findings:
            if isinstance(finding, dict):
                formatted.append(self._format_finding(finding))
        return formatted

    @abstractmethod
    def _format_finding(self, finding: Dict[str, Any]) -> str:
        """
        Форматирует отдельную находку
        
        Args:
            finding: Находка для форматирования
            
        Returns:
            str: Отформатированная находка
        """
        pass

    def _format_metadata(self, metadata: Dict[str, Any]) -> List[str]:
        """
        Форматирует метаданные
        
        Args:
            metadata: Метаданные для форматирования
            
        Returns:
            List[str]: Список отформатированных метаданных
        """
        if not metadata:
            return []
            
        formatted = []
        for key, value in metadata.items():
            formatted.append(f"{key}: {value}")
        return formatted