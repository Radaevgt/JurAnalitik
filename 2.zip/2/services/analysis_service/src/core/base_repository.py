"""
Analysis Service - Base Repository
Базовый абстрактный класс для хранилища результатов
"""
from typing import Dict, List, Optional
import uuid

from ..interfaces import IRepository, AnalysisResult, AnalysisType

class BaseRepository(IRepository):
    """Базовый класс для хранилища результатов анализа"""

    def __init__(self):
        """Инициализация хранилища"""
        self._results: Dict[str, AnalysisResult] = {}

    async def save_result(self, result: AnalysisResult) -> str:
        """
        Сохраняет результат анализа
        
        Args:
            result: Результат для сохранения
            
        Returns:
            str: Идентификатор сохраненного результата
        """
        if not isinstance(result, AnalysisResult):
            raise ValueError("Invalid result type")

        result_id = str(uuid.uuid4())
        self._results[result_id] = result
        return result_id

    async def get_result(self, result_id: str) -> Optional[AnalysisResult]:
        """
        Получает результат анализа по идентификатору
        
        Args:
            result_id: Идентификатор результата
            
        Returns:
            Optional[AnalysisResult]: Результат анализа или None если не найден
        """
        return self._results.get(result_id)

    async def list_results(self, analysis_type: Optional[AnalysisType] = None) -> List[AnalysisResult]:
        """
        Получает список результатов анализа
        
        Args:
            analysis_type: Опциональный фильтр по типу анализа
            
        Returns:
            List[AnalysisResult]: Список результатов анализа
        """
        if analysis_type is None:
            return list(self._results.values())
            
        return [
            result for result in self._results.values() 
            if result.type == analysis_type
        ]

    def _validate_result_id(self, result_id: str) -> bool:
        """
        Проверяет корректность идентификатора результата
        
        Args:
            result_id: Идентификатор для проверки
            
        Returns:
            bool: True если идентификатор валиден
        """
        try:
            uuid.UUID(result_id)
            return True
        except ValueError:
            return False