"""
Analysis Service - Base Analyzer
Базовый абстрактный класс для анализаторов
"""
from abc import abstractmethod
from typing import Dict, Any, List

from ..interfaces import IAnalyzer, AnalysisResult, AnalysisType

class BaseAnalyzer(IAnalyzer):
    """Базовый класс для всех анализаторов"""

    def __init__(self, analysis_type: AnalysisType):
        """
        Инициализация анализатора
        
        Args:
            analysis_type: Тип анализа
        """
        self._type = analysis_type
        self._min_score = 0.0
        self._max_score = 1.0

    @property
    def analysis_type(self) -> AnalysisType:
        """Получить тип анализа"""
        return self._type

    def validate_result(self, result: AnalysisResult) -> bool:
        """
        Проверяет корректность результата анализа
        
        Args:
            result: Результат для проверки
            
        Returns:
            bool: True если результат валиден
        """
        if not isinstance(result, AnalysisResult):
            return False
            
        if result.type != self._type:
            return False
            
        if not self._min_score <= result.score <= self._max_score:
            return False
            
        if not isinstance(result.findings, list):
            return False
            
        return True

    @abstractmethod
    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ контента
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа
        """
        pass

    def _create_result(self, score: float, findings: List[Dict[str, Any]], metadata: Dict[str, Any] = None) -> AnalysisResult:
        """
        Создает результат анализа с валидацией
        
        Args:
            score: Оценка результата (от 0 до 1)
            findings: Список находок
            metadata: Дополнительные метаданные
            
        Returns:
            AnalysisResult: Валидированный результат анализа
        """
        result = AnalysisResult(
            type=self._type,
            score=max(min(score, self._max_score), self._min_score),
            findings=findings,
            metadata=metadata
        )
        
        if not self.validate_result(result):
            raise ValueError("Invalid analysis result")
            
        return result