from typing import Dict, Any, Optional
from .base_client import BaseClient, RetryConfig, CircuitBreaker

class PromptServiceClient(BaseClient):
    """
    Клиент для взаимодействия с сервисом промптов.
    Предоставляет методы для получения и обработки промптов для различных типов анализа.
    """
    
    def __init__(
        self,
        base_url: str,
        retry_config: Optional[RetryConfig] = None,
        circuit_breaker: Optional[CircuitBreaker] = None
    ):
        super().__init__(base_url, retry_config, circuit_breaker)
        
    async def get_risk_analysis_prompt(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Получить промпт для анализа рисков.
        
        Args:
            context: Контекст для генерации промпта
            
        Returns:
            Dict[str, Any]: Сгенерированный промпт и метаданные
        """
        return await self.post('prompts/risk-analysis', json=context)
        
    async def get_business_analysis_prompt(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Получить промпт для бизнес-анализа.
        
        Args:
            context: Контекст для генерации промпта
            
        Returns:
            Dict[str, Any]: Сгенерированный промпт и метаданные
        """
        return await self.post('prompts/business-analysis', json=context)
        
    async def get_compliance_analysis_prompt(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Получить промпт для анализа соответствия требованиям.
        
        Args:
            context: Контекст для генерации промпта
            
        Returns:
            Dict[str, Any]: Сгенерированный промпт и метаданные
        """
        return await self.post('prompts/compliance-analysis', json=context)
        
    async def get_terminology_analysis_prompt(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Получить промпт для анализа терминологии.
        
        Args:
            context: Контекст для генерации промпта
            
        Returns:
            Dict[str, Any]: Сгенерированный промпт и метаданные
        """
        return await self.post('prompts/terminology-analysis', json=context)
        
    async def get_structural_analysis_prompt(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Получить промпт для структурного анализа.
        
        Args:
            context: Контекст для генерации промпта
            
        Returns:
            Dict[str, Any]: Сгенерированный промпт и метаданные
        """
        return await self.post('prompts/structural-analysis', json=context)