from abc import ABC, abstractmethod
import aiohttp
import asyncio
from typing import Any, Dict, Optional
from datetime import datetime, timedelta

class RetryConfig:
    """Конфигурация механизма повторных попыток"""
    def __init__(
        self,
        max_retries: int = 3,
        delay: float = 1.0,
        max_delay: float = 10.0,
        exponential_base: float = 2.0
    ):
        self.max_retries = max_retries
        self.delay = delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base

class CircuitBreaker:
    """
    Реализация паттерна Circuit Breaker для защиты от каскадных отказов
    """
    def __init__(
        self,
        failure_threshold: int = 5,
        reset_timeout: float = 60.0
    ):
        self._failure_count = 0
        self._failure_threshold = failure_threshold
        self._reset_timeout = reset_timeout
        self._last_failure_time: Optional[datetime] = None
        self._is_open = False

    def record_failure(self) -> None:
        """Зафиксировать ошибку"""
        self._failure_count += 1
        self._last_failure_time = datetime.now()
        
        if self._failure_count >= self._failure_threshold:
            self._is_open = True

    def record_success(self) -> None:
        """Зафиксировать успешный запрос"""
        self._failure_count = 0
        self._is_open = False
        self._last_failure_time = None

    def can_execute(self) -> bool:
        """Проверить возможность выполнения запроса"""
        if not self._is_open:
            return True
            
        if self._last_failure_time is None:
            return True
            
        if datetime.now() - self._last_failure_time > timedelta(seconds=self._reset_timeout):
            self._is_open = False
            self._failure_count = 0
            return True
            
        return False

class BaseClient(ABC):
    """
    Базовый класс для HTTP клиентов с поддержкой retry и circuit breaker
    """
    
    def __init__(
        self,
        base_url: str,
        retry_config: Optional[RetryConfig] = None,
        circuit_breaker: Optional[CircuitBreaker] = None
    ):
        self._base_url = base_url.rstrip('/')
        self._retry_config = retry_config or RetryConfig()
        self._circuit_breaker = circuit_breaker or CircuitBreaker()
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """Получить или создать сессию"""
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self) -> None:
        """Закрыть сессию"""
        if self._session:
            await self._session.close()
            self._session = None

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs
    ) -> Any:
        """
        Выполнить HTTP запрос с поддержкой retry и circuit breaker
        
        Args:
            method: HTTP метод
            path: Путь запроса
            **kwargs: Дополнительные параметры запроса
            
        Returns:
            Any: Результат запроса
            
        Raises:
            Exception: При ошибке запроса
        """
        if not self._circuit_breaker.can_execute():
            raise Exception("Circuit breaker is open")

        url = f"{self._base_url}/{path.lstrip('/')}"
        session = await self._get_session()

        for attempt in range(self._retry_config.max_retries):
            try:
                async with session.request(method, url, **kwargs) as response:
                    response.raise_for_status()
                    self._circuit_breaker.record_success()
                    return await response.json()
                    
            except Exception as e:
                self._circuit_breaker.record_failure()
                
                if attempt == self._retry_config.max_retries - 1:
                    raise
                    
                delay = min(
                    self._retry_config.delay * (self._retry_config.exponential_base ** attempt),
                    self._retry_config.max_delay
                )
                await asyncio.sleep(delay)

    async def get(self, path: str, **kwargs) -> Any:
        """GET запрос"""
        return await self._request('GET', path, **kwargs)

    async def post(self, path: str, **kwargs) -> Any:
        """POST запрос"""
        return await self._request('POST', path, **kwargs)

    async def put(self, path: str, **kwargs) -> Any:
        """PUT запрос"""
        return await self._request('PUT', path, **kwargs)

    async def delete(self, path: str, **kwargs) -> Any:
        """DELETE запрос"""
        return await self._request('DELETE', path, **kwargs)