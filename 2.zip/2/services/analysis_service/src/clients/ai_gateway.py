from typing import Dict, Any, Optional, List
from .base_client import BaseClient, RetryConfig, CircuitBreaker

class AIGatewayClient(BaseClient):
    """
    Клиент для взаимодействия с AI Gateway.
    Предоставляет единую точку доступа к различным AI сервисам.
    """
    
    def __init__(
        self,
        base_url: str,
        retry_config: Optional[RetryConfig] = None,
        circuit_breaker: Optional[CircuitBreaker] = None
    ):
        super().__init__(base_url, retry_config, circuit_breaker)
        
    async def get_services(self) -> List[Dict[str, Any]]:
        """
        Получить список доступных AI сервисов.
        
        Returns:
            List[Dict[str, Any]]: Список сервисов с их характеристиками
        """
        return await self.get('services')
        
    async def get_service_info(self, service_id: str) -> Dict[str, Any]:
        """
        Получить информацию о конкретном сервисе.
        
        Args:
            service_id: Идентификатор сервиса
            
        Returns:
            Dict[str, Any]: Информация о сервисе
        """
        return await self.get(f'services/{service_id}')
        
    async def process_request(
        self,
        service_id: str,
        request_data: Dict[str, Any],
        timeout: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Отправить запрос на обработку в выбранный сервис.
        
        Args:
            service_id: Идентификатор сервиса
            request_data: Данные запроса
            timeout: Таймаут ожидания ответа в секундах
            
        Returns:
            Dict[str, Any]: Результат обработки
        """
        return await self.post(
            f'services/{service_id}/process',
            json=request_data,
            timeout=timeout
        )
        
    async def get_request_status(self, request_id: str) -> Dict[str, Any]:
        """
        Получить статус запроса по его идентификатору.
        
        Args:
            request_id: Идентификатор запроса
            
        Returns:
            Dict[str, Any]: Статус и результаты обработки
        """
        return await self.get(f'requests/{request_id}')
        
    async def cancel_request(self, request_id: str) -> bool:
        """
        Отменить выполняющийся запрос.
        
        Args:
            request_id: Идентификатор запроса
            
        Returns:
            bool: True если успешно отменено
        """
        try:
            await self.delete(f'requests/{request_id}')
            return True
        except Exception:
            return False