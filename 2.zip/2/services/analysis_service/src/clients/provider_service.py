from typing import Dict, Any, Optional, List
from .base_client import BaseClient, RetryConfig, CircuitBreaker

class ProviderServiceClient(BaseClient):
    """
    Клиент для взаимодействия с сервисом провайдеров.
    Предоставляет методы для работы с различными AI провайдерами.
    """
    
    def __init__(
        self,
        base_url: str,
        retry_config: Optional[RetryConfig] = None,
        circuit_breaker: Optional[CircuitBreaker] = None
    ):
        super().__init__(base_url, retry_config, circuit_breaker)
        
    async def get_available_providers(self) -> List[Dict[str, Any]]:
        """
        Получить список доступных провайдеров.
        
        Returns:
            List[Dict[str, Any]]: Список провайдеров с их характеристиками
        """
        return await self.get('providers')
        
    async def get_provider_info(self, provider_id: str) -> Dict[str, Any]:
        """
        Получить информацию о конкретном провайдере.
        
        Args:
            provider_id: Идентификатор провайдера
            
        Returns:
            Dict[str, Any]: Информация о провайдере
        """
        return await self.get(f'providers/{provider_id}')
        
    async def analyze_text(
        self,
        provider_id: str,
        text: str,
        prompt: str,
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Отправить текст на анализ выбранному провайдеру.
        
        Args:
            provider_id: Идентификатор провайдера
            text: Текст для анализа
            prompt: Промпт для анализа
            options: Дополнительные параметры анализа
            
        Returns:
            Dict[str, Any]: Результат анализа
        """
        payload = {
            "text": text,
            "prompt": prompt,
            "options": options or {}
        }
        return await self.post(f'providers/{provider_id}/analyze', json=payload)
        
    async def get_analysis_status(self, analysis_id: str) -> Dict[str, Any]:
        """
        Получить статус анализа по его идентификатору.
        
        Args:
            analysis_id: Идентификатор анализа
            
        Returns:
            Dict[str, Any]: Статус и результаты анализа
        """
        return await self.get(f'analysis/{analysis_id}')
        
    async def cancel_analysis(self, analysis_id: str) -> bool:
        """
        Отменить выполняющийся анализ.
        
        Args:
            analysis_id: Идентификатор анализа
            
        Returns:
            bool: True если успешно отменено
        """
        try:
            await self.delete(f'analysis/{analysis_id}')
            return True
        except Exception:
            return False