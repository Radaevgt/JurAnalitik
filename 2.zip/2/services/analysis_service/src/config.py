import yaml
from typing import Dict, Any
from pathlib import Path

def load_config() -> Dict[str, Any]:
    """Загрузить конфигурацию из файла"""
    config_path = Path(__file__).parent.parent / "config" / "config.yaml"
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# Загружаем конфигурацию при импорте модуля
settings = load_config()