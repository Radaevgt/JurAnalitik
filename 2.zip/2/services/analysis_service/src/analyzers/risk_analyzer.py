"""
Analysis Service - Risk Analyzer
Анализатор рисков в юридических документах
"""
from typing import Dict, Any, List
import re

from ..core.base_analyzer import BaseAnalyzer
from ..interfaces import AnalysisType, AnalysisResult

class RiskAnalyzer(BaseAnalyzer):
    """Анализатор рисков в юридических документах"""

    def __init__(self):
        """Инициализация анализатора рисков"""
        super().__init__(AnalysisType.RISK)
        
        # Ключевые слова и фразы, указывающие на риски
        self._risk_patterns = [
            r"штраф",
            r"неустойка",
            r"ответственность",
            r"обязательство",
            r"нарушение",
            r"расторжение",
            r"отказ",
            r"претензия",
            r"санкция",
            r"спор"
        ]
        
        # Веса для разных типов рисков
        self._risk_weights = {
            "financial": 0.4,    # Финансовые риски
            "legal": 0.3,        # Юридические риски
            "operational": 0.2,  # Операционные риски
            "reputational": 0.1  # Репутационные риски
        }

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ рисков в тексте
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа рисков
        """
        if not content:
            return self._create_result(0.0, [], {"error": "Empty content"})

        # Анализ рисков по категориям
        findings = []
        risk_scores = {
            "financial": self._analyze_financial_risks(content, findings),
            "legal": self._analyze_legal_risks(content, findings),
            "operational": self._analyze_operational_risks(content, findings),
            "reputational": self._analyze_reputational_risks(content, findings)
        }

        # Расчет общего уровня риска с учетом весов
        total_score = sum(
            score * self._risk_weights[risk_type]
            for risk_type, score in risk_scores.items()
        )

        metadata = {
            "risk_scores": risk_scores,
            "risk_weights": self._risk_weights
        }

        return self._create_result(total_score, findings, metadata)

    def _analyze_financial_risks(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ финансовых рисков"""
        financial_patterns = [
            r"штраф\w*",
            r"неустойка\w*",
            r"пен[яи]\w*",
            r"возмещени[еюя]\w*",
            r"убыт[окa]\w*"
        ]
        
        score = 0.0
        for pattern in financial_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "financial",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1  # Увеличиваем оценку риска за каждое совпадение
                
        return min(score, 1.0)  # Нормализация оценки

    def _analyze_legal_risks(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ юридических рисков"""
        legal_patterns = [
            r"нарушени[еюя]\w*",
            r"ответственност[ьию]\w*",
            r"претензи[яию]\w*",
            r"спор\w*",
            r"суд\w*"
        ]
        
        score = 0.0
        for pattern in legal_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "legal",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_operational_risks(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ операционных рисков"""
        operational_patterns = [
            r"срок\w*",
            r"просрочк\w*",
            r"задержк\w*",
            r"неисполнени[еюя]\w*",
            r"отказ\w*"
        ]
        
        score = 0.0
        for pattern in operational_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "operational",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_reputational_risks(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ репутационных рисков"""
        reputational_patterns = [
            r"конфиденциальност[ьию]\w*",
            r"разглашени[еюя]\w*",
            r"репутаци[яию]\w*",
            r"имидж\w*",
            r"бренд\w*"
        ]
        
        score = 0.0
        for pattern in reputational_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "reputational",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)