"""
Analysis Service - Base Analyzer
Базовый класс для всех анализаторов
"""
from abc import abstractmethod
from typing import Dict, Any, List

from ..interfaces import IAnalyzer, AnalysisResult, AnalysisType

class BaseAnalyzer(IAnalyzer):
    """
    Базовый класс анализатора, предоставляющий общую функциональность
    """
    
    def __init__(self, analysis_type: AnalysisType):
        """
        Инициализация анализатора
        
        Args:
            analysis_type: Тип анализа
        """
        self._type = analysis_type
        self._metrics: Dict[str, float] = {}

    @abstractmethod
    async def _perform_analysis(self, content: str) -> Dict[str, Any]:
        """
        Выполняет конкретный анализ. Должен быть реализован в подклассах.
        
        Args:
            content: Текст для анализа
            
        Returns:
            Dict[str, Any]: Результаты анализа
        """
        pass

    @abstractmethod
    def _calculate_score(self, findings: Dict[str, Any]) -> float:
        """
        Рассчитывает общий скор на основе результатов анализа
        
        Args:
            findings: Результаты анализа
            
        Returns:
            float: Скор от 0 до 1
        """
        pass

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ контента
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа
        """
        # Выполняем анализ
        findings = await self._perform_analysis(content)
        
        # Рассчитываем скор
        score = self._calculate_score(findings)
        
        # Формируем список находок
        formatted_findings = self._format_findings(findings)
        
        # Создаем результат
        result = AnalysisResult(
            type=self._type,
            score=score,
            findings=formatted_findings,
            metadata={"metrics": self._metrics}
        )
        
        # Проверяем валидность
        if not self.validate_result(result):
            raise ValueError("Invalid analysis result")
            
        return result

    def validate_result(self, result: AnalysisResult) -> bool:
        """
        Проверяет корректность результата анализа
        
        Args:
            result: Результат для проверки
            
        Returns:
            bool: True если результат валиден
        """
        if not isinstance(result.score, float):
            return False
        if result.score < 0 or result.score > 1:
            return False
        if not isinstance(result.findings, list):
            return False
        return True

    def _format_findings(self, findings: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Форматирует находки в список
        
        Args:
            findings: Результаты анализа
            
        Returns:
            List[Dict[str, Any]]: Отформатированный список находок
        """
        formatted = []
        for key, value in findings.items():
            if isinstance(value, dict):
                formatted.append({"type": key, **value})
            else:
                formatted.append({"type": key, "value": value})
        return formatted

    def update_metrics(self, metric_name: str, value: float) -> None:
        """
        Обновляет метрики качества анализа
        
        Args:
            metric_name: Название метрики
            value: Значение метрики
        """
        self._metrics[metric_name] = value