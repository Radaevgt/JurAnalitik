"""
Analysis Service - Compliance Analyzer
Анализатор соответствия нормативным требованиям
"""
from typing import Dict, Any, List
import re

from ..core.base_analyzer import BaseAnalyzer
from ..interfaces import AnalysisType, AnalysisResult

class ComplianceAnalyzer(BaseAnalyzer):
    """Анализатор соответствия нормативным требованиям"""

    def __init__(self):
        """Инициализация анализатора соответствия"""
        super().__init__(AnalysisType.COMPLIANCE)
        
        # Веса для разных аспектов анализа соответствия
        self._aspect_weights = {
            "legal_references": 0.3,    # Ссылки на законодательство
            "requirements": 0.3,        # Обязательные требования
            "restrictions": 0.2,        # Ограничения
            "procedures": 0.2           # Процедуры соответствия
        }

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ соответствия нормативным требованиям
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа соответствия
        """
        if not content:
            return self._create_result(0.0, [], {"error": "Empty content"})

        # Анализ различных аспектов соответствия
        findings = []
        aspect_scores = {
            "legal_references": self._analyze_legal_references(content, findings),
            "requirements": self._analyze_requirements(content, findings),
            "restrictions": self._analyze_restrictions(content, findings),
            "procedures": self._analyze_procedures(content, findings)
        }

        # Расчет общей оценки с учетом весов
        total_score = sum(
            score * self._aspect_weights[aspect]
            for aspect, score in aspect_scores.items()
        )

        metadata = {
            "aspect_scores": aspect_scores,
            "aspect_weights": self._aspect_weights
        }

        return self._create_result(total_score, findings, metadata)

    def _analyze_legal_references(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ ссылок на законодательство"""
        legal_patterns = [
            r"федеральн\w+\s+закон\w*",
            r"закон\w*\s+рф",
            r"кодекс\w*",
            r"статья\s+\d+",
            r"пункт\s+\d+",
            r"гост\w*",
            r"снип\w*"
        ]
        
        score = 0.0
        for pattern in legal_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "legal_references",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_requirements(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ обязательных требований"""
        requirement_patterns = [
            r"требовани[еюя]\w*",
            r"обязательн\w+",
            r"необходим\w+",
            r"должен\s+\w+",
            r"следует\s+\w+"
        ]
        
        score = 0.0
        for pattern in requirement_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "requirements",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_restrictions(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ ограничений"""
        restriction_patterns = [
            r"запрещ\w+",
            r"не\s+допуска\w+",
            r"ограничени[еюя]\w*",
            r"исключ\w+",
            r"только\s+\w+"
        ]
        
        score = 0.0
        for pattern in restriction_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "restrictions",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_procedures(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ процедур соответствия"""
        procedure_patterns = [
            r"порядок\s+\w+",
            r"процедур[аы]\w*",
            r"регламент\w*",
            r"правил[оа]\w*",
            r"методик[аи]\w*"
        ]
        
        score = 0.0
        for pattern in procedure_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "procedures",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)