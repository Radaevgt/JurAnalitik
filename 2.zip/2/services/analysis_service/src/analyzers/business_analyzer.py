"""
Analysis Service - Business Analyzer
Анализатор бизнес-аспектов в юридических документах
"""
from typing import Dict, Any, List
import re

from ..core.base_analyzer import BaseAnalyzer
from ..interfaces import AnalysisType, AnalysisResult

class BusinessAnalyzer(BaseAnalyzer):
    """Анализатор бизнес-аспектов в юридических документах"""

    def __init__(self):
        """Инициализация анализатора бизнес-аспектов"""
        super().__init__(AnalysisType.BUSINESS)
        
        # Веса для разных аспектов бизнес-анализа
        self._aspect_weights = {
            "financial_terms": 0.3,    # Финансовые условия
            "obligations": 0.3,        # Обязательства сторон
            "deadlines": 0.2,          # Сроки
            "conditions": 0.2          # Условия сделки
        }

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ бизнес-аспектов в тексте
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа бизнес-аспектов
        """
        if not content:
            return self._create_result(0.0, [], {"error": "Empty content"})

        # Анализ различных бизнес-аспектов
        findings = []
        aspect_scores = {
            "financial_terms": self._analyze_financial_terms(content, findings),
            "obligations": self._analyze_obligations(content, findings),
            "deadlines": self._analyze_deadlines(content, findings),
            "conditions": self._analyze_conditions(content, findings)
        }

        # Расчет общей оценки с учетом весов
        total_score = sum(
            score * self._aspect_weights[aspect]
            for aspect, score in aspect_scores.items()
        )

        metadata = {
            "aspect_scores": aspect_scores,
            "aspect_weights": self._aspect_weights
        }

        return self._create_result(total_score, findings, metadata)

    def _analyze_financial_terms(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ финансовых условий"""
        financial_patterns = [
            r"сумм[аеу]\w*",
            r"стоимост[ьию]\w*",
            r"цен[аеу]\w*",
            r"оплат[аеу]\w*",
            r"вознаграждени[еюя]\w*"
        ]
        
        score = 0.0
        for pattern in financial_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "financial_terms",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_obligations(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ обязательств сторон"""
        obligation_patterns = [
            r"обязан\w*",
            r"должен\w*",
            r"обязательств[оа]\w*",
            r"требовани[еюя]\w*",
            r"исполнени[еюя]\w*"
        ]
        
        score = 0.0
        for pattern in obligation_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "obligations",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_deadlines(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ сроков"""
        deadline_patterns = [
            r"срок\w*",
            r"дат[аеу]\w*",
            r"период\w*",
            r"течени[еи]\w*",
            r"календарн\w*"
        ]
        
        score = 0.0
        for pattern in deadline_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "deadlines",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_conditions(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ условий сделки"""
        condition_patterns = [
            r"услови[еюя]\w*",
            r"порядок\w*",
            r"случа[еюй]\w*",
            r"при\s+\w+",
            r"если\s+\w+"
        ]
        
        score = 0.0
        for pattern in condition_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "conditions",
                    "pattern": pattern,
                    "match": match.group(),
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)