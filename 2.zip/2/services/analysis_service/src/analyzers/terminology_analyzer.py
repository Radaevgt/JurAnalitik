"""
Analysis Service - Terminology Analyzer
Анализатор терминологии в юридических документах
"""
from typing import Dict, Any, List
import re

from ..core.base_analyzer import BaseAnalyzer
from ..interfaces import AnalysisType, AnalysisResult

class TerminologyAnalyzer(BaseAnalyzer):
    """Анализатор терминологии в юридических документах"""

    def __init__(self):
        """Инициализация анализатора терминологии"""
        super().__init__(AnalysisType.TERMINOLOGY)
        
        # Веса для разных аспектов анализа терминологии
        self._aspect_weights = {
            "definitions": 0.4,     # Определения терминов
            "consistency": 0.3,     # Согласованность использования
            "clarity": 0.3          # Ясность терминологии
        }
        
        # Маркеры определений
        self._definition_markers = [
            r"далее[\s\-—]+",
            r"именуем\w+[\s\-—]+",
            r"определяе\w+[\s\-—]+как",
            r"означает[\s\-—]+",
            r"под[\s\w]+понимается"
        ]

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ терминологии в тексте
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа терминологии
        """
        if not content:
            return self._create_result(0.0, [], {"error": "Empty content"})

        # Анализ различных аспектов терминологии
        findings = []
        
        # Поиск определений терминов
        definitions = self._find_definitions(content)
        definitions_score = self._analyze_definitions(content, definitions, findings)
        
        # Анализ согласованности использования терминов
        consistency_score = self._analyze_consistency(content, definitions, findings)
        
        # Анализ ясности терминологии
        clarity_score = self._analyze_clarity(content, findings)

        aspect_scores = {
            "definitions": definitions_score,
            "consistency": consistency_score,
            "clarity": clarity_score
        }

        # Расчет общей оценки с учетом весов
        total_score = sum(
            score * self._aspect_weights[aspect]
            for aspect, score in aspect_scores.items()
        )

        metadata = {
            "aspect_scores": aspect_scores,
            "aspect_weights": self._aspect_weights,
            "definitions_found": len(definitions)
        }

        return self._create_result(total_score, findings, metadata)

    def _find_definitions(self, content: str) -> Dict[str, List[int]]:
        """
        Находит определения терминов в тексте
        
        Args:
            content: Текст для анализа
            
        Returns:
            Dict[str, List[int]]: Словарь терминов с позициями их определений
        """
        definitions = {}
        
        for marker in self._definition_markers:
            matches = re.finditer(marker, content, re.IGNORECASE)
            for match in matches:
                # Извлекаем определяемый термин
                start = max(0, match.start() - 50)
                end = min(len(content), match.end() + 100)
                context = content[start:end]
                
                # Ищем термин в кавычках или перед маркером
                term_match = re.search(r'"([^"]+)"|«([^»]+)»', context)
                if term_match:
                    term = term_match.group(1) or term_match.group(2)
                else:
                    # Берем слово перед маркером
                    term_match = re.search(r'(\w+)\s*' + marker, context)
                    if term_match:
                        term = term_match.group(1)
                    else:
                        continue
                
                if term:
                    if term not in definitions:
                        definitions[term] = []
                    definitions[term].append(match.start())
                    
        return definitions

    def _analyze_definitions(self, content: str, definitions: Dict[str, List[int]], 
                           findings: List[Dict[str, Any]]) -> float:
        """Анализ определений терминов"""
        if not definitions:
            return 0.0
            
        score = min(len(definitions) * 0.1, 1.0)
        
        for term, positions in definitions.items():
            for pos in positions:
                findings.append({
                    "type": "definition",
                    "term": term,
                    "position": pos
                })
                
        return score

    def _analyze_consistency(self, content: str, definitions: Dict[str, List[int]], 
                           findings: List[Dict[str, Any]]) -> float:
        """Анализ согласованности использования терминов"""
        if not definitions:
            return 0.0
            
        score = 0.0
        
        for term in definitions:
            # Ищем все упоминания термина
            pattern = r'\b' + re.escape(term) + r'\b'
            matches = list(re.finditer(pattern, content, re.IGNORECASE))
            
            if matches:
                # Проверяем согласованность использования
                inconsistent = False
                base_term = matches[0].group().lower()
                
                for match in matches[1:]:
                    if match.group().lower() != base_term:
                        inconsistent = True
                        findings.append({
                            "type": "inconsistency",
                            "term": term,
                            "position": match.start(),
                            "variant": match.group()
                        })
                
                if not inconsistent:
                    score += 0.1
                    
        return min(score, 1.0)

    def _analyze_clarity(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ ясности терминологии"""
        unclear_patterns = [
            r"и[\s/]или",
            r"др\.",
            r"т\.д\.",
            r"т\.п\.",
            r"прочие",
            r"иные",
            r"какие-либо"
        ]
        
        score = 1.0
        for pattern in unclear_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                findings.append({
                    "type": "unclear",
                    "pattern": pattern,
                    "position": match.start(),
                    "match": match.group()
                })
                score -= 0.1
                
        return max(score, 0.0)