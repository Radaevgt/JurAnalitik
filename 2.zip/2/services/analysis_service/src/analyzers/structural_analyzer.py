"""
Analysis Service - Structural Analyzer
Анализатор структуры юридических документов
"""
from typing import Dict, Any, List, Tuple
import re

from ..core.base_analyzer import BaseAnalyzer
from ..interfaces import AnalysisType, AnalysisResult

class StructuralAnalyzer(BaseAnalyzer):
    """Анализатор структуры юридических документов"""

    def __init__(self):
        """Инициализация анализатора структуры"""
        super().__init__(AnalysisType.STRUCTURAL)
        
        # Веса для разных аспектов анализа структуры
        self._aspect_weights = {
            "sections": 0.3,      # Разделы и подразделы
            "numbering": 0.2,     # Нумерация
            "references": 0.2,    # Внутренние ссылки
            "formatting": 0.3     # Форматирование
        }
        
        # Маркеры структурных элементов
        self._section_markers = [
            r"раздел\s+\d+",
            r"глава\s+\d+",
            r"статья\s+\d+",
            r"пункт\s+\d+",
            r"параграф\s+\d+"
        ]
        
        # Маркеры нумерации
        self._numbering_patterns = [
            r"\d+\.\d+",          # 1.1, 2.3
            r"\d+\.\d+\.\d+",     # 1.1.1, 2.3.4
            r"[а-я]\)\s",         # а), б)
            r"\d+\)\s",           # 1), 2)
            r"[ivx]+\.\s"         # i., ii.
        ]

    async def analyze(self, content: str) -> AnalysisResult:
        """
        Выполняет анализ структуры документа
        
        Args:
            content: Текст для анализа
            
        Returns:
            AnalysisResult: Результат анализа структуры
        """
        if not content:
            return self._create_result(0.0, [], {"error": "Empty content"})

        findings = []
        
        # Анализ разделов
        sections = self._analyze_sections(content, findings)
        sections_score = min(len(sections) * 0.1, 1.0)
        
        # Анализ нумерации
        numbering_score = self._analyze_numbering(content, findings)
        
        # Анализ внутренних ссылок
        references_score = self._analyze_references(content, sections, findings)
        
        # Анализ форматирования
        formatting_score = self._analyze_formatting(content, findings)

        aspect_scores = {
            "sections": sections_score,
            "numbering": numbering_score,
            "references": references_score,
            "formatting": formatting_score
        }

        # Расчет общей оценки с учетом весов
        total_score = sum(
            score * self._aspect_weights[aspect]
            for aspect, score in aspect_scores.items()
        )

        metadata = {
            "aspect_scores": aspect_scores,
            "aspect_weights": self._aspect_weights,
            "sections_count": len(sections)
        }

        return self._create_result(total_score, findings, metadata)

    def _analyze_sections(self, content: str, findings: List[Dict[str, Any]]) -> List[Tuple[str, int]]:
        """
        Анализ разделов документа
        
        Returns:
            List[Tuple[str, int]]: Список кортежей (название раздела, позиция)
        """
        sections = []
        
        for pattern in self._section_markers:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                # Извлекаем название раздела
                start = match.start()
                end = content.find("\n", start)
                if end == -1:
                    end = len(content)
                    
                section_name = content[start:end].strip()
                sections.append((section_name, start))
                
                findings.append({
                    "type": "section",
                    "name": section_name,
                    "position": start
                })
                
        return sorted(sections, key=lambda x: x[1])

    def _analyze_numbering(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ нумерации"""
        score = 0.0
        
        for pattern in self._numbering_patterns:
            matches = list(re.finditer(pattern, content))
            if matches:
                score += 0.2
                
                # Проверяем последовательность нумерации
                prev_num = None
                for match in matches:
                    num_str = match.group().rstrip('.) ')
                    try:
                        if num_str.isdigit():
                            num = int(num_str)
                            if prev_num is not None and num != prev_num + 1:
                                findings.append({
                                    "type": "numbering_error",
                                    "position": match.start(),
                                    "details": f"Нарушение последовательности: {prev_num} -> {num}"
                                })
                            prev_num = num
                    except ValueError:
                        pass
                        
        return min(score, 1.0)

    def _analyze_references(self, content: str, sections: List[Tuple[str, int]], 
                          findings: List[Dict[str, Any]]) -> float:
        """Анализ внутренних ссылок"""
        score = 0.0
        
        # Ищем ссылки на разделы
        for section_name, _ in sections:
            # Убираем номер из названия для поиска ссылок
            clean_name = re.sub(r'\d+', '', section_name).strip()
            if len(clean_name) < 4:  # Слишком короткие части пропускаем
                continue
                
            references = re.finditer(
                r'(?:согласно|в соответствии с|см\.)\s+' + re.escape(clean_name),
                content,
                re.IGNORECASE
            )
            
            for match in references:
                findings.append({
                    "type": "reference",
                    "target": section_name,
                    "position": match.start()
                })
                score += 0.1
                
        return min(score, 1.0)

    def _analyze_formatting(self, content: str, findings: List[Dict[str, Any]]) -> float:
        """Анализ форматирования"""
        score = 1.0
        
        # Проверяем отступы
        lines = content.split('\n')
        prev_indent = 0
        
        for i, line in enumerate(lines):
            if not line.strip():
                continue
                
            indent = len(line) - len(line.lstrip())
            
            # Резкое изменение отступа
            if abs(indent - prev_indent) > 8:
                findings.append({
                    "type": "formatting_warning",
                    "line": i + 1,
                    "details": "Резкое изменение отступа"
                })
                score -= 0.1
                
            prev_indent = indent
            
        # Проверяем пустые строки между разделами
        for i in range(1, len(lines)):
            if any(re.match(pattern, lines[i], re.IGNORECASE) for pattern in self._section_markers):
                if lines[i-1].strip():
                    findings.append({
                        "type": "formatting_warning",
                        "line": i + 1,
                        "details": "Отсутствует пустая строка перед разделом"
                    })
                    score -= 0.1
                    
        return max(score, 0.0)