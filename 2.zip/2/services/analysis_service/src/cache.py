from typing import Dict, Any, Optional
import time
from collections import OrderedDict
from .config import settings

class Cache:
    """
    Кэш для хранения результатов анализа в памяти.
    Использует LRU (Least Recently Used) стратегию вытеснения при достижении максимального размера.
    """
    
    def __init__(self):
        config = settings["service"]["cache"]
        self.ttl = config["ttl_hours"] * 3600  # Переводим часы в секунды
        self.max_size = config["max_size"]
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()

    def get(self, key: str) -> Optional[Any]:
        """Получить значение из кэша по ключу"""
        if key not in self._cache:
            return None
            
        entry = self._cache[key]
        if time.time() - entry["timestamp"] > self.ttl:
            # Удаляем устаревшую запись
            del self._cache[key]
            return None
            
        # Обновляем позицию записи (LRU)
        self._cache.move_to_end(key)
        return entry["value"]

    def set(self, key: str, value: Any) -> None:
        """Сохранить значение в кэш"""
        # Если достигнут максимальный размер, удаляем самую старую запись
        if len(self._cache) >= self.max_size:
            self._cache.popitem(last=False)
            
        entry = {
            "value": value,
            "timestamp": time.time()
        }
        self._cache[key] = entry
        self._cache.move_to_end(key)

    def delete(self, key: str) -> None:
        """Удалить значение из кэша"""
        if key in self._cache:
            del self._cache[key]

    def clear(self) -> None:
        """Очистить кэш"""
        self._cache.clear()

    def cleanup(self) -> None:
        """Удалить все устаревшие записи"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self._cache.items()
            if current_time - entry["timestamp"] > self.ttl
        ]
        for key in expired_keys:
            del self._cache[key]

    def generate_key(self, *args: Any, **kwargs: Any) -> str:
        """Сгенерировать ключ кэша из аргументов"""
        key_parts = [str(arg) for arg in args]
        key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
        return ":".join(key_parts)

# Создаем единственный экземпляр кэша
cache = Cache()