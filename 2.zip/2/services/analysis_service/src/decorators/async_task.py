import uuid
from typing import Any, Dict, Callable, Awaitable
from functools import wraps
from fastapi import HTTPException, status
from ..task_manager import TaskManager

task_manager = TaskManager()

def async_task(func: Callable[..., Awaitable[Any]]):
    """
    Декоратор для асинхронной обработки задач.
    Оборачивает асинхронную функцию, создавая для нее задачу в TaskManager.
    
    Args:
        func: Асинхронная функция для выполнения
        
    Returns:
        Dict с ID задачи
    """
    @wraps(func)
    async def wrapper(*args, **kwargs) -> Dict[str, str]:
        # Создаем уникальный ID для задачи
        task_id = str(uuid.uuid4())
        
        # Создаем корутину для выполнения
        coro = func(*args, **kwargs)
        
        # Добавляем задачу в TaskManager
        task_manager.add_task(task_id, coro)
        
        # Возвращаем ID задачи клиенту
        return {
            "task_id": task_id,
            "status": "accepted",
            "message": "Задача принята в обработку"
        }
    
    return wrapper

def get_task_result(task_id: str) -> Dict[str, Any]:
    """
    Получить результат выполнения асинхронной задачи.
    
    Args:
        task_id: ID задачи
        
    Returns:
        Dict с результатом или статусом выполнения
        
    Raises:
        HTTPException: если задача не найдена
    """
    try:
        status, result = task_manager.get_task_status(task_id)
        
        response = {
            "task_id": task_id,
            "status": status
        }
        
        if status == "completed":
            response["result"] = result
        elif status == "failed":
            response["error"] = str(result)
            
        return response
        
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Задача с ID {task_id} не найдена"
        )