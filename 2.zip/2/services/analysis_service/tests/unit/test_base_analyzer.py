import pytest
from unittest.mock import Mock, patch
from src.core.base_analyzer import BaseAnalyzer

class TestAnalyzer(BaseAnalyzer):
    """Тестовый анализатор для проверки базового класса"""
    def __init__(self):
        super().__init__("test_analyzer")
    
    async def analyze(self, text: str, options: dict = None) -> dict:
        return {
            "result": f"Analysis of: {text}",
            "score": 0.8
        }

@pytest.fixture
def analyzer():
    return TestAnalyzer()

def test_analyzer_initialization(analyzer):
    assert analyzer.name == "test_analyzer"
    assert hasattr(analyzer, 'analyze')
    assert analyzer.is_initialized()

@pytest.mark.asyncio
async def test_analyze_success(analyzer):
    # Подготовка
    text = "Test document"
    options = {"detailed": True}
    
    # Выполнение
    result = await analyzer.analyze(text, options)
    
    # Проверка
    assert result["result"] == "Analysis of: Test document"
    assert result["score"] == 0.8

@pytest.mark.asyncio
async def test_analyze_with_default_options(analyzer):
    # Выполнение
    result = await analyzer.analyze("Test document")
    
    # Проверка
    assert "result" in result
    assert "score" in result

def test_validate_text(analyzer):
    # Подготовка
    valid_text = "Valid text"
    empty_text = ""
    none_text = None
    
    # Проверка
    assert analyzer.validate_text(valid_text) is True
    assert analyzer.validate_text(empty_text) is False
    assert analyzer.validate_text(none_text) is False

def test_validate_options(analyzer):
    # Подготовка
    valid_options = {
        "detailed": True,
        "format": "json"
    }
    invalid_options = {
        "invalid_key": "value"
    }
    
    # Проверка
    assert analyzer.validate_options(valid_options) is True
    assert analyzer.validate_options(invalid_options) is False

@pytest.mark.asyncio
async def test_analyze_with_preprocessing(analyzer):
    # Подготовка
    def preprocess(text):
        return text.lower()
    
    analyzer.add_preprocessor(preprocess)
    
    # Выполнение
    result = await analyzer.analyze("Test TEXT")
    
    # Проверка
    assert "test text" in result["result"]

@pytest.mark.asyncio
async def test_analyze_with_postprocessing(analyzer):
    # Подготовка
    def postprocess(result):
        result["confidence"] = 0.9
        return result
    
    analyzer.add_postprocessor(postprocess)
    
    # Выполнение
    result = await analyzer.analyze("Test")
    
    # Проверка
    assert result["confidence"] == 0.9

def test_analyzer_metadata(analyzer):
    # Выполнение
    metadata = analyzer.get_metadata()
    
    # Проверка
    assert metadata["name"] == "test_analyzer"
    assert "version" in metadata
    assert "capabilities" in metadata
    assert "supported_formats" in metadata

@pytest.mark.asyncio
async def test_analyze_with_context(analyzer):
    # Подготовка
    context = {
        "document_type": "contract",
        "language": "ru"
    }
    
    # Выполнение
    result = await analyzer.analyze_with_context("Test", context)
    
    # Проверка
    assert result["context"] == context

def test_analyzer_configuration(analyzer):
    # Подготовка
    config = {
        "threshold": 0.5,
        "max_length": 1000
    }
    
    # Выполнение
    analyzer.configure(config)
    
    # Проверка
    assert analyzer.config["threshold"] == 0.5
    assert analyzer.config["max_length"] == 1000

@pytest.mark.asyncio
async def test_error_handling(analyzer):
    # Подготовка
    error_analyzer = TestAnalyzer()
    error_analyzer.analyze = Mock(side_effect=Exception("Analysis error"))
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await error_analyzer.analyze("Test")
    assert "Analysis error" in str(exc_info.value)

def test_analyzer_statistics(analyzer):
    # Подготовка
    analyzer.record_execution_time(0.5)
    analyzer.record_error("Test error")
    
    # Выполнение
    stats = analyzer.get_statistics()
    
    # Проверка
    assert stats["average_execution_time"] == 0.5
    assert stats["error_count"] > 0
    assert stats["total_executions"] > 0