import pytest
from unittest.mock import Mock, patch
from src.analyzers.risk_analyzer import RiskAnalyzer
from src.clients.prompt_service import PromptServiceClient
from src.clients.provider_service import ProviderServiceClient

@pytest.fixture
def mock_prompt_client():
    return Mock(spec=PromptServiceClient)

@pytest.fixture
def mock_provider_client():
    return Mock(spec=ProviderServiceClient)

@pytest.fixture
def analyzer(mock_prompt_client, mock_provider_client):
    analyzer = RiskAnalyzer()
    analyzer.prompt_client = mock_prompt_client
    analyzer.provider_client = mock_provider_client
    return analyzer

def test_analyzer_initialization(analyzer):
    assert analyzer.name == "risk_analyzer"
    assert hasattr(analyzer, 'analyze')
    assert analyzer.is_initialized()

@pytest.mark.asyncio
async def test_analyze_success(analyzer, mock_prompt_client, mock_provider_client):
    # Подготовка
    text = "Sample contract text"
    mock_prompt_client.process_prompt.return_value = "Processed prompt"
    mock_provider_client.get_completion.return_value = {
        "response": """
        {
            "risks": [
                {
                    "type": "legal",
                    "severity": "high",
                    "description": "Missing liability clause"
                }
            ],
            "overall_score": 0.7
        }
        """
    }
    
    # Выполнение
    result = await analyzer.analyze(text)
    
    # Проверка
    assert "risks" in result
    assert len(result["risks"]) == 1
    assert result["risks"][0]["type"] == "legal"
    assert result["risks"][0]["severity"] == "high"
    assert result["overall_score"] == 0.7

@pytest.mark.asyncio
async def test_analyze_with_context(analyzer, mock_prompt_client, mock_provider_client):
    # Подготовка
    text = "Sample text"
    context = {
        "document_type": "contract",
        "industry": "software"
    }
    mock_prompt_client.process_prompt.return_value = "Processed prompt with context"
    mock_provider_client.get_completion.return_value = {
        "response": '{"risks": [], "overall_score": 0.5}'
    }
    
    # Выполнение
    result = await analyzer.analyze(text, {"context": context})
    
    # Проверка
    mock_prompt_client.process_prompt.assert_called_once()
    assert "context" in mock_prompt_client.process_prompt.call_args[0][1]

def test_risk_severity_validation(analyzer):
    # Подготовка
    valid_severities = ["low", "medium", "high", "critical"]
    invalid_severity = "unknown"
    
    # Проверка
    for severity in valid_severities:
        assert analyzer.validate_risk_severity(severity)
    assert not analyzer.validate_risk_severity(invalid_severity)

def test_risk_type_validation(analyzer):
    # Подготовка
    valid_types = ["legal", "financial", "operational", "compliance"]
    invalid_type = "invalid"
    
    # Проверка
    for risk_type in valid_types:
        assert analyzer.validate_risk_type(risk_type)
    assert not analyzer.validate_risk_type(invalid_type)

@pytest.mark.asyncio
async def test_analyze_with_specific_risk_types(analyzer, mock_prompt_client, mock_provider_client):
    # Подготовка
    text = "Sample text"
    options = {
        "risk_types": ["legal", "financial"]
    }
    mock_provider_client.get_completion.return_value = {
        "response": '{"risks": [], "overall_score": 0.5}'
    }
    
    # Выполнение
    await analyzer.analyze(text, options)
    
    # Проверка
    call_args = mock_prompt_client.process_prompt.call_args[0][1]
    assert "risk_types" in call_args
    assert "legal" in call_args["risk_types"]
    assert "financial" in call_args["risk_types"]

@pytest.mark.asyncio
async def test_analyze_invalid_response(analyzer, mock_prompt_client, mock_provider_client):
    # Подготовка
    mock_provider_client.get_completion.return_value = {
        "response": "Invalid JSON"
    }
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        await analyzer.analyze("Test text")
    assert "Invalid response format" in str(exc_info.value)

def test_risk_scoring(analyzer):
    # Подготовка
    risks = [
        {"severity": "high", "impact": 0.8},
        {"severity": "medium", "impact": 0.5},
        {"severity": "low", "impact": 0.2}
    ]
    
    # Выполнение
    score = analyzer.calculate_risk_score(risks)
    
    # Проверка
    assert 0 <= score <= 1
    assert score > 0.5  # Учитывая высокий риск

def test_risk_categorization(analyzer):
    # Подготовка
    risks = [
        {"type": "legal", "description": "Risk 1"},
        {"type": "legal", "description": "Risk 2"},
        {"type": "financial", "description": "Risk 3"}
    ]
    
    # Выполнение
    categorized = analyzer.categorize_risks(risks)
    
    # Проверка
    assert len(categorized["legal"]) == 2
    assert len(categorized["financial"]) == 1

@pytest.mark.asyncio
async def test_analyze_with_custom_prompt(analyzer, mock_prompt_client, mock_provider_client):
    # Подготовка
    text = "Sample text"
    custom_prompt = "Custom analysis prompt"
    mock_provider_client.get_completion.return_value = {
        "response": '{"risks": [], "overall_score": 0.5}'
    }
    
    # Выполнение
    await analyzer.analyze(text, {"prompt_template": custom_prompt})
    
    # Проверка
    mock_prompt_client.process_prompt.assert_called_with(
        "risk_analysis",
        {"text": text, "prompt_template": custom_prompt}
    )