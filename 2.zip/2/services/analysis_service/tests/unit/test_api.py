import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
from src.api import app
from src.service import AnalysisService

@pytest.fixture
def mock_service():
    return Mock(spec=AnalysisService)

@pytest.fixture
def client(mock_service):
    app.dependency_overrides[AnalysisService] = lambda: mock_service
    return TestClient(app)

def test_health_check(client):
    # Выполнение
    response = client.get("/v1/health")
    
    # Проверка
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_get_analyzers(client, mock_service):
    # Подготовка
    mock_service.get_available_analyzers.return_value = {
        "risk_analyzer": {"name": "risk_analyzer", "version": "1.0"},
        "business_analyzer": {"name": "business_analyzer", "version": "1.0"}
    }
    
    # Выполнение
    response = client.get("/v1/analyzers")
    
    # Проверка
    assert response.status_code == 200
    analyzers = response.json()["analyzers"]
    assert len(analyzers) == 2
    assert analyzers["risk_analyzer"]["name"] == "risk_analyzer"
    assert analyzers["business_analyzer"]["name"] == "business_analyzer"

def test_analyze_text_success(client, mock_service):
    # Подготовка
    mock_service.analyze_text.return_value = {
        "result": "Analysis result",
        "score": 0.8
    }
    request_data = {
        "text": "Sample text",
        "options": {"detailed": True}
    }
    
    # Выполнение
    response = client.post("/v1/analyzers/risk_analyzer/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    result = response.json()
    assert result["result"] == "Analysis result"
    assert result["score"] == 0.8
    mock_service.analyze_text.assert_called_once_with(
        "Sample text",
        "risk_analyzer",
        {"detailed": True}
    )

def test_analyze_text_with_multiple_analyzers(client, mock_service):
    # Подготовка
    mock_service.analyze_text_with_analyzers.return_value = {
        "risk_analyzer": {"result": "Risk analysis"},
        "business_analyzer": {"result": "Business analysis"}
    }
    request_data = {
        "text": "Sample text",
        "analyzers": ["risk_analyzer", "business_analyzer"]
    }
    
    # Выполнение
    response = client.post("/v1/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    results = response.json()["results"]
    assert len(results) == 2
    assert results["risk_analyzer"]["result"] == "Risk analysis"
    assert results["business_analyzer"]["result"] == "Business analysis"

def test_analyze_text_validation_error(client):
    # Подготовка - пустой текст
    request_data = {
        "text": "",
        "options": {}
    }
    
    # Выполнение
    response = client.post("/v1/analyzers/risk_analyzer/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 422
    assert "validation" in response.json()["detail"].lower()

def test_analyze_text_analyzer_error(client, mock_service):
    # Подготовка
    mock_service.analyze_text.side_effect = Exception("Analysis error")
    request_data = {
        "text": "Sample text",
        "options": {}
    }
    
    # Выполнение
    response = client.post("/v1/analyzers/risk_analyzer/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 500
    assert "error" in response.json()["detail"].lower()

def test_analyze_with_nonexistent_analyzer(client, mock_service):
    # Подготовка
    mock_service.analyze_text.side_effect = ValueError("Analyzer not found")
    request_data = {
        "text": "Sample text"
    }
    
    # Выполнение
    response = client.post("/v1/analyzers/nonexistent/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()

def test_analyze_with_format(client, mock_service):
    # Подготовка
    mock_service.analyze_text.return_value = {
        "result": "Analysis result"
    }
    request_data = {
        "text": "Sample text",
        "options": {"format": "json"}
    }
    
    # Выполнение
    response = client.post("/v1/analyzers/risk_analyzer/analyze", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

def test_unauthorized_access(client):
    # Выполнение без токена авторизации
    response = client.post("/v1/analyzers/risk_analyzer/analyze", json={
        "text": "Sample text"
    })
    
    # Проверка
    assert response.status_code == 401
    assert "unauthorized" in response.json()["detail"].lower()

def test_metrics(client, mock_service):
    # Подготовка
    mock_service.get_statistics.return_value = {
        "total_requests": 100,
        "average_processing_time": 0.5,
        "analyzers": {
            "risk_analyzer": {
                "total_executions": 50,
                "average_execution_time": 0.3
            }
        }
    }
    
    # Выполнение
    response = client.get("/v1/metrics")
    
    # Проверка
    assert response.status_code == 200
    metrics = response.json()
    assert metrics["total_requests"] == 100
    assert "analyzers" in metrics
    assert "risk_analyzer" in metrics["analyzers"]