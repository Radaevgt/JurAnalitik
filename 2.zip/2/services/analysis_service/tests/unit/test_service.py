import pytest
from unittest.mock import Mock, patch
from src.service import AnalysisService
from src.core.base_analyzer import BaseAnalyzer

class TestAnalyzer(BaseAnalyzer):
    """Тестовый анализатор для проверки сервиса"""
    def __init__(self):
        super().__init__("test_analyzer")
    
    async def analyze(self, text: str, options: dict = None) -> dict:
        return {
            "result": f"Analysis of: {text}",
            "score": 0.8
        }

@pytest.fixture
def mock_analyzer():
    return Mock(spec=TestAnalyzer)

@pytest.fixture
def service():
    return AnalysisService()

def test_service_initialization(service):
    assert service is not None
    assert hasattr(service, 'analyzers')
    assert isinstance(service.analyzers, dict)

def test_register_analyzer(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    
    # Выполнение
    service.register_analyzer(mock_analyzer)
    
    # Проверка
    assert "test_analyzer" in service.analyzers
    assert service.analyzers["test_analyzer"] == mock_analyzer

def test_register_duplicate_analyzer(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    service.register_analyzer(mock_analyzer)
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        service.register_analyzer(mock_analyzer)
    assert "Analyzer already registered" in str(exc_info.value)

def test_get_analyzer(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    service.register_analyzer(mock_analyzer)
    
    # Выполнение
    analyzer = service.get_analyzer("test_analyzer")
    
    # Проверка
    assert analyzer == mock_analyzer

def test_get_nonexistent_analyzer(service):
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        service.get_analyzer("nonexistent")
    assert "Analyzer not found" in str(exc_info.value)

@pytest.mark.asyncio
async def test_analyze_text(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    mock_analyzer.analyze.return_value = {
        "result": "Test result",
        "score": 0.8
    }
    service.register_analyzer(mock_analyzer)
    
    text = "Test document"
    options = {"detailed": True}
    
    # Выполнение
    result = await service.analyze_text(text, "test_analyzer", options)
    
    # Проверка
    assert result["result"] == "Test result"
    assert result["score"] == 0.8
    mock_analyzer.analyze.assert_called_once_with(text, options)

@pytest.mark.asyncio
async def test_analyze_text_with_multiple_analyzers(service):
    # Подготовка
    analyzers = [TestAnalyzer() for _ in range(3)]
    for i, analyzer in enumerate(analyzers):
        analyzer.name = f"analyzer_{i}"
        service.register_analyzer(analyzer)
    
    # Выполнение
    results = await service.analyze_text_with_analyzers(
        "Test text",
        ["analyzer_0", "analyzer_1", "analyzer_2"]
    )
    
    # Проверка
    assert len(results) == 3
    assert all("result" in r for r in results.values())
    assert all("score" in r for r in results.values())

def test_get_available_analyzers(service):
    # Подготовка
    analyzers = [TestAnalyzer() for _ in range(3)]
    for i, analyzer in enumerate(analyzers):
        analyzer.name = f"analyzer_{i}"
        service.register_analyzer(analyzer)
    
    # Выполнение
    available = service.get_available_analyzers()
    
    # Проверка
    assert len(available) == 3
    assert all(f"analyzer_{i}" in available for i in range(3))

@pytest.mark.asyncio
async def test_analyze_with_format(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    mock_analyzer.analyze.return_value = {"result": "Test result"}
    service.register_analyzer(mock_analyzer)
    
    # Выполнение
    result = await service.analyze_text(
        "Test text",
        "test_analyzer",
        {"format": "json"}
    )
    
    # Проверка
    assert isinstance(result, dict)
    mock_analyzer.analyze.assert_called_once()

@pytest.mark.asyncio
async def test_analyze_with_cache(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    mock_analyzer.analyze.return_value = {"result": "Test result"}
    service.register_analyzer(mock_analyzer)
    
    # Первый вызов
    result1 = await service.analyze_text("Test text", "test_analyzer")
    
    # Второй вызов с тем же текстом
    result2 = await service.analyze_text("Test text", "test_analyzer")
    
    # Проверка
    assert result1 == result2
    assert mock_analyzer.analyze.call_count == 1  # Вызван только один раз

def test_analyzer_error_handling(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    mock_analyzer.analyze.side_effect = Exception("Analysis error")
    service.register_analyzer(mock_analyzer)
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        service.analyze_text("Test text", "test_analyzer")
    assert "Analysis error" in str(exc_info.value)

def test_service_statistics(service, mock_analyzer):
    # Подготовка
    mock_analyzer.name = "test_analyzer"
    mock_analyzer.get_statistics.return_value = {
        "total_executions": 10,
        "average_execution_time": 0.5
    }
    service.register_analyzer(mock_analyzer)
    
    # Выполнение
    stats = service.get_statistics()
    
    # Проверка
    assert "analyzers" in stats
    assert "test_analyzer" in stats["analyzers"]
    assert stats["analyzers"]["test_analyzer"]["total_executions"] == 10