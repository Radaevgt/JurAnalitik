"""
Analysis Service - Tests for Formatters
Тесты для форматтеров результатов анализа
"""
import json
import pytest
from bs4 import BeautifulSoup
import markdown2

from ..src.interfaces import AnalysisType, AnalysisResult
from ..src.formatters import (
    MarkdownFormatter,
    HTMLFormatter,
    JSONFormatter
)

# Тестовые данные
@pytest.fixture
def sample_result():
    """Фикстура с тестовым результатом анализа"""
    return AnalysisResult(
        type=AnalysisType.RISK,
        score=0.75,
        findings=[
            {
                "type": "financial_risk",
                "context": "штраф в размере 10%",
                "position": 100,
                "severity": "high"
            },
            {
                "type": "legal_risk",
                "context": "нарушение условий договора",
                "position": 200,
                "severity": "medium"
            }
        ],
        metadata={
            "metrics": {
                "total_risks": 2,
                "risk_distribution": {
                    "financial": 0.5,
                    "legal": 0.5
                }
            }
        }
    )

class TestMarkdownFormatter:
    """Тесты для Markdown форматтера"""
    
    def test_markdown_format(self, sample_result):
        """Тест форматирования в Markdown"""
        formatter = MarkdownFormatter()
        result = formatter.format(sample_result)
        
        # Проверяем базовую структуру
        assert "# Результаты анализа: risk" in result
        assert "**Общий скор:** 75.0%" in result
        
        # Проверяем секцию находок
        assert "## Находки" in result
        assert "### financial_risk" in result
        assert "### legal_risk" in result
        
        # Проверяем метрики
        assert "## Метрики" in result
        assert "total_risks" in result
        
        # Проверяем валидность Markdown
        html = markdown2.markdown(result)
        assert html is not None
        assert len(html) > 0

class TestHTMLFormatter:
    """Тесты для HTML форматтера"""
    
    def test_html_format(self, sample_result):
        """Тест форматирования в HTML"""
        formatter = HTMLFormatter()
        result = formatter.format(sample_result)
        
        # Парсим HTML для проверки структуры
        soup = BeautifulSoup(result, 'html.parser')
        
        # Проверяем базовую структуру
        assert soup.title.string == "Результаты анализа: risk"
        assert "75.0%" in soup.find(class_="score").text
        
        # Проверяем секцию находок
        findings = soup.find(class_="findings")
        assert findings is not None
        assert len(findings.find_all(class_="finding")) == 2
        
        # Проверяем метрики
        metrics = soup.find(class_="metrics")
        assert metrics is not None
        assert "total_risks" in metrics.text
        
        # Проверяем стили
        assert soup.style is not None
        assert "body {" in str(soup.style)

    def test_html_score_colors(self, sample_result):
        """Тест цветового оформления скора"""
        formatter = HTMLFormatter()
        
        # Тест для высокого скора
        sample_result.score = 0.9
        result_high = formatter.format(sample_result)
        assert "#28a745" in result_high  # Зеленый
        
        # Тест для среднего скора
        sample_result.score = 0.7
        result_medium = formatter.format(sample_result)
        assert "#ffc107" in result_medium  # Желтый
        
        # Тест для низкого скора
        sample_result.score = 0.3
        result_low = formatter.format(sample_result)
        assert "#dc3545" in result_low  # Красный

class TestJSONFormatter:
    """Тесты для JSON форматтера"""
    
    def test_json_format(self, sample_result):
        """Тест форматирования в JSON"""
        formatter = JSONFormatter()
        result = formatter.format(sample_result)
        
        # Проверяем, что результат - валидный JSON
        data = json.loads(result)
        
        # Проверяем структуру
        assert data["type"] == "risk"
        assert data["score"] == 0.75
        assert data["score_percentage"] == "75.0%"
        assert len(data["findings"]) == 2
        assert "metrics" in data
        assert "metadata" in data
        
        # Проверяем находки
        findings = data["findings"]
        assert findings[0]["type"] == "financial_risk"
        assert findings[1]["type"] == "legal_risk"
        
        # Проверяем метаданные
        assert "timestamp" in data["metadata"]
        assert "version" in data["metadata"]

@pytest.mark.parametrize("formatter_class", [
    MarkdownFormatter,
    HTMLFormatter,
    JSONFormatter
])
def test_formatter_empty_result(formatter_class):
    """Тест форматтеров с пустым результатом"""
    formatter = formatter_class()
    empty_result = AnalysisResult(
        type=AnalysisType.RISK,
        score=0,
        findings=[],
        metadata={}
    )
    result = formatter.format(empty_result)
    
    assert result is not None
    assert len(result) > 0
    
    if formatter_class == JSONFormatter:
        data = json.loads(result)
        assert data["findings"] == []
    elif formatter_class == HTMLFormatter:
        soup = BeautifulSoup(result, 'html.parser')
        findings = soup.find(class_="findings")
        assert "Находок не обнаружено" in findings.text
    else:  # MarkdownFormatter
        assert "Находок не обнаружено" in result

@pytest.mark.parametrize("formatter_class", [
    MarkdownFormatter,
    HTMLFormatter,
    JSONFormatter
])
def test_formatter_special_chars(formatter_class):
    """Тест обработки специальных символов"""
    formatter = formatter_class()
    result = AnalysisResult(
        type=AnalysisType.RISK,
        score=0.5,
        findings=[{
            "type": "test_risk",
            "context": "<script>alert('test')</script>",
            "position": 0
        }],
        metadata={}
    )
    formatted = formatter.format(result)
    
    assert "<script>" not in formatted
    if formatter_class == JSONFormatter:
        data = json.loads(formatted)
        assert data["findings"][0]["context"] == "<script>alert('test')</script>"
    else:
        assert "&lt;script&gt;" in formatted or r"\<script\>" in formatted