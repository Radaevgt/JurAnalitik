"""
Analysis Service - Tests for Service and API
Тесты для основного сервиса и REST API
"""
import json
import asyncio
import pytest
from fastapi.testclient import TestClient
import yaml

from ..src.interfaces import AnalysisType, AnalysisResult
from ..src.service import AnalysisService
from ..src.api import app

# Создаем тестового клиента
client = TestClient(app)

# Тестовые данные
TEST_CONTENT = """
ДОГОВОР ОКАЗАНИЯ УСЛУГ
1. Предмет договора
Исполнитель обязуется оказать услуги, а Заказчик обязуется оплатить их.
2. Стоимость услуг и порядок оплаты
Стоимость услуг составляет 50 000 рублей.
3. Ответственность сторон
За нарушение сроков предусмотрен штраф.
"""

@pytest.fixture
def service():
    """Фикстура с экземпляром сервиса"""
    return AnalysisService()

class TestAnalysisService:
    """Тесты для основного сервиса"""
    
    @pytest.mark.asyncio
    async def test_analyze(self, service):
        """Тест метода analyze"""
        analysis_types = [
            AnalysisType.RISK,
            AnalysisType.BUSINESS
        ]
        
        results = await service.analyze(TEST_CONTENT, analysis_types)
        
        assert len(results) == 2
        assert results[0].type == AnalysisType.RISK
        assert results[1].type == AnalysisType.BUSINESS
        assert all(0 <= r.score <= 1 for r in results)
        assert all(len(r.findings) > 0 for r in results)

    def test_format_results(self, service):
        """Тест форматирования результатов"""
        analysis_types = [AnalysisType.RISK]
        
        # Тестируем разные форматы
        formats = ['markdown', 'html', 'json']
        for format_type in formats:
            formatted = service.format_results(
                [AnalysisResult(
                    type=AnalysisType.RISK,
                    score=0.5,
                    findings=[{"type": "test", "value": "test"}],
                    metadata={}
                )],
                format_type
            )
            assert formatted is not None
            assert len(formatted) > 0

    @pytest.mark.asyncio
    async def test_analyze_and_format(self, service):
        """Тест комбинированного метода analyze_and_format"""
        analysis_types = [AnalysisType.RISK]
        format_type = 'json'
        
        result = await service.analyze_and_format(
            TEST_CONTENT,
            analysis_types,
            format_type
        )
        
        assert result is not None
        assert len(result) > 0
        # Проверяем, что результат - валидный JSON
        assert json.loads(result) is not None

    @pytest.mark.asyncio
    async def test_cache(self, service):
        """Тест кэширования результатов"""
        analysis_types = [AnalysisType.RISK]
        
        # Первый запрос - кэш пустой
        cache_key = service._get_cache_key(TEST_CONTENT, analysis_types)
        assert service._get_from_cache(cache_key) is None
        
        # Анализируем и проверяем кэш
        results = await service.analyze(TEST_CONTENT, analysis_types)
        cached = service._get_from_cache(cache_key)
        assert cached is not None
        assert len(cached) == len(results)
        
        # Очищаем кэш
        service.clear_cache()
        assert service._get_from_cache(cache_key) is None

class TestAnalysisAPI:
    """Тесты для REST API"""
    
    def test_analyze_text(self):
        """Тест эндпоинта анализа текста"""
        response = client.post(
            "/analyze",
            json={
                "content": TEST_CONTENT,
                "analysis_types": ["risk", "business"],
                "format_type": "json"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        assert "format" in data
        assert "metadata" in data

    def test_analyze_file(self):
        """Тест эндпоинта анализа файла"""
        # Создаем тестовый файл
        content = TEST_CONTENT.encode('utf-8')
        files = {
            'file': ('test.txt', content, 'text/plain')
        }
        response = client.post(
            "/analyze/file",
            files=files,
            data={
                "analysis_types": ["risk"],
                "format_type": "json"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        assert "format" in data
        assert "metadata" in data

    def test_invalid_requests(self):
        """Тест обработки некорректных запросов"""
        # Пустой текст
        response = client.post(
            "/analyze",
            json={
                "content": "",
                "analysis_types": ["risk"],
                "format_type": "json"
            }
        )
        assert response.status_code == 400
        
        # Неподдерживаемый формат
        response = client.post(
            "/analyze",
            json={
                "content": TEST_CONTENT,
                "analysis_types": ["risk"],
                "format_type": "invalid"
            }
        )
        assert response.status_code == 400
        
        # Неподдерживаемый тип файла
        files = {
            'file': ('test.exe', b'binary content', 'application/octet-stream')
        }
        response = client.post(
            "/analyze/file",
            files=files,
            data={
                "analysis_types": ["risk"],
                "format_type": "json"
            }
        )
        assert response.status_code == 400

    def test_get_endpoints(self):
        """Тест информационных эндпоинтов"""
        # Список анализаторов
        response = client.get("/analyzers")
        assert response.status_code == 200
        analyzers = response.json()
        assert len(analyzers) > 0
        assert "risk" in analyzers
        
        # Список форматов
        response = client.get("/formats")
        assert response.status_code == 200
        formats = response.json()
        assert len(formats) > 0
        assert "json" in formats
        assert "markdown" in formats
        assert "html" in formats
        
        # Проверка здоровья
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"

@pytest.mark.asyncio
async def test_concurrent_requests():
    """Тест параллельной обработки запросов"""
    async def make_request():
        return client.post(
            "/analyze",
            json={
                "content": TEST_CONTENT,
                "analysis_types": ["risk"],
                "format_type": "json"
            }
        )
    
    # Создаем и запускаем параллельные запросы
    tasks = [make_request() for _ in range(5)]
    responses = await asyncio.gather(*tasks)
    
    # Проверяем результаты
    assert all(r.status_code == 200 for r in responses)
    assert len({r.json()["results"] for r in responses}) == 1  # Результаты должны быть одинаковыми благодаря кэшу