"""
Analysis Service - Tests for Analyzers
Тесты для анализаторов документов
"""
import pytest
from ..src.interfaces import AnalysisType
from ..src.analyzers import (
    RiskAnalyzer, BusinessAnalyzer, ComplianceAnalyzer,
    TerminologyAnalyzer, StructuralAnalyzer
)

# Тестовые данные
TEST_CONTRACT = """
ДОГОВОР КУПЛИ-ПРОДАЖИ № 123
между ООО "Продавец" и ООО "Покупатель"

1. ПРЕДМЕТ ДОГОВОРА
1.1. Продавец обязуется передать в собственность Покупателя товар,
а Покупатель обязуется принять и оплатить его.

2. ЦЕНА И ПОРЯДОК ОПЛАТЫ
2.1. Стоимость товара составляет 100 000 рублей.
2.2. Оплата производится в течение 5 рабочих дней.
2.3. В случае просрочки платежа начисляется пеня в размере 0.1%.

3. ОТВЕТСТВЕННОСТЬ СТОРОН
3.1. За нарушение условий договора стороны несут ответственность
согласно действующему законодательству РФ.

4. ПОДПИСИ СТОРОН
Продавец: ____________    Покупатель: ____________
"""

@pytest.mark.asyncio
class TestRiskAnalyzer:
    """Тесты для анализатора рисков"""
    
    async def test_risk_analysis(self):
        """Тест анализа рисков"""
        analyzer = RiskAnalyzer()
        result = await analyzer.analyze(TEST_CONTRACT)
        
        assert result.type == AnalysisType.RISK
        assert 0 <= result.score <= 1
        assert len(result.findings) > 0
        
        # Проверяем наличие ключевых рисков
        risk_types = {f.get('type') for f in result.findings}
        assert 'financial_risk' in risk_types
        assert 'legal_risk' in risk_types

@pytest.mark.asyncio
class TestBusinessAnalyzer:
    """Тесты для бизнес-анализатора"""
    
    async def test_business_analysis(self):
        """Тест бизнес-анализа"""
        analyzer = BusinessAnalyzer()
        result = await analyzer.analyze(TEST_CONTRACT)
        
        assert result.type == AnalysisType.BUSINESS
        assert 0 <= result.score <= 1
        assert len(result.findings) > 0
        
        # Проверяем наличие бизнес-аспектов
        aspect_types = {f.get('type') for f in result.findings}
        assert 'financial_terms' in aspect_types
        assert 'payment_conditions' in aspect_types

@pytest.mark.asyncio
class TestComplianceAnalyzer:
    """Тесты для анализатора соответствия"""
    
    async def test_compliance_analysis(self):
        """Тест анализа соответствия"""
        analyzer = ComplianceAnalyzer()
        result = await analyzer.analyze(TEST_CONTRACT)
        
        assert result.type == AnalysisType.COMPLIANCE
        assert 0 <= result.score <= 1
        assert len(result.findings) > 0
        
        # Проверяем наличие требований
        req_types = {f.get('type') for f in result.findings}
        assert 'legal_references' in req_types
        assert 'regulatory_terms' in req_types

@pytest.mark.asyncio
class TestTerminologyAnalyzer:
    """Тесты для анализатора терминологии"""
    
    async def test_terminology_analysis(self):
        """Тест анализа терминологии"""
        analyzer = TerminologyAnalyzer()
        result = await analyzer.analyze(TEST_CONTRACT)
        
        assert result.type == AnalysisType.TERMINOLOGY
        assert 0 <= result.score <= 1
        assert len(result.findings) > 0
        
        # Проверяем наличие категорий терминов
        term_categories = {f.get('type') for f in result.findings}
        assert 'general_terms' in term_categories
        assert 'document_terms' in term_categories

@pytest.mark.asyncio
class TestStructuralAnalyzer:
    """Тесты для структурного анализатора"""
    
    async def test_structural_analysis(self):
        """Тест структурного анализа"""
        analyzer = StructuralAnalyzer()
        result = await analyzer.analyze(TEST_CONTRACT)
        
        assert result.type == AnalysisType.STRUCTURAL
        assert 0 <= result.score <= 1
        assert len(result.findings) > 0
        
        # Проверяем наличие структурных элементов
        sections = {f.get('type') for f in result.findings}
        assert 'header' in sections
        assert 'subject' in sections
        assert 'signatures' in sections

    async def test_structural_analysis_invalid(self):
        """Тест структурного анализа некорректного документа"""
        analyzer = StructuralAnalyzer()
        result = await analyzer.analyze("Некорректный документ без структуры")
        
        assert result.type == AnalysisType.STRUCTURAL
        assert result.score < 0.5  # Низкий скор для некорректного документа

@pytest.mark.parametrize("analyzer_class", [
    RiskAnalyzer,
    BusinessAnalyzer,
    ComplianceAnalyzer,
    TerminologyAnalyzer,
    StructuralAnalyzer
])
@pytest.mark.asyncio
async def test_analyzer_validation(analyzer_class):
    """Тест валидации результатов анализаторов"""
    analyzer = analyzer_class()
    result = await analyzer.analyze(TEST_CONTRACT)
    
    # Проверяем базовую валидацию
    assert analyzer.validate_result(result)
    
    # Проверяем метрики
    assert result.metadata is not None
    assert 'metrics' in result.metadata
    assert len(result.metadata['metrics']) > 0

@pytest.mark.parametrize("analyzer_class", [
    RiskAnalyzer,
    BusinessAnalyzer,
    ComplianceAnalyzer,
    TerminologyAnalyzer,
    StructuralAnalyzer
])
@pytest.mark.asyncio
async def test_analyzer_empty_input(analyzer_class):
    """Тест анализаторов с пустым входом"""
    analyzer = analyzer_class()
    result = await analyzer.analyze("")
    
    assert result.type == analyzer._type
    assert result.score == 0
    assert len(result.findings) == 0