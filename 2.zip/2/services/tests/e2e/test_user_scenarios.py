import pytest
import asyncio
import aiohttp
import json
from typing import Dict, List
from datetime import datetime

class TestUserScenarios:
    """End-to-end тесты основных пользовательских сценариев"""

    @pytest.fixture(autouse=True)
    async def setup(self):
        """Настройка тестового окружения"""
        # Базовые URL для сервисов
        self.base_urls = {
            "gateway": "http://localhost:8000",
            "analysis": "http://localhost:8001",
            "provider": "http://localhost:8002",
            "prompt": "http://localhost:8003"
        }
        
        # Тестовые данные
        self.test_documents = [
            {
                "text": """
                ДОГОВОР КУПЛИ-ПРОДАЖИ
                между ООО "Продавец" и ИП Иванов И.И.
                
                1. Предмет договора
                1.1. Продавец обязуется передать товар...
                """,
                "expected_risks": ["отсутствие сроков поставки", "нечеткие условия оплаты"]
            },
            {
                "text": """
                СОГЛАШЕНИЕ О КОНФИДЕНЦИАЛЬНОСТИ
                
                1. Стороны обязуются не разглашать информацию...
                2. Срок действия соглашения...
                """,
                "expected_sections": ["предмет соглашения", "конфиденциальная информация"]
            }
        ]
        
        # Создаем сессию для HTTP запросов
        self.session = aiohttp.ClientSession()
        yield
        # Закрываем сессию после тестов
        await self.session.close()

    async def _wait_for_analysis(self, task_id: str, max_retries: int = 10) -> Dict:
        """Ожидание завершения анализа"""
        for _ in range(max_retries):
            async with self.session.get(
                f"{self.base_urls['analysis']}/api/v1/tasks/{task_id}",
                headers={"Authorization": "Bearer test_token"}
            ) as response:
                status = await response.json()
                if status["status"] == "completed":
                    return status["result"]
                elif status["status"] == "failed":
                    raise Exception(f"Analysis failed: {status['error']}")
                await asyncio.sleep(1)
        raise TimeoutError("Analysis took too long to complete")

    @pytest.mark.e2e
    async def test_document_analysis_flow(self):
        """Тест полного процесса анализа документа"""
        # 1. Отправляем документ на анализ
        async with self.session.post(
            f"{self.base_urls['analysis']}/api/v1/analyze",
            json={
                "text": self.test_documents[0]["text"],
                "analyzer_id": "risk_analyzer",
                "options": {"detailed": True}
            },
            headers={"Authorization": "Bearer test_token"}
        ) as response:
            assert response.status == 200
            data = await response.json()
            assert "task_id" in data
            
            # 2. Ожидаем результатов анализа
            result = await self._wait_for_analysis(data["task_id"])
            
            # 3. Проверяем результаты
            assert "risks" in result
            assert isinstance(result["risks"], list)
            assert len(result["risks"]) > 0
            
            # 4. Проверяем наличие ожидаемых рисков
            found_risks = [risk["description"].lower() for risk in result["risks"]]
            for expected_risk in self.test_documents[0]["expected_risks"]:
                assert any(expected_risk in risk for risk in found_risks)

    @pytest.mark.e2e
    async def test_multiple_documents_analysis(self):
        """Тест параллельного анализа нескольких документов"""
        # 1. Отправляем несколько документов на анализ
        tasks = []
        for doc in self.test_documents:
            async with self.session.post(
                f"{self.base_urls['analysis']}/api/v1/analyze",
                json={
                    "text": doc["text"],
                    "analyzer_id": "risk_analyzer"
                },
                headers={"Authorization": "Bearer test_token"}
            ) as response:
                assert response.status == 200
                data = await response.json()
                tasks.append(data["task_id"])
        
        # 2. Ожидаем завершения всех анализов
        results = await asyncio.gather(*[
            self._wait_for_analysis(task_id)
            for task_id in tasks
        ])
        
        # 3. Проверяем результаты
        assert len(results) == len(self.test_documents)
        for result in results:
            assert "risks" in result
            assert len(result["risks"]) > 0

    @pytest.mark.e2e
    async def test_error_handling_and_recovery(self):
        """Тест обработки ошибок и восстановления"""
        # 1. Пробуем отправить некорректный документ
        async with self.session.post(
            f"{self.base_urls['analysis']}/api/v1/analyze",
            json={
                "text": "",  # Пустой текст
                "analyzer_id": "risk_analyzer"
            },
            headers={"Authorization": "Bearer test_token"}
        ) as response:
            assert response.status == 400
            error = await response.json()
            assert "error" in error
        
        # 2. Отправляем корректный документ после ошибки
        async with self.session.post(
            f"{self.base_urls['analysis']}/api/v1/analyze",
            json={
                "text": self.test_documents[0]["text"],
                "analyzer_id": "risk_analyzer"
            },
            headers={"Authorization": "Bearer test_token"}
        ) as response:
            assert response.status == 200
            data = await response.json()
            result = await self._wait_for_analysis(data["task_id"])
            assert "risks" in result

    @pytest.mark.e2e
    async def test_analysis_with_different_options(self):
        """Тест анализа с различными опциями"""
        options_to_test = [
            {"detailed": True, "max_risks": 5},
            {"detailed": False, "max_risks": 3},
            {"format": "markdown"},
            {"format": "html"}
        ]
        
        for options in options_to_test:
            async with self.session.post(
                f"{self.base_urls['analysis']}/api/v1/analyze",
                json={
                    "text": self.test_documents[0]["text"],
                    "analyzer_id": "risk_analyzer",
                    "options": options
                },
                headers={"Authorization": "Bearer test_token"}
            ) as response:
                assert response.status == 200
                data = await response.json()
                result = await self._wait_for_analysis(data["task_id"])
                
                # Проверяем соответствие формата
                if options.get("format") == "markdown":
                    assert "##" in result["formatted_output"]
                elif options.get("format") == "html":
                    assert "<h2>" in result["formatted_output"]
                
                # Проверяем количество рисков
                if "max_risks" in options:
                    assert len(result["risks"]) <= options["max_risks"]