import pytest
import asyncio
import os
from typing import AsyncGenerator
from services.ai_gateway.src.gateway import AIGateway
from services.provider_service.src.service import ProviderService
from services.prompt_service.src.service import PromptService
from services.analysis_service.src.service import AnalysisService

# Конфигурация для тестового окружения
TEST_CONFIG = {
    "AI_GATEWAY_URL": "http://localhost:8000",
    "PROVIDER_SERVICE_URL": "http://localhost:8001",
    "PROMPT_SERVICE_URL": "http://localhost:8002",
    "ANALYSIS_SERVICE_URL": "http://localhost:8003",
    "AUTH_TOKEN": "test_token",
    "CACHE_TYPE": "memory",
    "LOG_LEVEL": "DEBUG"
}

@pytest.fixture(scope="session")
def event_loop():
    """Создает экземпляр event loop для всей тестовой сессии"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session")
def test_config():
    """Предоставляет конфигурацию для тестового окружения"""
    # Устанавливаем переменные окружения для тестов
    for key, value in TEST_CONFIG.items():
        os.environ[key] = str(value)
    return TEST_CONFIG

@pytest.fixture
async def ai_gateway(test_config) -> AsyncGenerator[AIGateway, None]:
    """Фикстура для AI Gateway с тестовой конфигурацией"""
    gateway = AIGateway()
    await gateway.initialize()
    yield gateway
    await gateway.close()

@pytest.fixture
async def provider_service(test_config) -> AsyncGenerator[ProviderService, None]:
    """Фикстура для Provider Service с тестовой конфигурацией"""
    service = ProviderService()
    await service.initialize()
    yield service
    await service.close()

@pytest.fixture
async def prompt_service(test_config) -> AsyncGenerator[PromptService, None]:
    """Фикстура для Prompt Service с тестовой конфигурацией"""
    service = PromptService()
    await service.initialize()
    yield service
    await service.close()

@pytest.fixture
async def analysis_service(test_config) -> AsyncGenerator[AnalysisService, None]:
    """Фикстура для Analysis Service с тестовой конфигурацией"""
    service = AnalysisService()
    await service.initialize()
    yield service
    await service.close()

@pytest.fixture
def mock_provider_response():
    """Фикстура для моков ответов от провайдера"""
    return {
        "response": "Mocked provider response",
        "metadata": {
            "model": "test-model",
            "tokens": {
                "prompt": 100,
                "completion": 50,
                "total": 150
            }
        }
    }

@pytest.fixture
def sample_documents():
    """Фикстура с тестовыми документами"""
    return [
        {
            "text": "Договор купли-продажи между ООО 'Компания' и ИП Иванов",
            "expected_risks": ["Отсутствие сроков поставки", "Нечеткие условия оплаты"]
        },
        {
            "text": "Соглашение о конфиденциальности",
            "expected_risks": ["Отсутствие срока действия", "Нечеткое определение конфиденциальной информации"]
        }
    ]

@pytest.fixture
def integration_test_markers():
    """Маркеры для интеграционных тестов"""
    return {
        "slow": pytest.mark.slow,
        "integration": pytest.mark.integration,
        "dependency": pytest.mark.dependency,
        "asyncio": pytest.mark.asyncio
    }