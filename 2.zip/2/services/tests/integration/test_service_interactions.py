import pytest
import asyncio
from unittest.mock import Mock
from services.ai_gateway.src.gateway import AIGateway
from services.provider_service.src.service import ProviderService
from services.prompt_service.src.service import PromptService
from services.analysis_service.src.service import AnalysisService

@pytest.fixture
async def ai_gateway():
    gateway = AIGateway()
    yield gateway
    # Очистка после тестов
    await gateway.close()

@pytest.fixture
async def provider_service():
    service = ProviderService()
    yield service
    # Очистка после тестов
    await service.close()

@pytest.fixture
async def prompt_service():
    service = PromptService()
    yield service
    # Очистка после тестов
    await service.close()

@pytest.fixture
async def analysis_service():
    service = AnalysisService()
    yield service
    # Очистка после тестов
    await service.close()

@pytest.mark.integration
@pytest.mark.asyncio
async def test_full_analysis_flow(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест полного процесса анализа документа через все сервисы"""
    # Подготовка
    document_text = "Sample contract text for analysis"
    
    # Выполнение анализа
    # 1. Analysis Service запрашивает анализ
    analysis_result = await analysis_service.analyze_text(
        text=document_text,
        analyzer_id="risk_analyzer"
    )
    
    # 2. Prompt Service генерирует промпт
    prompt = await prompt_service.process_prompt(
        "risk_analysis",
        {"text": document_text}
    )
    
    # 3. Provider Service выполняет запрос к модели
    provider_response = await provider_service.get_completion(
        provider="deepseek",
        prompt=prompt
    )
    
    # Проверки
    assert analysis_result is not None
    assert "risks" in analysis_result
    assert len(analysis_result["risks"]) > 0

@pytest.mark.integration
@pytest.mark.asyncio
async def test_error_propagation(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест корректной обработки ошибок между сервисами"""
    # Подготовка - имитируем ошибку в Provider Service
    provider_service.get_completion = Mock(side_effect=Exception("Provider error"))
    
    # Проверка распространения ошибки
    with pytest.raises(Exception) as exc_info:
        await analysis_service.analyze_text(
            text="Test document",
            analyzer_id="risk_analyzer"
        )
    assert "Provider error" in str(exc_info.value)

@pytest.mark.integration
@pytest.mark.asyncio
async def test_concurrent_requests(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест обработки параллельных запросов"""
    # Подготовка
    texts = [f"Document {i}" for i in range(5)]
    
    # Параллельное выполнение запросов
    tasks = [
        analysis_service.analyze_text(text, "risk_analyzer")
        for text in texts
    ]
    results = await asyncio.gather(*tasks)
    
    # Проверка
    assert len(results) == 5
    assert all("risks" in result for result in results)

@pytest.mark.integration
@pytest.mark.asyncio
async def test_service_authentication(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест аутентификации между сервисами"""
    # Подготовка - неверный токен
    ai_gateway.auth_token = "invalid_token"
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await analysis_service.analyze_text(
            text="Test document",
            analyzer_id="risk_analyzer"
        )
    assert "authentication" in str(exc_info.value).lower()

@pytest.mark.integration
@pytest.mark.asyncio
async def test_cache_consistency(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест согласованности кэша между сервисами"""
    # Подготовка
    text = "Test document"
    
    # Первый запрос
    result1 = await analysis_service.analyze_text(
        text=text,
        analyzer_id="risk_analyzer"
    )
    
    # Второй запрос (должен использовать кэш)
    result2 = await analysis_service.analyze_text(
        text=text,
        analyzer_id="risk_analyzer"
    )
    
    # Проверка
    assert result1 == result2
    # Проверяем, что второй запрос не дошел до Provider Service
    assert provider_service.get_completion.call_count == 1

@pytest.mark.integration
@pytest.mark.asyncio
async def test_service_fallback(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест механизма fallback между провайдерами"""
    # Подготовка - первый провайдер недоступен
    provider_service.get_completion = Mock(side_effect=[
        Exception("Primary provider error"),
        {"response": "Fallback response"}
    ])
    
    # Выполнение
    result = await analysis_service.analyze_text(
        text="Test document",
        analyzer_id="risk_analyzer",
        options={"fallback": True}
    )
    
    # Проверка
    assert result is not None
    assert provider_service.get_completion.call_count == 2

@pytest.mark.integration
@pytest.mark.asyncio
async def test_metrics_collection(ai_gateway, provider_service, prompt_service, analysis_service):
    """Тест сбора метрик при взаимодействии сервисов"""
    # Выполнение запроса
    await analysis_service.analyze_text(
        text="Test document",
        analyzer_id="risk_analyzer"
    )
    
    # Проверка метрик
    gateway_metrics = ai_gateway.get_metrics()
    provider_metrics = provider_service.get_metrics()
    prompt_metrics = prompt_service.get_metrics()
    analysis_metrics = analysis_service.get_metrics()
    
    assert gateway_metrics["requests_total"] > 0
    assert provider_metrics["requests_total"] > 0
    assert prompt_metrics["requests_total"] > 0
    assert analysis_metrics["requests_total"] > 0