import pytest
from httpx import AsyncClient
from services.ai_gateway.src.api import app as gateway_app
from services.provider_service.src.api import app as provider_app
from services.prompt_service.src.api import app as prompt_app
from services.analysis_service.src.api import app as analysis_app

@pytest.fixture
async def gateway_client():
    async with AsyncClient(app=gateway_app, base_url="http://test") as client:
        yield client

@pytest.fixture
async def provider_client():
    async with AsyncClient(app=provider_app, base_url="http://test") as client:
        yield client

@pytest.fixture
async def prompt_client():
    async with AsyncClient(app=prompt_app, base_url="http://test") as client:
        yield client

@pytest.fixture
async def analysis_client():
    async with AsyncClient(app=analysis_app, base_url="http://test") as client:
        yield client

@pytest.mark.integration
@pytest.mark.asyncio
async def test_analysis_api_flow(
    gateway_client,
    provider_client,
    prompt_client,
    analysis_client,
    test_config,
    sample_documents
):
    """Тест полного процесса анализа через API endpoints"""
    # 1. Запрос к Analysis Service для начала анализа
    analysis_response = await analysis_client.post(
        "/api/v1/analyze",
        json={
            "text": sample_documents[0]["text"],
            "analyzer_id": "risk_analyzer"
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert analysis_response.status_code == 200
    analysis_data = analysis_response.json()
    assert "task_id" in analysis_data

    # 2. Проверка статуса задачи
    task_status = await analysis_client.get(
        f"/api/v1/tasks/{analysis_data['task_id']}",
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert task_status.status_code == 200
    status_data = task_status.json()
    assert status_data["status"] in ["pending", "processing", "completed"]

@pytest.mark.integration
@pytest.mark.asyncio
async def test_provider_api_integration(provider_client, test_config):
    """Тест интеграции с Provider Service через API"""
    response = await provider_client.post(
        "/api/v1/completion",
        json={
            "provider": "deepseek",
            "prompt": "Test prompt",
            "options": {"temperature": 0.7}
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "response" in data
    assert "metadata" in data

@pytest.mark.integration
@pytest.mark.asyncio
async def test_prompt_api_integration(prompt_client, test_config):
    """Тест интеграции с Prompt Service через API"""
    response = await prompt_client.post(
        "/api/v1/prompts/process",
        json={
            "type": "risk_analysis",
            "params": {"text": "Sample contract text"}
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "prompt" in data
    assert "metadata" in data

@pytest.mark.integration
@pytest.mark.asyncio
async def test_gateway_api_integration(gateway_client, test_config):
    """Тест интеграции с AI Gateway через API"""
    response = await gateway_client.post(
        "/api/v1/process",
        json={
            "text": "Sample text for analysis",
            "analysis_type": "risk",
            "options": {"detailed": True}
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "result" in data
    assert "metadata" in data

@pytest.mark.integration
@pytest.mark.asyncio
async def test_error_handling_across_services(
    analysis_client,
    provider_client,
    test_config
):
    """Тест обработки ошибок между сервисами через API"""
    # 1. Запрос с неверным ID анализатора
    error_response = await analysis_client.post(
        "/api/v1/analyze",
        json={
            "text": "Test text",
            "analyzer_id": "invalid_analyzer"
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert error_response.status_code == 404
    
    # 2. Запрос с неверным провайдером
    provider_error = await provider_client.post(
        "/api/v1/completion",
        json={
            "provider": "invalid_provider",
            "prompt": "Test prompt"
        },
        headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
    )
    assert provider_error.status_code == 404

@pytest.mark.integration
@pytest.mark.asyncio
async def test_authentication_across_services(
    analysis_client,
    provider_client,
    prompt_client,
    gateway_client
):
    """Тест аутентификации между сервисами через API"""
    # Тест с неверным токеном
    invalid_token = "invalid_token"
    endpoints = [
        (analysis_client, "/api/v1/analyze"),
        (provider_client, "/api/v1/completion"),
        (prompt_client, "/api/v1/prompts/process"),
        (gateway_client, "/api/v1/process")
    ]
    
    for client, endpoint in endpoints:
        response = await client.post(
            endpoint,
            json={"test": "data"},
            headers={"Authorization": f"Bearer {invalid_token}"}
        )
        assert response.status_code == 401

@pytest.mark.integration
@pytest.mark.asyncio
async def test_concurrent_api_requests(
    analysis_client,
    test_config,
    sample_documents
):
    """Тест параллельной обработки запросов через API"""
    import asyncio
    
    # Создаем несколько параллельных запросов
    async def make_request(text):
        return await analysis_client.post(
            "/api/v1/analyze",
            json={
                "text": text,
                "analyzer_id": "risk_analyzer"
            },
            headers={"Authorization": f"Bearer {test_config['AUTH_TOKEN']}"}
        )
    
    # Запускаем запросы параллельно
    tasks = [
        make_request(doc["text"])
        for doc in sample_documents * 2  # Дублируем документы для большего количества запросов
    ]
    responses = await asyncio.gather(*tasks)
    
    # Проверяем результаты
    assert all(r.status_code == 200 for r in responses)
    assert all("task_id" in r.json() for r in responses)