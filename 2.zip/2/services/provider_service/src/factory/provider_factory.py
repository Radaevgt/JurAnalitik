from typing import Dict, Type, List
import logging

from ..interfaces import IProviderFactory, IProvider, ProviderConfig
from ..providers.enhanced_deepseek import EnhancedDeepSeekProvider
from ..providers.deepseek_r1 import DeepSeekR1Provider

logger = logging.getLogger(__name__)

class DeepSeekProviderFactory(IProviderFactory):
    """Фабрика для создания провайдеров DeepSeek"""

    # Маппинг типов провайдеров на их классы
    PROVIDER_TYPES: Dict[str, Type[IProvider]] = {
        'enhanced': EnhancedDeepSeekProvider,
        'r1': DeepSeekR1Provider
    }

    # Маппинг моделей на типы провайдеров
    MODEL_TO_PROVIDER: Dict[str, str] = {
        'deepseek-enhanced': 'enhanced',
        'deepseek-r1': 'r1'
    }

    async def create_provider(self, provider_type: str, config: ProviderConfig) -> IProvider:
        """
        Создание инстанса провайдера
        
        Args:
            provider_type: Тип провайдера ('enhanced' или 'r1')
            config: Конфигурация провайдера
            
        Returns:
            IProvider: Инстанс провайдера
            
        Raises:
            ValueError: Если тип провайдера не поддерживается
        """
        # Определяем тип провайдера по модели, если он не указан явно
        if not provider_type:
            provider_type = self._get_provider_type_by_model(config.model)

        if provider_type not in self.PROVIDER_TYPES:
            raise ValueError(
                f"Unsupported provider type: {provider_type}. "
                f"Supported types: {', '.join(self.PROVIDER_TYPES.keys())}"
            )

        try:
            # Создаем инстанс провайдера
            provider_class = self.PROVIDER_TYPES[provider_type]
            provider = provider_class()
            
            # Инициализируем провайдер с конфигурацией
            await provider.initialize(config)
            
            logger.info(
                f"Created and initialized {provider_type} provider "
                f"with model {config.model}"
            )
            
            return provider
            
        except Exception as e:
            logger.error(f"Failed to create provider {provider_type}: {str(e)}")
            raise

    def get_available_providers(self) -> List[str]:
        """
        Получение списка доступных типов провайдеров
        
        Returns:
            List[str]: Список типов провайдеров
        """
        return list(self.PROVIDER_TYPES.keys())

    def _get_provider_type_by_model(self, model: str) -> str:
        """
        Определение типа провайдера по названию модели
        
        Args:
            model: Название модели
            
        Returns:
            str: Тип провайдера
            
        Raises:
            ValueError: Если модель не поддерживается
        """
        for model_prefix, provider_type in self.MODEL_TO_PROVIDER.items():
            if model.startswith(model_prefix):
                return provider_type
                
        raise ValueError(
            f"Unsupported model: {model}. "
            f"Supported models: {', '.join(self.MODEL_TO_PROVIDER.keys())}"
        )