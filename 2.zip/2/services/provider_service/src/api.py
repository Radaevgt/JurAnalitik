from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, List, Any
import yaml
import logging
from pathlib import Path

from services.common.middleware.fastapi_monitoring import setup_monitoring
from .interfaces import ProviderConfig, AnalysisResult
from .service import ProviderService

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Создание FastAPI приложения
app = FastAPI(
    title="Provider Service API",
    description="API для управления AI провайдерами анализа документов",
    version="1.0.0"
)

# Загрузка конфигурации
config_path = Path(__file__).parent.parent / "config" / "config.yaml"
with open(config_path) as f:
    config = yaml.safe_load(f)

# Настройка CORS
# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config["service"]["cors_origins"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Настройка мониторинга
setup_monitoring(app)

# Создание сервиса
provider_service = ProviderService()

@app.get("/providers", response_model=List[str])
async def get_providers():
    """Получение списка доступных провайдеров"""
    try:
        return await provider_service.get_providers()
    except Exception as e:
        logger.error(f"Failed to get providers: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/providers", response_model=str)
async def create_provider(provider_type: str, config: ProviderConfig):
    """
    Создание нового провайдера
    
    Args:
        provider_type: Тип провайдера
        config: Конфигурация провайдера
    
    Returns:
        str: ID созданного провайдера
    """
    try:
        return await provider_service.create_provider(provider_type, config)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to create provider: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/providers/{provider_id}/analyze", response_model=AnalysisResult)
async def analyze_document(
    provider_id: str,
    document: Dict[str, Any],
    analysis_type: str
):
    """
    Анализ документа через указанный провайдер
    
    Args:
        provider_id: ID провайдера
        document: Документ для анализа
        analysis_type: Тип анализа
    
    Returns:
        AnalysisResult: Результат анализа
    """
    try:
        return await provider_service.analyze_document(
            provider_id, document, analysis_type
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/providers/{provider_id}/status", response_model=Dict[str, Any])
async def get_provider_status(provider_id: str):
    """
    Получение статуса провайдера
    
    Args:
        provider_id: ID провайдера
    
    Returns:
        Dict[str, Any]: Статус провайдера
    """
    try:
        return await provider_service.get_provider_status(provider_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to get provider status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/providers/{provider_id}/metrics", response_model=Dict[str, Any])
async def get_provider_metrics(provider_id: str):
    """
    Получение метрик провайдера
    
    Args:
        provider_id: ID провайдера
    
    Returns:
        Dict[str, Any]: Метрики провайдера
    """
    try:
        return await provider_service.get_provider_metrics(provider_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to get provider metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics", response_model=Dict[str, Any])
async def get_service_metrics():
    """Получение общих метрик сервиса"""
    metrics = {
        "total_providers": len(provider_service._providers),
        "provider_types": await provider_service.get_providers(),
        "providers": {
            pid: {
                "type": config.name,
                "model": config.model,
                "status": (await provider_service.get_provider_status(pid))["state"]
            }
            for pid, config in provider_service._provider_configs.items()
        }
    }
    return metrics

# Обработчик для graceful shutdown
@app.on_event("shutdown")
async def shutdown_event():
    """Корректное завершение работы сервиса"""
    try:
        await provider_service.__aexit__(None, None, None)
        logger.info("Provider service shut down successfully")
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")