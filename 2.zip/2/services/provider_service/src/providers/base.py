from abc import abstractmethod
from typing import Dict, Any
import asyncio
from datetime import datetime
import logging
from uuid import uuid4

from ..interfaces import IProvider, ProviderConfig, AnalysisResult

logger = logging.getLogger(__name__)

class AIProvider(IProvider):
    """Базовый класс для AI провайдеров"""

    def __init__(self):
        self.config: ProviderConfig = None
        self.provider_id: str = str(uuid4())
        self.last_request: datetime = None
        self.total_requests: int = 0
        self.failed_requests: int = 0
        self._status: Dict[str, Any] = {
            "state": "initialized",
            "last_error": None,
            "is_available": True
        }
        self._metrics: Dict[str, Any] = {
            "total_requests": 0,
            "failed_requests": 0,
            "average_response_time": 0,
            "total_response_time": 0
        }
        self._lock = asyncio.Lock()

    async def initialize(self, config: ProviderConfig) -> None:
        """Инициализация провайдера с конфигурацией"""
        self.config = config
        try:
            await self._validate_config()
            await self._setup_provider()
            self._status["state"] = "ready"
        except Exception as e:
            self._status["state"] = "error"
            self._status["last_error"] = str(e)
            self._status["is_available"] = False
            logger.error(f"Failed to initialize provider {self.config.name}: {e}")
            raise

    async def analyze_document(self, document: Dict[str, Any], analysis_type: str) -> AnalysisResult:
        """Анализ документа с метриками и обработкой ошибок"""
        start_time = datetime.now()
        
        try:
            async with self._lock:
                if not self._status["is_available"]:
                    raise RuntimeError(f"Provider {self.config.name} is not available")
                
                self.total_requests += 1
                self._metrics["total_requests"] += 1
                self.last_request = start_time
                
                result = await self._analyze_document_internal(document, analysis_type)
                
                # Обновляем метрики успешного запроса
                execution_time = (datetime.now() - start_time).total_seconds()
                self._update_metrics(execution_time, success=True)
                
                return AnalysisResult(
                    provider=self.config.name,
                    document_id=str(uuid4()),
                    analysis_type=analysis_type,
                    result=result,
                    metadata={
                        "execution_time": execution_time,
                        "provider_id": self.provider_id
                    },
                    created_at=datetime.now()
                )
                
        except Exception as e:
            self.failed_requests += 1
            self._metrics["failed_requests"] += 1
            execution_time = (datetime.now() - start_time).total_seconds()
            self._update_metrics(execution_time, success=False)
            
            self._status["last_error"] = str(e)
            logger.error(f"Analysis failed for provider {self.config.name}: {e}")
            raise

    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса провайдера"""
        return {
            **self._status,
            "provider_id": self.provider_id,
            "provider_name": self.config.name if self.config else None,
            "last_request": self.last_request.isoformat() if self.last_request else None,
            "total_requests": self.total_requests,
            "failed_requests": self.failed_requests
        }

    async def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик производительности"""
        return self._metrics

    def _update_metrics(self, execution_time: float, success: bool) -> None:
        """Обновление метрик производительности"""
        self._metrics["total_response_time"] += execution_time
        if success:
            total_successful = self._metrics["total_requests"] - self._metrics["failed_requests"]
            if total_successful > 0:
                self._metrics["average_response_time"] = (
                    self._metrics["total_response_time"] / total_successful
                )

    @abstractmethod
    async def _validate_config(self) -> None:
        """Валидация конфигурации провайдера"""
        pass

    @abstractmethod
    async def _setup_provider(self) -> None:
        """Настройка провайдера после инициализации"""
        pass

    @abstractmethod
    async def _analyze_document_internal(self, document: Dict[str, Any], 
                                       analysis_type: str) -> Dict[str, Any]:
        """Внутренняя реализация анализа документа"""
        pass