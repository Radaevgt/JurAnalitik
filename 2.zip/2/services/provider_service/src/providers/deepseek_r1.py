from typing import Dict, Any
import os
import aiohttp
import json
import logging
from datetime import datetime

from .base import AIProvider
from ..interfaces import ProviderConfig

logger = logging.getLogger(__name__)

class DeepSeekR1Provider(AIProvider):
    """Провайдер для модели DeepSeek R1"""

    REQUIRED_CONFIG_FIELDS = ['api_key', 'model', 'api_url']
    SUPPORTED_ANALYSIS_TYPES = [
        'risk_analysis',
        'compliance_analysis', 
        'business_analysis',
        'terminology_analysis',
        'structural_analysis',
        'comparison_analysis'
    ]

    def __init__(self):
        super().__init__()
        self.model = "deepseek-r1-0528"
        self.api_key = os.getenv("DEEPSEEK_API_KEY")
        self._session: aiohttp.ClientSession = None
        self._api_url: str = None
        self._metrics = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_response_time': 0.0
        }
        self._total_tokens = 0

    async def _validate_config(self) -> None:
        """Валидация конфигурации провайдера"""
        missing_fields = [
            field for field in self.REQUIRED_CONFIG_FIELDS 
            if not self.config.options.get(field)
        ]
        
        if missing_fields:
            logger.error(f"Missing configuration fields: {missing_fields}")
            raise ValueError(
                f"Missing required configuration fields: {', '.join(missing_fields)}"
            )

        if self.config.model not in self.config.options.get('available_models', []):
            logger.error(f"Model {self.config.model} is not available")
            raise ValueError(
                f"Model {self.config.model} is not available for DeepSeek R1 provider"
            )

    async def _setup_provider(self) -> None:
        """Настройка провайдера после инициализации"""
        try:
            self._api_url = self.config.options['api_url']
            self._session = aiohttp.ClientSession(
                headers={
                    'Authorization': f'Bearer {self.config.options["api_key"]}',
                    'Content-Type': 'application/json'
                }
            )
            
            # Проверка подключения к API
            async with self._session.get(f"{self._api_url}/health") as response:
                if response.status != 200:
                    raise ConnectionError(
                        f"Failed to connect to DeepSeek R1 API: {response.status}"
                    )
                logger.info("Successfully connected to DeepSeek R1 API")
                
        except Exception as e:
            logger.error(f"Failed to setup provider: {str(e)}")
            if self._session:
                await self._session.close()
            raise ConnectionError(f"Failed to connect to DeepSeek R1 API: {str(e)}")

    async def _analyze_document_internal(self, document: Dict[str, Any], 
                                      analysis_type: str) -> Dict[str, Any]:
        """Внутренняя реализация анализа документа"""
        if analysis_type not in self.SUPPORTED_ANALYSIS_TYPES:
            logger.error(f"Unsupported analysis type: {analysis_type}")
            raise ValueError(
                f"Analysis type {analysis_type} is not supported. "
                f"Supported types: {', '.join(self.SUPPORTED_ANALYSIS_TYPES)}"
            )

        start_time = datetime.now()
        try:
            request_data = {
                'model': self.config.model,
                'document': document,
                'analysis_type': analysis_type,
                'options': {
                    'language': document.get('language', 'ru'),
                    'format': document.get('format', 'text'),
                    'max_tokens': self.config.options.get('max_tokens', 4000),
                    'temperature': self.config.options.get('temperature', 0.7)
                }
            }

            async with self._session.post(
                f"{self._api_url}/analyze",
                json=request_data
            ) as response:
                if response.status != 200:
                    error_data = await response.text()
                    logger.error(f"API error: {response.status} - {error_data}")
                    raise RuntimeError(
                        f"DeepSeek R1 API error: {response.status} - {error_data}"
                    )
                
                result = await response.json()
                
                # Обновление метрик
                self._metrics['total_requests'] += 1
                self._metrics['successful_requests'] += 1
                self._metrics['total_response_time'] += (datetime.now() - start_time).total_seconds()
                self._total_tokens += result.get('tokens_used', 0)

                return {
                    'analysis': result['analysis'],
                    'confidence': result.get('confidence', 0.0),
                    'tokens_used': result.get('tokens_used', 0),
                    'processing_time': result.get('processing_time', 0.0)
                }

        except aiohttp.ClientError as e:
            self._metrics['failed_requests'] += 1
            logger.error(f"Network error during analysis: {e}")
            raise RuntimeError(f"Failed to communicate with DeepSeek R1 API: {str(e)}")
        
        except json.JSONDecodeError as e:
            self._metrics['failed_requests'] += 1
            logger.error(f"Failed to parse API response: {e}")
            raise RuntimeError("Invalid response format from DeepSeek R1 API")
        
        except Exception as e:
            self._metrics['failed_requests'] += 1
            logger.error(f"Unexpected error during analysis: {e}")
            raise

    async def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик производительности"""
        metrics = await super().get_metrics()
        
        metrics.update({
            'model': self.config.model,
            'api_latency': self._calculate_api_latency(),
            'tokens_per_request': self._calculate_tokens_per_request(),
            'success_rate': self._calculate_success_rate()
        })
        
        return metrics

    def _calculate_api_latency(self) -> float:
        """Расчет средней задержки API"""
        if self._metrics['total_requests'] == 0:
            return 0.0
        return self._metrics['total_response_time'] / self._metrics['total_requests']

    def _calculate_tokens_per_request(self) -> float:
        """Расчет среднего количества токенов на запрос"""
        if not hasattr(self, '_total_tokens'):
            return 0.0
        if self._metrics['total_requests'] == 0:
            return 0.0
        return self._total_tokens / self._metrics['total_requests']

    def _calculate_success_rate(self) -> float:
        """Расчет процента успешных запросов"""
        if self._metrics['total_requests'] == 0:
            return 0.0
        return (self._metrics['successful_requests'] / self._metrics['total_requests']) * 100

    async def __aenter__(self):
        """Контекстный менеджер для автоматического закрытия сессии"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Закрытие сессии при выходе из контекстного менеджера"""
        if self._session:
            await self._session.close()

    async def get_risk_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Анализ рисков документа"""
        return await self._analyze_document_internal(document, 'risk_analysis')

    async def get_business_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Бизнес-анализ документа"""
        return await self._analyze_document_internal(document, 'business_analysis')

    async def get_compliance_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Анализ соответствия нормативным требованиям"""
        return await self._analyze_document_internal(document, 'compliance_analysis')

    async def get_terminology_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Анализ терминологии документа"""
        return await self._analyze_document_internal(document, 'terminology_analysis')

    async def get_structural_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Анализ структуры документа"""
        return await self._analyze_document_internal(document, 'structural_analysis')

    async def get_comparison_analysis_prompt(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Сравнительный анализ документов"""
        return await self._analyze_document_internal(document, 'comparison_analysis')