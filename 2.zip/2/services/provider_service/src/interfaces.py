from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ProviderConfig:
    """Конфигурация провайдера"""
    name: str
    api_key: str
    model: str
    options: Dict[str, Any]

@dataclass
class AnalysisResult:
    """Результат анализа документа"""
    provider: str
    document_id: str
    analysis_type: str
    result: Dict[str, Any]
    metadata: Dict[str, Any]
    created_at: datetime

class IProvider(ABC):
    """Интерфейс провайдера AI"""
    
    @abstractmethod
    async def initialize(self, config: ProviderConfig) -> None:
        """Инициализация провайдера с конфигурацией"""
        pass
    
    @abstractmethod
    async def analyze_document(self, document: Dict[str, Any], analysis_type: str) -> AnalysisResult:
        """Анализ документа"""
        pass
    
    @abstractmethod
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса провайдера"""
        pass

    @abstractmethod
    async def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик производительности"""
        pass

class IProviderFactory(ABC):
    """Интерфейс фабрики провайдеров"""
    
    @abstractmethod
    async def create_provider(self, provider_type: str, config: ProviderConfig) -> IProvider:
        """Создание инстанса провайдера"""
        pass
    
    @abstractmethod
    def get_available_providers(self) -> List[str]:
        """Получение списка доступных провайдеров"""
        pass

class IProviderService(ABC):
    """Интерфейс сервиса управления провайдерами"""
    
    @abstractmethod
    async def get_providers(self) -> List[str]:
        """Получение списка доступных провайдеров"""
        pass
    
    @abstractmethod
    async def create_provider(self, provider_type: str, config: ProviderConfig) -> str:
        """Создание инстанса провайдера"""
        pass
    
    @abstractmethod
    async def analyze_document(self, provider_id: str, document: Dict[str, Any], 
                             analysis_type: str) -> AnalysisResult:
        """Анализ документа через указанный провайдер"""
        pass
    
    @abstractmethod
    async def get_provider_status(self, provider_id: str) -> Dict[str, Any]:
        """Получение статуса провайдера"""
        pass

    @abstractmethod
    async def get_provider_metrics(self, provider_id: str) -> Dict[str, Any]:
        """Получение метрик провайдера"""
        pass