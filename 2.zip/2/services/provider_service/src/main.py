from flask import Flask, request, jsonify
from providers.enhanced_deepseek import EnhancedDeepSeekProvider
import os

app = Flask(__name__)
provider = EnhancedDeepSeekProvider()

@app.route('/health')
def health_check():
    return {'status': 'ok'}

@app.route('/analyze', methods=['POST'])
def analyze_document():
    data = request.json
    result = provider.analyze_document(data['text'])
    return jsonify(result)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8001))
    app.run(host='0.0.0.0', port=port)