from typing import Dict, List, Any, Optional
import logging
import asyncio
from datetime import datetime
from uuid import uuid4

from .interfaces import (
    IProviderService, 
    IProviderFactory, 
    IProvider,
    ProviderConfig, 
    AnalysisResult
)
from .factory.provider_factory import DeepSeekProviderFactory

logger = logging.getLogger(__name__)

class ProviderService(IProviderService):
    """Сервис управления AI провайдерами"""

    def __init__(self):
        self._factory: IProviderFactory = DeepSeekProviderFactory()
        self._providers: Dict[str, IProvider] = {}
        self._provider_configs: Dict[str, ProviderConfig] = {}
        self._lock = asyncio.Lock()

    async def get_providers(self) -> List[str]:
        """Получение списка доступных провайдеров"""
        return self._factory.get_available_providers()

    async def create_provider(self, provider_type: str, config: ProviderConfig) -> str:
        """
        Создание инстанса провайдера
        
        Args:
            provider_type: Тип провайдера
            config: Конфигурация провайдера
            
        Returns:
            str: ID созданного провайдера
            
        Raises:
            ValueError: Если тип провайдера не поддерживается
            RuntimeError: Если не удалось создать провайдер
        """
        async with self._lock:
            try:
                provider = await self._factory.create_provider(provider_type, config)
                provider_id = str(uuid4())
                
                self._providers[provider_id] = provider
                self._provider_configs[provider_id] = config
                
                logger.info(
                    f"Created provider {provider_type} with ID {provider_id}"
                )
                
                return provider_id
                
            except Exception as e:
                logger.error(f"Failed to create provider: {str(e)}")
                raise RuntimeError(f"Failed to create provider: {str(e)}")

    async def analyze_document(
        self, 
        provider_id: str, 
        document: Dict[str, Any],
        analysis_type: str
    ) -> AnalysisResult:
        """
        Анализ документа через указанный провайдер
        
        Args:
            provider_id: ID провайдера
            document: Документ для анализа
            analysis_type: Тип анализа
            
        Returns:
            AnalysisResult: Результат анализа
            
        Raises:
            ValueError: Если провайдер не найден
            RuntimeError: Если анализ не удался
        """
        provider = self._get_provider(provider_id)
        
        try:
            return await provider.analyze_document(document, analysis_type)
        except Exception as e:
            logger.error(
                f"Document analysis failed for provider {provider_id}: {str(e)}"
            )
            raise RuntimeError(f"Analysis failed: {str(e)}")

    async def get_provider_status(self, provider_id: str) -> Dict[str, Any]:
        """
        Получение статуса провайдера
        
        Args:
            provider_id: ID провайдера
            
        Returns:
            Dict[str, Any]: Статус провайдера
            
        Raises:
            ValueError: Если провайдер не найден
        """
        provider = self._get_provider(provider_id)
        status = await provider.get_status()
        
        # Добавляем информацию о конфигурации
        config = self._provider_configs[provider_id]
        status.update({
            'config': {
                'name': config.name,
                'model': config.model,
                'options': config.options
            }
        })
        
        return status

    async def get_provider_metrics(self, provider_id: str) -> Dict[str, Any]:
        """
        Получение метрик провайдера
        
        Args:
            provider_id: ID провайдера
            
        Returns:
            Dict[str, Any]: Метрики провайдера
            
        Raises:
            ValueError: Если провайдер не найден
        """
        provider = self._get_provider(provider_id)
        return await provider.get_metrics()

    def _get_provider(self, provider_id: str) -> IProvider:
        """
        Получение провайдера по ID
        
        Args:
            provider_id: ID провайдера
            
        Returns:
            IProvider: Инстанс провайдера
            
        Raises:
            ValueError: Если провайдер не найден
        """
        provider = self._providers.get(provider_id)
        if not provider:
            raise ValueError(f"Provider {provider_id} not found")
        return provider

    async def __aenter__(self):
        """Контекстный менеджер для автоматического закрытия провайдеров"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Закрытие всех провайдеров при выходе из контекстного менеджера"""
        for provider in self._providers.values():
            try:
                await provider.__aexit__(exc_type, exc_val, exc_tb)
            except Exception as e:
                logger.error(f"Failed to close provider: {str(e)}")
        self._providers.clear()
        self._provider_configs.clear()