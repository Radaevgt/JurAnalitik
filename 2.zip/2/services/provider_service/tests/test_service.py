import pytest
import asyncio
from unittest.mock import Mock, AsyncMock
from datetime import datetime

from ..src.interfaces import ProviderConfig, AnalysisResult
from ..src.service import ProviderService
from ..src.providers.base import AIProvider

@pytest.fixture
def mock_provider():
    """Фикстура для создания мок-провайдера"""
    provider = AsyncMock(spec=AIProvider)
    provider.get_status.return_value = {
        "state": "ready",
        "is_available": True
    }
    provider.get_metrics.return_value = {
        "total_requests": 0,
        "failed_requests": 0
    }
    return provider

@pytest.fixture
def mock_factory(mock_provider):
    """Фикстура для создания мок-фабрики"""
    factory = Mock()
    factory.get_available_providers.return_value = ["enhanced", "r1"]
    factory.create_provider = AsyncMock(return_value=mock_provider)
    return factory

@pytest.fixture
async def service(mock_factory):
    """Фикстура для создания сервиса с мок-зависимостями"""
    service = ProviderService()
    service._factory = mock_factory
    yield service
    await service.__aexit__(None, None, None)

@pytest.mark.asyncio
async def test_get_providers(service):
    """Тест получения списка провайдеров"""
    providers = await service.get_providers()
    assert providers == ["enhanced", "r1"]

@pytest.mark.asyncio
async def test_create_provider(service, mock_factory):
    """Тест создания провайдера"""
    config = ProviderConfig(
        name="test",
        api_key="test-key",
        model="test-model",
        options={}
    )
    
    provider_id = await service.create_provider("enhanced", config)
    
    assert provider_id in service._providers
    mock_factory.create_provider.assert_called_once_with("enhanced", config)

@pytest.mark.asyncio
async def test_analyze_document(service, mock_provider):
    """Тест анализа документа"""
    # Создаем провайдера
    config = ProviderConfig(
        name="test",
        api_key="test-key",
        model="test-model",
        options={}
    )
    provider_id = await service.create_provider("enhanced", config)
    
    # Настраиваем мок для analyze_document
    expected_result = AnalysisResult(
        provider="test",
        document_id="test-doc",
        analysis_type="test",
        result={"key": "value"},
        metadata={},
        created_at=datetime.now()
    )
    mock_provider.analyze_document.return_value = expected_result
    
    # Выполняем анализ
    result = await service.analyze_document(
        provider_id,
        {"content": "test"},
        "test"
    )
    
    assert result == expected_result
    mock_provider.analyze_document.assert_called_once()

@pytest.mark.asyncio
async def test_get_provider_status(service, mock_provider):
    """Тест получения статуса провайдера"""
    # Создаем провайдера
    config = ProviderConfig(
        name="test",
        api_key="test-key",
        model="test-model",
        options={}
    )
    provider_id = await service.create_provider("enhanced", config)
    
    status = await service.get_provider_status(provider_id)
    
    assert status["state"] == "ready"
    assert status["is_available"] is True
    mock_provider.get_status.assert_called_once()

@pytest.mark.asyncio
async def test_get_provider_metrics(service, mock_provider):
    """Тест получения метрик провайдера"""
    # Создаем провайдера
    config = ProviderConfig(
        name="test",
        api_key="test-key",
        model="test-model",
        options={}
    )
    provider_id = await service.create_provider("enhanced", config)
    
    metrics = await service.get_provider_metrics(provider_id)
    
    assert metrics["total_requests"] == 0
    assert metrics["failed_requests"] == 0
    mock_provider.get_metrics.assert_called_once()

@pytest.mark.asyncio
async def test_provider_not_found(service):
    """Тест обработки ошибки при отсутствии провайдера"""
    with pytest.raises(ValueError):
        await service.get_provider_status("non-existent-id")

@pytest.mark.asyncio
async def test_provider_cleanup(service, mock_provider):
    """Тест очистки ресурсов при завершении работы"""
    # Создаем провайдера
    config = ProviderConfig(
        name="test",
        api_key="test-key",
        model="test-model",
        options={}
    )
    await service.create_provider("enhanced", config)
    
    # Завершаем работу сервиса
    await service.__aexit__(None, None, None)
    
    assert len(service._providers) == 0
    assert len(service._provider_configs) == 0