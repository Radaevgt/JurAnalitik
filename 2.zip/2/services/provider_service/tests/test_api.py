import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch
from datetime import datetime

from ..src.api import app
from ..src.interfaces import ProviderConfig, AnalysisResult

@pytest.fixture
def client():
    """Фикстура для создания тестового клиента"""
    return TestClient(app)

@pytest.fixture
def mock_service():
    """Фикстура для создания мока сервиса"""
    with patch('src.api.provider_service') as mock:
        # Настраиваем методы мока
        mock.get_providers = AsyncMock(return_value=["enhanced", "r1"])
        mock.create_provider = AsyncMock(return_value="test-provider-id")
        mock.get_provider_status = AsyncMock(return_value={
            "state": "ready",
            "is_available": True
        })
        mock.get_provider_metrics = AsyncMock(return_value={
            "total_requests": 0,
            "failed_requests": 0
        })
        mock.analyze_document = AsyncMock(return_value=AnalysisResult(
            provider="test",
            document_id="test-doc",
            analysis_type="test",
            result={"key": "value"},
            metadata={},
            created_at=datetime.now()
        ))
        yield mock

def test_get_providers(client, mock_service):
    """Тест GET /providers"""
    response = client.get("/providers")
    assert response.status_code == 200
    assert response.json() == ["enhanced", "r1"]

def test_create_provider(client, mock_service):
    """Тест POST /providers"""
    config = {
        "name": "test",
        "api_key": "test-key",
        "model": "test-model",
        "options": {}
    }
    
    response = client.post("/providers", params={"provider_type": "enhanced"}, json=config)
    
    assert response.status_code == 200
    assert response.json() == "test-provider-id"
    mock_service.create_provider.assert_called_once()

def test_analyze_document(client, mock_service):
    """Тест POST /providers/{provider_id}/analyze"""
    document = {
        "content": "test content",
        "language": "ru"
    }
    
    response = client.post(
        "/providers/test-id/analyze",
        params={"analysis_type": "test"},
        json=document
    )
    
    assert response.status_code == 200
    result = response.json()
    assert result["provider"] == "test"
    assert result["analysis_type"] == "test"
    mock_service.analyze_document.assert_called_once()

def test_get_provider_status(client, mock_service):
    """Тест GET /providers/{provider_id}/status"""
    response = client.get("/providers/test-id/status")
    
    assert response.status_code == 200
    status = response.json()
    assert status["state"] == "ready"
    assert status["is_available"] is True
    mock_service.get_provider_status.assert_called_once()

def test_get_provider_metrics(client, mock_service):
    """Тест GET /providers/{provider_id}/metrics"""
    response = client.get("/providers/test-id/metrics")
    
    assert response.status_code == 200
    metrics = response.json()
    assert metrics["total_requests"] == 0
    assert metrics["failed_requests"] == 0
    mock_service.get_provider_metrics.assert_called_once()

def test_get_service_metrics(client):
    """Тест GET /metrics"""
    response = client.get("/metrics")
    
    assert response.status_code == 200
    metrics = response.json()
    assert "total_providers" in metrics
    assert "provider_types" in metrics
    assert "providers" in metrics

def test_provider_not_found(client, mock_service):
    """Тест обработки ошибки при отсутствии провайдера"""
    mock_service.get_provider_status.side_effect = ValueError("Provider not found")
    
    response = client.get("/providers/non-existent-id/status")
    
    assert response.status_code == 404
    assert "Provider not found" in response.json()["detail"]

def test_invalid_provider_config(client, mock_service):
    """Тест обработки некорректной конфигурации провайдера"""
    mock_service.create_provider.side_effect = ValueError("Invalid config")
    
    config = {
        "name": "test",
        "api_key": "",  # Пустой API ключ
        "model": "test-model",
        "options": {}
    }
    
    response = client.post("/providers", params={"provider_type": "enhanced"}, json=config)
    
    assert response.status_code == 400
    assert "Invalid config" in response.json()["detail"]

def test_analysis_error(client, mock_service):
    """Тест обработки ошибки при анализе документа"""
    mock_service.analyze_document.side_effect = RuntimeError("Analysis failed")
    
    document = {
        "content": "test content",
        "language": "ru"
    }
    
    response = client.post(
        "/providers/test-id/analyze",
        params={"analysis_type": "test"},
        json=document
    )
    
    assert response.status_code == 500
    assert "Analysis failed" in response.json()["detail"]