import pytest
from unittest.mock import Mock, patch
from src.providers.deepseek_r1 import DeepSeekProvider

@pytest.fixture
def mock_api_client():
    return Mock()

@pytest.fixture
def provider(mock_api_client):
    provider = DeepSeekProvider()
    provider.api_client = mock_api_client
    return provider

def test_provider_initialization(provider):
    assert provider.name == "deepseek"
    assert provider.model_name == "deepseek-chat"
    assert provider.is_available() is True

@pytest.mark.asyncio
async def test_get_completion_success(provider, mock_api_client):
    # Подготовка
    mock_api_client.create_completion.return_value = {
        "id": "test-1",
        "choices": [{"text": "Test response"}],
        "usage": {
            "prompt_tokens": 5,
            "completion_tokens": 2,
            "total_tokens": 7
        }
    }
    
    # Выполнение
    result = await provider.get_completion(
        "Test prompt",
        {"temperature": 0.7}
    )
    
    # Проверка
    assert result["id"] == "test-1"
    assert result["response"] == "Test response"
    assert result["usage"]["total_tokens"] == 7
    mock_api_client.create_completion.assert_called_once_with(
        model="deepseek-chat",
        prompt="Test prompt",
        temperature=0.7
    )

@pytest.mark.asyncio
async def test_get_completion_with_streaming(provider, mock_api_client):
    # Подготовка
    mock_api_client.create_completion.return_value = {
        "id": "test-2",
        "choices": [{"text": "Test response"}],
        "usage": {"total_tokens": 5}
    }
    
    # Выполнение
    result = await provider.get_completion(
        "Test prompt",
        {"temperature": 0.7, "stream": True}
    )
    
    # Проверка
    assert result["id"] == "test-2"
    assert result["response"] == "Test response"
    mock_api_client.create_completion.assert_called_once_with(
        model="deepseek-chat",
        prompt="Test prompt",
        temperature=0.7,
        stream=True
    )

@pytest.mark.asyncio
async def test_get_completion_error_handling(provider, mock_api_client):
    # Подготовка
    mock_api_client.create_completion.side_effect = Exception("API Error")
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await provider.get_completion("Test prompt")
    assert "API Error" in str(exc_info.value)

def test_validate_model_specific_options(provider):
    # Проверка валидных опций
    valid_options = {
        "temperature": 0.7,
        "max_tokens": 100,
        "top_p": 0.9
    }
    provider.validate_options(valid_options)  # Не должно вызывать исключений
    
    # Проверка невалидных опций
    invalid_options = {
        "temperature": 1.5,  # Должно быть от 0 до 1
        "max_tokens": 5000,  # Превышает лимит модели
        "invalid_param": "value"  # Неподдерживаемый параметр
    }
    with pytest.raises(ValueError):
        provider.validate_options(invalid_options)

@pytest.mark.asyncio
async def test_retry_mechanism(provider, mock_api_client):
    # Подготовка
    mock_api_client.create_completion.side_effect = [
        Exception("Temporary error"),
        {
            "id": "test-3",
            "choices": [{"text": "Success after retry"}],
            "usage": {"total_tokens": 3}
        }
    ]
    
    # Выполнение
    result = await provider.get_completion("Test prompt")
    
    # Проверка
    assert result["response"] == "Success after retry"
    assert mock_api_client.create_completion.call_count == 2

def test_model_capabilities(provider):
    capabilities = provider.get_capabilities()
    assert "text_completion" in capabilities
    assert "chat" in capabilities
    assert isinstance(capabilities["max_tokens"], int)
    assert isinstance(capabilities["supported_languages"], list)

@pytest.mark.asyncio
async def test_context_handling(provider, mock_api_client):
    # Подготовка
    mock_api_client.create_completion.return_value = {
        "id": "test-4",
        "choices": [{"text": "Response with context"}],
        "usage": {"total_tokens": 10}
    }
    
    # Выполнение
    result = await provider.get_completion(
        "Test prompt",
        {
            "context": "Previous conversation",
            "temperature": 0.7
        }
    )
    
    # Проверка
    assert result["response"] == "Response with context"
    mock_api_client.create_completion.assert_called_once()
    call_args = mock_api_client.create_completion.call_args[1]
    assert "Previous conversation" in call_args["prompt"]