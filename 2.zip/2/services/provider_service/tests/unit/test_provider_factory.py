import pytest
from unittest.mock import Mock, patch
from src.factory.provider_factory import ProviderFactory
from src.providers.deepseek_r1 import DeepSeekProvider
from src.providers.enhanced_deepseek import EnhancedDeepSeekProvider

@pytest.fixture
def factory():
    return ProviderFactory()

def test_factory_initialization(factory):
    assert factory is not None
    assert hasattr(factory, 'providers')
    assert isinstance(factory.providers, dict)

def test_register_provider(factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.name = "test_provider"
    
    # Выполнение
    factory.register_provider(mock_provider)
    
    # Проверка
    assert "test_provider" in factory.providers
    assert factory.providers["test_provider"] == mock_provider

def test_get_provider_success(factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.name = "test_provider"
    factory.register_provider(mock_provider)
    
    # Выполнение
    provider = factory.get_provider("test_provider")
    
    # Проверка
    assert provider == mock_provider

def test_get_provider_not_found(factory):
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        factory.get_provider("non_existent_provider")
    assert "Provider not found" in str(exc_info.value)

def test_get_all_providers(factory):
    # Подготовка
    mock_provider1 = Mock()
    mock_provider1.name = "provider1"
    mock_provider2 = Mock()
    mock_provider2.name = "provider2"
    
    factory.register_provider(mock_provider1)
    factory.register_provider(mock_provider2)
    
    # Выполнение
    providers = factory.get_all_providers()
    
    # Проверка
    assert len(providers) == 2
    assert "provider1" in providers
    assert "provider2" in providers

def test_default_providers_registration():
    # Выполнение
    factory = ProviderFactory()
    
    # Проверка
    providers = factory.get_all_providers()
    assert "deepseek" in providers
    assert "enhanced_deepseek" in providers
    
    deepseek = factory.get_provider("deepseek")
    enhanced = factory.get_provider("enhanced_deepseek")
    
    assert isinstance(deepseek, DeepSeekProvider)
    assert isinstance(enhanced, EnhancedDeepSeekProvider)

def test_provider_configuration(factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.name = "test_provider"
    factory.register_provider(mock_provider)
    
    config = {
        "test_provider": {
            "api_key": "test_key",
            "timeout": 30
        }
    }
    
    # Выполнение
    factory.configure_providers(config)
    
    # Проверка
    mock_provider.configure.assert_called_once_with({
        "api_key": "test_key",
        "timeout": 30
    })

def test_provider_health_check(factory):
    # Подготовка
    mock_provider1 = Mock()
    mock_provider1.name = "provider1"
    mock_provider1.health_check.return_value = {"status": "ok"}
    
    mock_provider2 = Mock()
    mock_provider2.name = "provider2"
    mock_provider2.health_check.return_value = {"status": "error"}
    
    factory.register_provider(mock_provider1)
    factory.register_provider(mock_provider2)
    
    # Выполнение
    status = factory.check_providers_health()
    
    # Проверка
    assert status["provider1"]["status"] == "ok"
    assert status["provider2"]["status"] == "error"
    mock_provider1.health_check.assert_called_once()
    mock_provider2.health_check.assert_called_once()

def test_provider_validation(factory):
    # Подготовка
    invalid_provider = Mock()
    invalid_provider.name = None  # Невалидный провайдер без имени
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        factory.register_provider(invalid_provider)
    assert "Invalid provider" in str(exc_info.value)

def test_duplicate_provider_registration(factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.name = "test_provider"
    factory.register_provider(mock_provider)
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        factory.register_provider(mock_provider)
    assert "Provider already registered" in str(exc_info.value)