import pytest
from unittest.mock import Mock, patch
from src.service import ProviderService
from src.factory.provider_factory import ProviderFactory

@pytest.fixture
def mock_factory():
    return Mock(spec=ProviderFactory)

@pytest.fixture
def service(mock_factory):
    return ProviderService(provider_factory=mock_factory)

def test_service_initialization(service):
    assert service is not None
    assert hasattr(service, 'provider_factory')

@pytest.mark.asyncio
async def test_get_completion_success(service, mock_factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.get_completion.return_value = {
        "id": "test-1",
        "response": "Test response",
        "usage": {"total_tokens": 10}
    }
    mock_factory.get_provider.return_value = mock_provider
    
    # Выполнение
    result = await service.get_completion(
        provider="test_provider",
        prompt="Test prompt",
        options={"temperature": 0.7}
    )
    
    # Проверка
    assert result["id"] == "test-1"
    assert result["response"] == "Test response"
    assert result["usage"]["total_tokens"] == 10
    mock_factory.get_provider.assert_called_once_with("test_provider")
    mock_provider.get_completion.assert_called_once_with(
        "Test prompt",
        {"temperature": 0.7}
    )

@pytest.mark.asyncio
async def test_get_completion_provider_not_found(service, mock_factory):
    # Подготовка
    mock_factory.get_provider.side_effect = ValueError("Provider not found")
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        await service.get_completion(
            provider="non_existent",
            prompt="Test prompt"
        )
    assert "Provider not found" in str(exc_info.value)

@pytest.mark.asyncio
async def test_get_completion_provider_error(service, mock_factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.get_completion.side_effect = Exception("Provider error")
    mock_factory.get_provider.return_value = mock_provider
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await service.get_completion(
            provider="test_provider",
            prompt="Test prompt"
        )
    assert "Provider error" in str(exc_info.value)

def test_get_available_providers(service, mock_factory):
    # Подготовка
    mock_factory.get_all_providers.return_value = {
        "provider1": {"status": "active"},
        "provider2": {"status": "active"}
    }
    
    # Выполнение
    providers = service.get_available_providers()
    
    # Проверка
    assert len(providers) == 2
    assert "provider1" in providers
    assert "provider2" in providers
    mock_factory.get_all_providers.assert_called_once()

def test_get_provider_info(service, mock_factory):
    # Подготовка
    mock_provider = Mock()
    mock_provider.get_metadata.return_value = {
        "name": "test_provider",
        "version": "1.0",
        "capabilities": ["completion"]
    }
    mock_factory.get_provider.return_value = mock_provider
    
    # Выполнение
    info = service.get_provider_info("test_provider")
    
    # Проверка
    assert info["name"] == "test_provider"
    assert info["version"] == "1.0"
    assert "completion" in info["capabilities"]

def test_health_check(service, mock_factory):
    # Подготовка
    mock_factory.check_providers_health.return_value = {
        "provider1": {"status": "ok"},
        "provider2": {"status": "error"}
    }
    
    # Выполнение
    status = service.health_check()
    
    # Проверка
    assert status["provider1"]["status"] == "ok"
    assert status["provider2"]["status"] == "error"
    mock_factory.check_providers_health.assert_called_once()

@pytest.mark.asyncio
async def test_fallback_provider(service, mock_factory):
    # Подготовка
    primary_provider = Mock()
    primary_provider.get_completion.side_effect = Exception("Primary provider error")
    
    fallback_provider = Mock()
    fallback_provider.get_completion.return_value = {
        "id": "fallback-1",
        "response": "Fallback response",
        "usage": {"total_tokens": 5}
    }
    
    mock_factory.get_provider.side_effect = [primary_provider, fallback_provider]
    
    # Выполнение
    result = await service.get_completion_with_fallback(
        primary_provider="primary",
        fallback_provider="fallback",
        prompt="Test prompt"
    )
    
    # Проверка
    assert result["id"] == "fallback-1"
    assert result["response"] == "Fallback response"
    assert result["provider"] == "fallback"
    primary_provider.get_completion.assert_called_once()
    fallback_provider.get_completion.assert_called_once()

def test_configure_providers(service, mock_factory):
    # Подготовка
    config = {
        "provider1": {"api_key": "key1"},
        "provider2": {"api_key": "key2"}
    }
    
    # Выполнение
    service.configure_providers(config)
    
    # Проверка
    mock_factory.configure_providers.assert_called_once_with(config)