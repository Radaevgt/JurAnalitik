import pytest
import aiohttp
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime

from ...src.providers.deepseek_r1 import DeepSeekR1Provider
from ...src.interfaces import ProviderConfig

@pytest.fixture
async def provider():
    """Фикстура для создания провайдера"""
    provider = DeepSeekR1Provider()
    provider.config = ProviderConfig(
        name="DeepSeek R1",
        model="deepseek-r1-0528",
        options={
            'api_key': 'test_key',
            'api_url': 'http://test.api',
            'model': 'deepseek-r1-0528',
            'available_models': ['deepseek-r1-0528'],
            'max_tokens': 4000,
            'temperature': 0.7
        }
    )
    return provider

@pytest.mark.asyncio
async def test_validate_config_success(provider):
    """Тест успешной валидации конфигурации"""
    await provider._validate_config()

@pytest.mark.asyncio
async def test_validate_config_missing_fields():
    """Тест валидации с отсутствующими полями"""
    provider = DeepSeekR1Provider()
    provider.config = ProviderConfig(
        name="DeepSeek R1",
        model="deepseek-r1-0528",
        options={}
    )
    
    with pytest.raises(ValueError) as exc:
        await provider._validate_config()
    assert "Missing required configuration fields" in str(exc.value)

@pytest.mark.asyncio
async def test_validate_config_invalid_model():
    """Тест валидации с неподдерживаемой моделью"""
    provider = DeepSeekR1Provider()
    provider.config = ProviderConfig(
        name="DeepSeek R1",
        model="invalid-model",
        options={
            'api_key': 'test_key',
            'api_url': 'http://test.api',
            'model': 'invalid-model',
            'available_models': ['deepseek-r1-0528']
        }
    )
    
    with pytest.raises(ValueError) as exc:
        await provider._validate_config()
    assert "is not available for DeepSeek R1 provider" in str(exc.value)

@pytest.mark.asyncio
async def test_setup_provider_success(provider):
    """Тест успешной настройки провайдера"""
    mock_response = AsyncMock()
    mock_response.status = 200
    
    with patch('aiohttp.ClientSession.get', return_value=mock_response):
        await provider._setup_provider()
        assert provider._session is not None
        assert provider._api_url == 'http://test.api'

@pytest.mark.asyncio
async def test_setup_provider_failure(provider):
    """Тест ошибки при настройке провайдера"""
    mock_response = AsyncMock()
    mock_response.status = 500
    
    with patch('aiohttp.ClientSession.get', return_value=mock_response):
        with pytest.raises(ConnectionError):
            await provider._setup_provider()

@pytest.mark.asyncio
async def test_analyze_document_success(provider):
    """Тест успешного анализа документа"""
    mock_response = AsyncMock()
    mock_response.status = 200
    mock_response.json = AsyncMock(return_value={
        'analysis': 'Test analysis',
        'confidence': 0.9,
        'tokens_used': 100,
        'processing_time': 1.5
    })
    
    with patch('aiohttp.ClientSession.post', return_value=mock_response):
        result = await provider._analyze_document_internal(
            {'text': 'Test document'},
            'risk_analysis'
        )
        assert result['analysis'] == 'Test analysis'
        assert result['confidence'] == 0.9
        assert result['tokens_used'] == 100

@pytest.mark.asyncio
async def test_analyze_document_api_error(provider):
    """Тест ошибки API при анализе документа"""
    mock_response = AsyncMock()
    mock_response.status = 500
    mock_response.text = AsyncMock(return_value="API Error")
    
    with patch('aiohttp.ClientSession.post', return_value=mock_response):
        with pytest.raises(RuntimeError) as exc:
            await provider._analyze_document_internal(
                {'text': 'Test document'},
                'risk_analysis'
            )
        assert "DeepSeek R1 API error" in str(exc.value)

@pytest.mark.asyncio
async def test_analyze_document_invalid_type(provider):
    """Тест анализа с неподдерживаемым типом"""
    with pytest.raises(ValueError) as exc:
        await provider._analyze_document_internal(
            {'text': 'Test document'},
            'invalid_type'
        )
    assert "Analysis type invalid_type is not supported" in str(exc.value)

@pytest.mark.asyncio
async def test_get_metrics(provider):
    """Тест получения метрик"""
    provider._metrics = {
        'total_requests': 10,
        'successful_requests': 8,
        'failed_requests': 2,
        'total_response_time': 5.0
    }
    provider._total_tokens = 1000
    
    metrics = await provider.get_metrics()
    assert metrics['model'] == 'deepseek-r1-0528'
    assert metrics['api_latency'] == 0.5
    assert metrics['tokens_per_request'] == 100
    assert metrics['success_rate'] == 80.0

@pytest.mark.asyncio
async def test_context_manager(provider):
    """Тест работы контекстного менеджера"""
    async with provider as p:
        assert p == provider
    assert provider._session is None