import pytest
from unittest.mock import Mock, patch
from src.providers.base import BaseProvider

class TestProvider(BaseProvider):
    """Тестовый провайдер для проверки базового класса"""
    def __init__(self):
        super().__init__("test_provider")
    
    async def get_completion(self, prompt: str, options: dict = None):
        return {
            "id": "test-1",
            "response": f"Response to: {prompt}",
            "usage": {"total_tokens": len(prompt.split())}
        }

@pytest.fixture
def provider():
    return TestProvider()

def test_provider_initialization(provider):
    assert provider.name == "test_provider"
    assert provider.is_available() is True

@pytest.mark.asyncio
async def test_get_completion_success(provider):
    # Выполнение
    result = await provider.get_completion("Test prompt", {"temperature": 0.7})
    
    # Проверка
    assert result["id"] == "test-1"
    assert result["response"] == "Response to: Test prompt"
    assert result["usage"]["total_tokens"] == 2

@pytest.mark.asyncio
async def test_get_completion_with_default_options(provider):
    # Выполнение
    result = await provider.get_completion("Test prompt")
    
    # Проверка
    assert result["id"] == "test-1"
    assert result["response"] == "Response to: Test prompt"

@pytest.mark.asyncio
async def test_validate_prompt_length(provider):
    # Подготовка
    long_prompt = "test " * 1000  # Создаем длинный промпт
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        await provider.get_completion(long_prompt)
    assert "Prompt too long" in str(exc_info.value)

def test_validate_options(provider):
    # Подготовка
    invalid_options = {
        "temperature": 2.0,  # Должно быть от 0 до 1
        "max_tokens": -1     # Должно быть положительным
    }
    
    # Проверка
    with pytest.raises(ValueError) as exc_info:
        provider.validate_options(invalid_options)
    assert "Invalid options" in str(exc_info.value)

@pytest.mark.asyncio
async def test_rate_limiting(provider):
    # Подготовка
    provider.rate_limit = 2  # Ограничиваем до 2 запросов
    
    # Выполнение первых двух запросов
    await provider.get_completion("Test 1")
    await provider.get_completion("Test 2")
    
    # Проверка третьего запроса
    with pytest.raises(Exception) as exc_info:
        await provider.get_completion("Test 3")
    assert "Rate limit exceeded" in str(exc_info.value)

def test_provider_status(provider):
    # Проверка начального статуса
    assert provider.get_status() == {
        "name": "test_provider",
        "available": True,
        "error_rate": 0.0,
        "average_latency": 0.0
    }
    
    # Имитация ошибок
    provider.record_error("Test error")
    provider.record_latency(0.5)
    
    # Проверка обновленного статуса
    status = provider.get_status()
    assert status["error_rate"] > 0
    assert status["average_latency"] == 0.5

@pytest.mark.asyncio
async def test_error_handling(provider):
    # Подготовка
    error_provider = TestProvider()
    error_provider.get_completion = Mock(side_effect=Exception("API Error"))
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await error_provider.get_completion("Test prompt")
    assert "API Error" in str(exc_info.value)

def test_provider_metadata(provider):
    # Проверка метаданных провайдера
    metadata = provider.get_metadata()
    assert metadata["name"] == "test_provider"
    assert "version" in metadata
    assert "capabilities" in metadata
    assert "supported_languages" in metadata

def test_provider_configuration(provider):
    # Подготовка
    config = {
        "api_key": "test_key",
        "timeout": 30,
        "max_retries": 3
    }
    
    # Выполнение
    provider.configure(config)
    
    # Проверка
    assert provider.config["api_key"] == "test_key"
    assert provider.config["timeout"] == 30
    assert provider.config["max_retries"] == 3