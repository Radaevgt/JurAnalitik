"""
Интерфейсы для взаимодействия между микросервисами
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, List

@dataclass
class ServiceRequest:
    """Структура запроса к сервису"""
    method: str
    path: str
    data: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None

@dataclass
class ServiceResponse:
    """Структура ответа от сервиса"""
    status: int
    data: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None
    error: Optional[str] = None

class ServiceInterface(ABC):
    """Базовый интерфейс для всех сервисов"""
    
    @abstractmethod
    async def handle_request(self, request: ServiceRequest) -> ServiceResponse:
        """Обработка входящего запроса"""
        pass
    
    @abstractmethod
    async def health_check(self) -> bool:
        """Проверка работоспособности сервиса"""
        pass

class PromptServiceInterface(ServiceInterface):
    """Интерфейс для сервиса обработки промптов"""
    
    @abstractmethod
    async def process_prompt(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Обработка промпта"""
        pass
    
    @abstractmethod
    async def validate_prompt(self, prompt: str) -> bool:
        """Валидация промпта"""
        pass

class ProviderServiceInterface(ServiceInterface):
    """Интерфейс для сервиса провайдеров AI"""
    
    @abstractmethod
    async def get_available_models(self) -> List[str]:
        """Получение списка доступных моделей"""
        pass
    
    @abstractmethod
    async def execute_model(
        self, 
        model_id: str, 
        input_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Выполнение запроса к модели"""
        pass

class AnalysisServiceInterface(ServiceInterface):
    """Интерфейс для сервиса анализа"""
    
    @abstractmethod
    async def analyze_response(
        self, 
        response: Dict[str, Any], 
        criteria: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Анализ ответа от модели"""
        pass
    
    @abstractmethod
    async def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик анализа"""
        pass

class ServiceRegistry(ABC):
    """Интерфейс для регистрации сервисов"""
    
    @abstractmethod
    def register_service(self, service_type: str, service: ServiceInterface) -> None:
        """Регистрация сервиса"""
        pass
    
    @abstractmethod
    def unregister_service(self, service_type: str, service: ServiceInterface) -> None:
        """Удаление сервиса из регистра"""
        pass
    
    @abstractmethod
    def get_service(self, service_type: str) -> Optional[ServiceInterface]:
        """Получение сервиса по типу"""
        pass
    
    @abstractmethod
    def list_services(self) -> Dict[str, List[ServiceInterface]]:
        """Получение списка всех зарегистрированных сервисов"""
        pass