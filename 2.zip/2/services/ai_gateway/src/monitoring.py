from prometheus_client import Counter, Histogram, Gauge, REGISTRY, generate_latest
from typing import Optional
import time

# Метрики для HTTP запросов
REQUEST_COUNT = Counter(
    'gateway_requests_total',
    'Total gateway request count',
    ['service_type', 'status']
)

REQUEST_LATENCY = Histogram(
    'gateway_request_duration_seconds',
    'Gateway request latency in seconds',
    ['service_type']
)

ACTIVE_SERVICES = Gauge(
    'gateway_active_services',
    'Number of active services by type',
    ['service_type']
)

class GatewayMetrics:
    """Класс для сбора метрик шлюза"""

    @staticmethod
    def track_request(service_type: str, start_time: float, success: bool = True) -> None:
        """Отслеживание запроса"""
        # Измеряем время выполнения
        latency = time.time() - start_time
        REQUEST_LATENCY.labels(
            service_type=service_type
        ).observe(latency)

        # Увеличиваем счетчик запросов
        REQUEST_COUNT.labels(
            service_type=service_type,
            status='success' if success else 'error'
        ).inc()

    @staticmethod
    def update_service_count(service_type: str, count: int) -> None:
        """Обновление количества активных сервисов"""
        ACTIVE_SERVICES.labels(
            service_type=service_type
        ).set(count)

    @staticmethod
    def get_metrics() -> bytes:
        """Получение текущих метрик"""
        return generate_latest(REGISTRY)