"""
AI Gateway Service - основной класс для маршрутизации и обработки запросов.
"""
import logging
import time
from typing import Dict, List, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod
from .monitoring import GatewayMetrics

@dataclass
class ServiceConfig:
    """Конфигурация сервиса"""
    name: str
    host: str
    port: int
    weight: int = 1
    healthy: bool = True

class LoadBalancer:
    """Класс для балансировки нагрузки между сервисами"""
    
    def __init__(self):
        self._services: Dict[str, List[ServiceConfig]] = {}
        self._current_index: Dict[str, int] = {}
    
    def add_service(self, service_type: str, config: ServiceConfig) -> None:
        """Добавить сервис в балансировщик"""
        if service_type not in self._services:
            self._services[service_type] = []
            self._current_index[service_type] = 0
        self._services[service_type].append(config)
    
    def get_next_service(self, service_type: str) -> Optional[ServiceConfig]:
        """Получить следующий доступный сервис используя Round Robin"""
        if service_type not in self._services or not self._services[service_type]:
            return None
            
        services = self._services[service_type]
        start_index = self._current_index[service_type]
        
        # Поиск следующего здорового сервиса
        for i in range(len(services)):
            index = (start_index + i) % len(services)
            if services[index].healthy:
                self._current_index[service_type] = (index + 1) % len(services)
                return services[index]
        
        return None

class RequestRouter:
    """Класс для маршрутизации запросов"""
    
    def __init__(self):
        self._routes: Dict[str, str] = {}
        
    def add_route(self, path: str, service_type: str) -> None:
        """Добавить маршрут"""
        self._routes[path] = service_type
        
    def get_service_type(self, path: str) -> Optional[str]:
        """Получить тип сервиса для данного пути"""
        return self._routes.get(path)

class Gateway:
    """Основной класс шлюза"""
    
    def __init__(self):
        self._load_balancer = LoadBalancer()
        self._router = RequestRouter()
        self._logger = logging.getLogger(__name__)
        
    def setup_logging(self, level: int = logging.INFO) -> None:
        """Настройка логирования"""
        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
    def add_service(self, service_type: str, config: ServiceConfig) -> None:
        """Добавить сервис в шлюз"""
        self._load_balancer.add_service(service_type, config)
        self._logger.info(f"Added service: {config.name} ({service_type})")
        
        # Обновляем метрики о количестве сервисов
        services = self._load_balancer._services.get(service_type, [])
        GatewayMetrics.update_service_count(service_type, len(services))
        
    def add_route(self, path: str, service_type: str) -> None:
        """Добавить маршрут"""
        self._router.add_route(path, service_type)
        self._logger.info(f"Added route: {path} -> {service_type}")
        
    def route_request(self, path: str) -> Optional[ServiceConfig]:
        """Маршрутизация запроса"""
        start_time = time.time()
        try:
            service_type = self._router.get_service_type(path)
            if not service_type:
                self._logger.warning(f"No route found for path: {path}")
                GatewayMetrics.track_request("unknown", start_time, False)
                return None
                
            service = self._load_balancer.get_next_service(service_type)
            if not service:
                self._logger.error(f"No available services for type: {service_type}")
                GatewayMetrics.track_request(service_type, start_time, False)
                return None
                
            self._logger.info(f"Routing request to: {service.name}")
            GatewayMetrics.track_request(service_type, start_time, True)
            return service
            
        except Exception as e:
            self._logger.error(f"Error routing request: {str(e)}")
            GatewayMetrics.track_request("error", start_time, False)
            return None