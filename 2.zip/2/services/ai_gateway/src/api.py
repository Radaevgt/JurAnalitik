from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, Any, Optional
import yaml
from pathlib import Path

from .gateway import Gateway, ServiceConfig
from .monitoring import GatewayMetrics

# Создание FastAPI приложения
app = FastAPI(
    title="AI Gateway API",
    description="API шлюза для AI сервисов",
    version="1.0.0"
)

# Загрузка конфигурации
config_path = Path(__file__).parent.parent / "config" / "config.yaml"
with open(config_path) as f:
    config = yaml.safe_load(f)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config["service"]["cors_origins"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Создание шлюза
gateway = Gateway()

@app.get("/metrics")
async def metrics():
    """Endpoint для метрик Prometheus"""
    return Response(GatewayMetrics.get_metrics(), media_type="text/plain")

@app.post("/route")
async def route_request(request: Request) -> Dict[str, Any]:
    """
    Маршрутизация запроса к нужному сервису
    """
    path = request.url.path
    service = gateway.route_request(path)
    
    if not service:
        return {"error": "Service not found"}
        
    return {
        "service": {
            "name": service.name,
            "host": service.host,
            "port": service.port
        }
    }

@app.post("/services/{service_type}")
async def add_service(service_type: str, config: Dict[str, Any]) -> Dict[str, str]:
    """
    Добавление нового сервиса
    """
    service_config = ServiceConfig(**config)
    gateway.add_service(service_type, service_config)
    return {"status": "Service added successfully"}

@app.post("/routes")
async def add_route(path: str, service_type: str) -> Dict[str, str]:
    """
    Добавление нового маршрута
    """
    gateway.add_route(path, service_type)
    return {"status": "Route added successfully"}