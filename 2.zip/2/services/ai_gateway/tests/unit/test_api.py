import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
from src.api import app
from src.gateway import AIGateway

@pytest.fixture
def mock_gateway():
    return Mock(spec=AIGateway)

@pytest.fixture
def client(mock_gateway):
    app.dependency_overrides[AIGateway] = lambda: mock_gateway
    return TestClient(app)

def test_health_check(client, mock_gateway):
    # Подготовка
    mock_gateway.health_check.return_value = {
        "status": "ok",
        "version": "1.0",
        "providers": ["deepseek", "enhanced_deepseek"]
    }
    
    # Выполнение
    response = client.get("/v1/health")
    
    # Проверка
    assert response.status_code == 200
    assert response.json() == {
        "status": "ok",
        "version": "1.0",
        "providers": ["deepseek", "enhanced_deepseek"]
    }

def test_completion_success(client, mock_gateway):
    # Подготовка
    mock_gateway.get_completion.return_value = {
        "id": "test-1",
        "response": "Test response",
        "usage": {"total_tokens": 10}
    }
    request_data = {
        "provider": "deepseek",
        "prompt": "Test prompt",
        "options": {"temperature": 0.7}
    }
    
    # Выполнение
    response = client.post("/v1/completion", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    assert response.json() == {
        "id": "test-1",
        "response": "Test response",
        "usage": {"total_tokens": 10}
    }
    mock_gateway.get_completion.assert_called_once_with(
        provider="deepseek",
        prompt="Test prompt",
        options={"temperature": 0.7}
    )

def test_completion_validation_error(client):
    # Подготовка
    request_data = {
        "prompt": "Test prompt",  # Отсутствует обязательное поле provider
        "options": {"temperature": 0.7}
    }
    
    # Выполнение
    response = client.post("/v1/completion", json=request_data)
    
    # Проверка
    assert response.status_code == 422
    assert "provider" in response.json()["detail"][0]["loc"]

def test_completion_provider_error(client, mock_gateway):
    # Подготовка
    mock_gateway.get_completion.side_effect = Exception("Provider error")
    request_data = {
        "provider": "deepseek",
        "prompt": "Test prompt"
    }
    
    # Выполнение
    response = client.post("/v1/completion", json=request_data)
    
    # Проверка
    assert response.status_code == 500
    assert response.json()["detail"] == "Provider error"

def test_metrics(client, mock_gateway):
    # Подготовка
    mock_gateway.get_metrics.return_value = {
        "requests_total": 100,
        "requests_success": 95,
        "requests_failed": 5,
        "average_response_time": 0.5
    }
    
    # Выполнение
    response = client.get("/v1/metrics")
    
    # Проверка
    assert response.status_code == 200
    metrics = response.json()
    assert metrics["requests_total"] == 100
    assert metrics["requests_success"] == 95
    assert metrics["requests_failed"] == 5
    assert metrics["average_response_time"] == 0.5

def test_completion_with_prompt_processing(client, mock_gateway):
    # Подготовка
    mock_gateway.get_completion_with_prompt_processing.return_value = {
        "id": "test-2",
        "response": "Test response",
        "usage": {"total_tokens": 15}
    }
    request_data = {
        "provider": "deepseek",
        "prompt_template": "test-template",
        "parameters": {"param": "value"},
        "options": {"temperature": 0.7}
    }
    
    # Выполнение
    response = client.post("/v1/completion/with-prompt", json=request_data)
    
    # Проверка
    assert response.status_code == 200
    assert response.json() == {
        "id": "test-2",
        "response": "Test response",
        "usage": {"total_tokens": 15}
    }
    mock_gateway.get_completion_with_prompt_processing.assert_called_once_with(
        provider="deepseek",
        prompt_template="test-template",
        parameters={"param": "value"},
        options={"temperature": 0.7}
    )

def test_unauthorized_access(client):
    # Выполнение без токена авторизации
    response = client.post("/v1/completion", json={
        "provider": "deepseek",
        "prompt": "Test prompt"
    })
    
    # Проверка
    assert response.status_code == 401
    assert "Unauthorized" in response.json()["detail"]