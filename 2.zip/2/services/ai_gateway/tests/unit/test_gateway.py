import pytest
from unittest.mock import Mock, patch
from src.gateway import AIGateway

@pytest.fixture
def mock_provider_service():
    return Mock()

@pytest.fixture
def mock_prompt_service():
    return Mock()

@pytest.fixture
def gateway(mock_provider_service, mock_prompt_service):
    return AIGateway(
        provider_service=mock_provider_service,
        prompt_service=mock_prompt_service
    )

def test_gateway_initialization(gateway):
    assert gateway is not None
    assert hasattr(gateway, 'provider_service')
    assert hasattr(gateway, 'prompt_service')

@pytest.mark.asyncio
async def test_completion_success(gateway, mock_provider_service):
    # Подготовка
    mock_provider_service.get_completion.return_value = {
        "id": "test-1",
        "response": "Test response",
        "usage": {"total_tokens": 10}
    }
    
    # Выполнение
    result = await gateway.get_completion(
        provider="test-provider",
        prompt="Test prompt",
        options={"temperature": 0.7}
    )
    
    # Проверка
    assert result["id"] == "test-1"
    assert result["response"] == "Test response"
    assert result["usage"]["total_tokens"] == 10
    mock_provider_service.get_completion.assert_called_once_with(
        provider="test-provider",
        prompt="Test prompt",
        options={"temperature": 0.7}
    )

@pytest.mark.asyncio
async def test_completion_with_prompt_processing(gateway, mock_prompt_service, mock_provider_service):
    # Подготовка
    mock_prompt_service.process_prompt.return_value = "Processed prompt"
    mock_provider_service.get_completion.return_value = {
        "id": "test-2",
        "response": "Test response",
        "usage": {"total_tokens": 15}
    }
    
    # Выполнение
    result = await gateway.get_completion_with_prompt_processing(
        provider="test-provider",
        prompt_template="test-template",
        parameters={"param": "value"},
        options={"temperature": 0.7}
    )
    
    # Проверка
    assert result["id"] == "test-2"
    assert result["response"] == "Test response"
    mock_prompt_service.process_prompt.assert_called_once_with(
        template="test-template",
        parameters={"param": "value"}
    )
    mock_provider_service.get_completion.assert_called_once_with(
        provider="test-provider",
        prompt="Processed prompt",
        options={"temperature": 0.7}
    )

@pytest.mark.asyncio
async def test_completion_error_handling(gateway, mock_provider_service):
    # Подготовка
    mock_provider_service.get_completion.side_effect = Exception("Provider error")
    
    # Проверка
    with pytest.raises(Exception) as exc_info:
        await gateway.get_completion(
            provider="test-provider",
            prompt="Test prompt"
        )
    assert str(exc_info.value) == "Provider error"

@pytest.mark.asyncio
async def test_health_check(gateway, mock_provider_service):
    # Подготовка
    mock_provider_service.health_check.return_value = {
        "status": "ok",
        "version": "1.0"
    }
    
    # Выполнение
    result = await gateway.health_check()
    
    # Проверка
    assert result["status"] == "ok"
    assert result["version"] == "1.0"
    mock_provider_service.health_check.assert_called_once()

@pytest.mark.asyncio
async def test_metrics(gateway):
    # Выполнение
    result = await gateway.get_metrics()
    
    # Проверка
    assert "requests_total" in result
    assert "requests_success" in result
    assert "requests_failed" in result
    assert "average_response_time" in result