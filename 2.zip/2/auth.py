import os
import secrets
from flask import Blueprint, request, redirect, url_for, flash, render_template, session

# Импортируем наш новый модуль базы данных
from database import AppDatabase

# Создаем Blueprint для модуля авторизации
auth_bp = Blueprint('auth', __name__, template_folder='templates')

# Инициализируем базу данных
app_db = AppDatabase()

def create_user(username, password, email=None):
    """Создание нового пользователя"""
    return app_db.users.create_user(username, password, email)

def authenticate_user(username, password):
    """Аутентификация пользователя"""
    return app_db.users.authenticate_user(username, password)

def create_session(username):
    """Создание сессии пользователя"""
    session_id = secrets.token_urlsafe(32)
    success = app_db.sessions.create_session(username, session_id)
    return session_id if success else None

def get_current_user():
    """Получение текущего пользователя из сессии"""
    session_id = session.get('session_id')
    if not session_id:
        return None
    
    username = app_db.sessions.get_user_by_session(session_id)
    return username

def get_current_user_data():
    """Получение полных данных текущего пользователя"""
    username = get_current_user()
    if not username:
        return None
    
    return app_db.users.get_user_by_username(username)

def require_auth():
    """Проверка авторизации (декоратор можно будет сделать позже)"""
    current_user = get_current_user()
    if not current_user:
        return False
    return True

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Регистрация нового пользователя"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        email = request.form.get('email', '').strip()
        
        # Простая валидация
        if not username or not password:
            flash('Все поля обязательны для заполнения', 'error')
            return redirect(url_for('auth.register'))
        
        if len(username) < 3:
            flash('Имя пользователя должно быть не менее 3 символов', 'error')
            return redirect(url_for('auth.register'))
        
        if len(password) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
            return redirect(url_for('auth.register'))
        
        # Создаем пользователя
        if create_user(username, password, email):
            # Сразу логиним пользователя
            session_id = create_session(username)
            if session_id:
                session['session_id'] = session_id
                flash('Регистрация прошла успешно! Добро пожаловать!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Пользователь создан, но не удалось войти в систему', 'error')
        else:
            flash('Пользователь с таким именем уже существует', 'error')
    
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Авторизация пользователя"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if not username or not password:
            flash('Введите имя пользователя и пароль', 'error')
            return redirect(url_for('auth.login'))
        
        if authenticate_user(username, password):
            session_id = create_session(username)
            if session_id:
                session['session_id'] = session_id
                flash('Вы успешно вошли в систему', 'success')
                return redirect(url_for('index'))
            else:
                flash('Ошибка создания сессии', 'error')
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    """Выход из системы"""
    session_id = session.get('session_id')
    if session_id:
        app_db.sessions.delete_session(session_id)
    
    session.pop('session_id', None)
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

# ==========================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ app.py
# ==========================================

def get_user_id_by_session():
    """Получить ID пользователя по текущей сессии"""
    user_data = get_current_user_data()
    return user_data['id'] if user_data else None

def check_user_document_limits(username):
    """Проверка лимитов пользователя (пока просто возвращаем True)"""
    # TODO: Реализовать проверку тарифных планов
    return True

def increment_user_usage(username):
    """Увеличить счетчик использования документов"""
    # TODO: Реализовать счетчик для биллинга
    pass

# ==========================================
# СОВМЕСТИМОСТЬ СО СТАРЫМ КОДОМ
# ==========================================

# Для совместимости с app.py создаем пустые объекты
sessions_storage = {}  # Больше не используется, но пока оставим для совместимости

# Простая функция для проверки авторизации в app.py
def is_user_authenticated():
    """Простая проверка авторизации для использования в app.py"""
    return get_current_user() is not None