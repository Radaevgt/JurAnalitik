import os
import json
import requests
from abc import ABC, abstractmethod
from dotenv import load_dotenv
import time
from typing import Dict, List, Optional

load_dotenv()

class AIProvider(ABC):
    """Абстрактный базовый класс для провайдеров ИИ"""
    @abstractmethod
    def analyze_document(self, content: str, analysis_type: str = 'basic') -> str:
        pass

# ==========================================
# СПЕЦИАЛИЗИРОВАННЫЕ АНАЛИЗАТОРЫ
# ==========================================

class AnalysisPrompts:
    """Класс с улучшенными промптами на основе Jurmak структуры"""
    
    @staticmethod
    def get_system_message():
        """Системное сообщение для роли юриста"""
        return """Ты - профессиональный юрист со специализацией на анализе юридических документов и договоров. 
Твои ответы должны быть точными, структурированными и основанными на действующем законодательстве РФ.
В своем анализе обязательно цитируй в двойных кавычках релевантные фрагменты анализируемого документа."""

    @staticmethod
    def get_risk_analysis_prompt(content: str) -> str:
        """Промпт для анализа юридических рисков"""
        return f"""
Проанализируй следующий юридический документ и выяви все потенциальные риски.

Документ для анализа:
\"\"\"{content}\"\"\"

СТРУКТУРА АНАЛИЗА:

**1. ОБЩИЕ СВЕДЕНИЯ**
- Краткое описание документа и его основного содержания
- Тип договора/документа и его правовая природа
- Включи цитаты из ключевых разделов документа

**2. НОРМАТИВНАЯ БАЗА**
- Укажи применимые нормы ГК РФ, специальных законов
- Свяжи нормы с конкретными положениями документа через цитирование

**3. ВЫЯВЛЕННЫЕ РИСКИ**
Для каждого риска укажи:
- 🔴 **Название риска**
- **Описание:** что именно создает риск
- **Цитата:** "точный фрагмент документа в кавычках"
- **Правовое основание:** статья закона/кодекса
- **Последствия:** что может произойти
- **Уровень серьезности:** ВЫСОКИЙ/СРЕДНИЙ/НИЗКИЙ

**4. РЕКОМЕНДАЦИИ**
- Как устранить каждый выявленный риск
- Конкретные изменения текста документа
- Дополнительные документы/условия

**5. ЗАКЛЮЧЕНИЕ**
- Общая оценка юридической устойчивости
- Приоритетные действия

Формат ответа: структурированный текст с четкими разделами и обязательным цитированием.
"""

    @staticmethod
    def get_business_analysis_prompt(content: str) -> str:
        """Промпт для бизнес-анализа договора"""
        return f"""
Проведи бизнес-анализ следующего договора с акцентом на финансовые и коммерческие аспекты.

Документ для анализа:
\"\"\"{content}\"\"\"

СТРУКТУРА БИЗНЕС-АНАЛИЗА:

**1. ФИНАНСОВЫЕ УСЛОВИЯ**
- Извлеки и проанализируй все суммы, цены, тарифы
- Цитируй: "конкретные финансовые условия из документа"
- Рассчитай общую стоимость договора

**2. УСЛОВИЯ ПЛАТЕЖЕЙ**
- График платежей и сроки
- Штрафы, пени, неустойки (размеры и основания)
- Цитируй: "условия об оплате и санкциях"

**3. КОММЕРЧЕСКИЕ РИСКИ**
- Финансовые потери от неисполнения
- Риски изменения цен, курсов валют
- Гарантийные обязательства и их стоимость

**4. ЭКОНОМИЧЕСКАЯ ЭФФЕКТИВНОСТЬ**
- ROI и окупаемость (если применимо)
- Сравнение с рыночными условиями
- Выгодность условий для каждой стороны

**5. БИЗНЕС-РЕКОМЕНДАЦИИ**
- Как улучшить финансовые условия
- Оптимизация платежей и снижение рисков
- Предложения по ценообразованию

Включай конкретные цифры и расчеты, обязательно цитируй финансовые условия из документа.
"""

    @staticmethod
    def get_compliance_analysis_prompt(content: str) -> str:
        """Промпт для анализа соответствия законодательству"""
        return f"""
Проанализируй соответствие документа требованиям российского законодательства.

Документ для анализа:
\"\"\"{content}\"\"\"

СТРУКТУРА КОМПЛАЕНС-АНАЛИЗА:

**1. СООТВЕТСТВИЕ ГК РФ**
- Проверка обязательных элементов договора (ст. 432 ГК РФ)
- Соответствие требованиям к форме сделки
- Цитируй: "проблемные или отсутствующие положения"

**2. СПЕЦИАЛЬНОЕ РЕГУЛИРОВАНИЕ**
- Соответствие отраслевому законодательству
- Лицензионные требования (если применимо)
- Валютное законодательство (для валютных операций)

**3. АНТИМОНОПОЛЬНОЕ ЗАКОНОДАТЕЛЬСТВО**
- Проверка на ограничение конкуренции
- Соответствие требованиям о госзакупках (если применимо)

**4. ЗАЩИТА ПЕРСОНАЛЬНЫХ ДАННЫХ**
- Соответствие требованиям 152-ФЗ
- Обработка и защита персональных данных

**5. НАРУШЕНИЯ И РИСКИ**
- Выявленные несоответствия законодательству
- Цитируй: "конкретные нарушения в тексте"
- Возможные санкции и последствия

**6. РЕКОМЕНДАЦИИ ПО ПРИВЕДЕНИЮ В СООТВЕТСТВИЕ**
- Конкретные изменения для устранения нарушений
- Дополнительные документы и процедуры

Фокусируйся на конкретных нарушениях с указанием статей законов.
"""

    @staticmethod
    def get_terminology_analysis_prompt(content: str) -> str:
        """Промпт для терминологического анализа"""
        return f"""
Проанализируй терминологию и определения в документе.

Документ для анализы:
\"\"\"{content}\"\"\"

СТРУКТУРА ТЕРМИНОЛОГИЧЕСКОГО АНАЛИЗА:

**1. ИСПОЛЬЗУЕМЫЕ ТЕРМИНЫ**
- Список всех специальных терминов в документе
- Цитируй: "определения из документа"

**2. НЕОПРЕДЕЛЕННЫЕ ПОНЯТИЯ**
- Термины без четкого определения
- "Размытые" формулировки типа "разумный срок", "существенные обстоятельства"
- Цитируй: "проблемные формулировки"

**3. ПРОТИВОРЕЧИЯ В ТЕРМИНОЛОГИИ**
- Разное использование одних терминов
- Синонимы, которые могут создать путаницу

**4. СООТВЕТСТВИЕ ЮРИДИЧЕСКОЙ ТЕХНИКЕ**
- Правильность использования юридических терминов
- Соответствие терминологии отраслевым стандартам

**5. ГЛОССАРИЙ РЕКОМЕНДУЕМЫХ ОПРЕДЕЛЕНИЙ**
- Предложения четких определений для неопределенных терминов
- Унификация терминологии

**6. РЕКОМЕНДАЦИИ ПО УЛУЧШЕНИЮ**
- Как сделать текст более понятным и однозначным
- Предложения новых формулировок

Цель: обеспечить однозначность толкования всех терминов в документе.
"""

    @staticmethod
    def get_structural_analysis_prompt(content: str) -> str:
        """Промпт для структурного анализа документа"""
        return f"""
Проанализируй структуру и полноту документа.

Документ для анализа:
\"\"\"{content}\"\"\"

СТРУКТУРА АНАЛИЗА:

**1. АНАЛИЗ СТРУКТУРЫ**
- Проверка наличия обязательных разделов
- Логичность последовательности разделов
- Нумерация и оформление пунктов

**2. ПОЛНОТА СОДЕРЖАНИЯ**
- Отсутствующие обязательные элементы
- Недостающие разделы (порядок приемки, ответственность и т.д.)

**3. ВНУТРЕННИЕ ПРОТИВОРЕЧИЯ**
- Противоречия между разными пунктами
- Цитируй: "противоречащие положения"

**4. ДУБЛИРОВАНИЕ**
- Повторяющиеся положения
- Избыточные формулировки

**5. ССЫЛКИ И ПРИЛОЖЕНИЯ**
- Корректность ссылок на приложения
- Соответствие основного текста и приложений

**6. РЕКОМЕНДАЦИИ ПО СТРУКТУРЕ**
- Предложения по реорганизации документа
- Дополнительные разделы и пункты
- Улучшение логики изложения

Цель: обеспечить логичную, полную и непротиворечивую структуру документа.
"""

    @staticmethod
    def get_comparison_analysis_prompt(content1: str, content2: str) -> str:
        """Промпт для сравнительного анализа документов"""
        return f"""
Проведи сравнительный анализ двух документов и выяви различия.

ПЕРВЫЙ ДОКУМЕНТ:
\"\"\"{content1}\"\"\"

ВТОРОЙ ДОКУМЕНТ:
\"\"\"{content2}\"\"\"

СТРУКТУРА СРАВНИТЕЛЬНОГО АНАЛИЗА:

**1. КЛЮЧЕВЫЕ РАЗЛИЧИЯ**
- Основные отличия в содержании
- Цитируй различающиеся положения из обоих документов

**2. УСЛОВИЯ И ПРАВА СТОРОН**
- Сравнение прав и обязанностей
- Различия в ответственности

**3. ФИНАНСОВЫЕ УСЛОВИЯ**
- Сравнение цен, сроков платежей
- Различия в штрафных санкциях

**4. ПРАВОВЫЕ АСПЕКТЫ**
- Различия в юридической защищенности
- Сравнение рисков в каждом документе

**5. РЕКОМЕНДАЦИИ ПО ВЫБОРУ**
- Какой документ более выгоден и почему
- Элементы для унификации

**6. ПРЕДЛОЖЕНИЯ ПО ДОРАБОТКЕ**
- Как объединить лучшие элементы обоих документов

Цель: помочь выбрать лучший вариант или создать оптимальный документ.
"""

# ==========================================
# РАСШИРЕННЫЙ DEEPSEEK ПРОВАЙДЕР
# ==========================================

class EnhancedDeepSeekProvider(AIProvider):
    """Расширенный провайдер DeepSeek с множественными типами анализа"""
    
    def __init__(self):
        self.api_key = os.getenv('DEEPSEEK_API_KEY')
        self.base_url = "https://api.deepseek.com/v1/chat/completions"
        
        # Конфигурация для разных типов анализа
        self.analysis_configs = {
            'risk': {'max_tokens': 2000, 'temperature': 0.2},
            'business': {'max_tokens': 1500, 'temperature': 0.3},
            'compliance': {'max_tokens': 1800, 'temperature': 0.1},
            'terminology': {'max_tokens': 1200, 'temperature': 0.2},
            'structural': {'max_tokens': 1300, 'temperature': 0.2},
            'comparison': {'max_tokens': 2500, 'temperature': 0.2},
            'basic': {'max_tokens': 1500, 'temperature': 0.3}
        }
        
        if not self.api_key:
            print("[!] DEEPSEEK_API_KEY не найден в .env файле")
        else:
            print("[+] EnhancedDeepSeek API готов к использованию")
    
    def analyze_document(self, content: str, analysis_type: str = 'basic') -> str:
        """Анализ документа с выбором типа анализа"""
        if not self.api_key:
            return self._generate_no_api_report(content, analysis_type)
        
        # Выбираем промпт в зависимости от типа анализа
        prompt = self._get_prompt_for_analysis_type(content, analysis_type)
        config = self.analysis_configs.get(analysis_type, self.analysis_configs['basic'])
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": AnalysisPrompts.get_system_message()},
                {"role": "user", "content": prompt}
            ],
            "temperature": config['temperature'],
            "max_tokens": config['max_tokens'],
            "stream": False
        }
        
        # Делаем запрос с retry логикой
        return self._make_api_request(data, headers, content, analysis_type)
    
    def _get_prompt_for_analysis_type(self, content: str, analysis_type: str) -> str:
        """Возвращает промпт для конкретного типа анализа"""
        prompt_methods = {
            'risk': AnalysisPrompts.get_risk_analysis_prompt,
            'business': AnalysisPrompts.get_business_analysis_prompt,
            'compliance': AnalysisPrompts.get_compliance_analysis_prompt,
            'terminology': AnalysisPrompts.get_terminology_analysis_prompt,
            'structural': AnalysisPrompts.get_structural_analysis_prompt,
            'basic': AnalysisPrompts.get_risk_analysis_prompt  # По умолчанию риски
        }
        
        prompt_method = prompt_methods.get(analysis_type, AnalysisPrompts.get_risk_analysis_prompt)
        return prompt_method(content)
    
    def compare_documents(self, content1: str, content2: str) -> str:
        """Сравнительный анализ двух документов"""
        if not self.api_key:
            return self._generate_no_api_report(content1 + "\n\n" + content2, 'comparison')
        
        prompt = AnalysisPrompts.get_comparison_analysis_prompt(content1, content2)
        config = self.analysis_configs['comparison']
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": AnalysisPrompts.get_system_message()},
                {"role": "user", "content": prompt}
            ],
            "temperature": config['temperature'],
            "max_tokens": config['max_tokens'],
            "stream": False
        }
        
        return self._make_api_request(data, headers, content1 + content2, 'comparison')
    
    def _make_api_request(self, data, headers, content: str, analysis_type: str) -> str:
        """Выполнение API запроса с обработкой ошибок"""
        session = requests.Session()
        max_attempts = 3
        
        for attempt in range(max_attempts):
            try:
                if attempt > 0:
                    print(f"[*] Повторная попытка {attempt + 1}/{max_attempts}...")
                    time.sleep(2)
                
                print(f"[*] Выполняем {analysis_type} анализ через DeepSeek API...")
                start_time = time.time()
                
                response = session.post(
                    self.base_url,
                    headers=headers,
                    json=data,
                    timeout=(15, 120)  # Увеличиваем таймаут для сложных анализов
                )
                
                elapsed = time.time() - start_time
                print(f"[*] DeepSeek ответил за {elapsed:.1f} секунд")
                
                # Обработка ошибок
                if response.status_code == 402:
                    return self._generate_billing_error_report(content, analysis_type)
                elif response.status_code == 429:
                    if attempt < max_attempts - 1:
                        time.sleep(5)
                        continue
                    return self._generate_rate_limit_error_report(content, analysis_type)
                elif response.status_code == 503:
                    if attempt < max_attempts - 1:
                        time.sleep(3)
                        continue
                    return self._generate_server_error_report(content, analysis_type)
                
                response.raise_for_status()
                result = response.json()
                
                if 'choices' not in result or len(result['choices']) == 0:
                    raise Exception("Пустой ответ от API")
                
                print(f"[+] {analysis_type.title()} анализ завершен успешно")
                return result['choices'][0]['message']['content']
                
            except requests.exceptions.Timeout:
                print(f"[-] Попытка {attempt + 1}: Таймаут соединения")
                if attempt < max_attempts - 1:
                    continue
                return self._generate_timeout_error_report(content, analysis_type)
            except Exception as e:
                print(f"[-] Попытка {attempt + 1}: Ошибка - {str(e)}")
                if attempt < max_attempts - 1:
                    continue
                return self._generate_general_error_report(content, str(e), analysis_type)
        
        return self._generate_all_attempts_failed_report(content, analysis_type)
    
    # ==========================================
    # ГЕНЕРАТОРЫ ОТЧЕТОВ ОБ ОШИБКАХ
    # ==========================================
    
    def _generate_no_api_report(self, content: str, analysis_type: str) -> str:
        """Отчет когда API ключ не настроен"""
        analysis_names = {
            'risk': 'анализ рисков',
            'business': 'бизнес-анализ', 
            'compliance': 'комплаенс-анализ',
            'terminology': 'терминологический анализ',
            'structural': 'структурный анализ',
            'comparison': 'сравнительный анализ',
            'basic': 'базовый анализ'
        }
        
        analysis_name = analysis_names.get(analysis_type, 'анализ')
        
        return f"""# 📋 {analysis_name.title()}

## ⚠️ API ключ не настроен

Для получения полного {analysis_name} необходимо настроить DeepSeek API ключ.

## 📊 Базовая информация
**Тип анализа:** {analysis_name}  
**Слов в документе:** {len(content.split()):,}  
**Символов:** {len(content):,}

## 🔧 Настройка DeepSeek API

1. Зайдите на https://platform.deepseek.com/
2. Зарегистрируйтесь и создайте API ключ
3. Настройте биллинг (добавьте карту и пополните баланс)
4. Добавьте в файл .env:
   ```
   DEEPSEEK_API_KEY=sk-ваш_ключ_здесь
   ```

---
*Настройте API ключ для получения полного анализа*"""

    def _generate_billing_error_report(self, content: str, analysis_type: str) -> str:
        """Отчет при ошибке биллинга"""
        return f"""# 📋 {analysis_type.title()} анализ

## 💳 Ошибка оплаты (Error 402)

DeepSeek API требует пополнения баланса.

## 🔧 Решение:
1. Войдите в консоль: https://platform.deepseek.com/
2. Найдите раздел "Billing" или "Credits"
3. Пополните баланс минимум на $5-10
4. Подождите 5-10 минут и повторите попытку

## 📊 Документ готов к анализу
**Размер:** {len(content)} символов  
**Тип анализа:** {analysis_type}

---
*Пополните баланс для получения анализа*"""

    def _generate_timeout_error_report(self, content: str, analysis_type: str) -> str:
        """Отчет при таймауте"""
        return f"""# 📋 {analysis_type.title()} анализ

## ⏳ Сервер не отвечает (Timeout)

Серверы DeepSeek перегружены или временно недоступны.

## 🔧 Рекомендации:
1. **Попробуйте через 10-15 минут** - обычно помогает
2. **Уменьшите размер документа** - разбейте на части
3. **Попробуйте в другое время** - меньше нагрузки ночью

## 📊 Информация о документе
**Размер:** {len(content)} символов  
**Тип анализа:** {analysis_type}  

---
*Серверы перегружены, попробуйте позже*"""

    def _generate_rate_limit_error_report(self, content: str, analysis_type: str) -> str:
        """Отчет при превышении лимитов"""
        return f"""# 📋 {analysis_type.title()} анализ

## ⚡ Превышен лимит запросов (Error 429)

Достигнут дневной/часовой лимит использования API.

## 🔧 Решение:
- Подождите 1-2 часа и повторите попытку
- Или обновите тариф в консоли DeepSeek

## 📊 Статистика документа
**Слов:** {len(content.split())} | **Символов:** {len(content)}
**Тип анализа:** {analysis_type}

---
*Превышен лимит API, попробуйте позже*"""

    def _generate_server_error_report(self, content: str, analysis_type: str) -> str:
        """Отчет при ошибке сервера"""
        return f"""# 📋 {analysis_type.title()} анализ

## 🔧 Технические работы (Error 503)

Серверы DeepSeek временно недоступны.

## ⏳ Что делать:
- Подождите 15-30 минут
- Проверьте статус: https://status.deepseek.com/
- Повторите попытку

## 📊 Документ готов к обработке
**Размер:** {len(content)} символов
**Тип анализа:** {analysis_type}

---
*Технические работы, ожидайте восстановления*"""

    def _generate_general_error_report(self, content: str, error: str, analysis_type: str) -> str:
        """Отчет при общей ошибке"""
        return f"""# 📋 {analysis_type.title()} анализ

## ❌ Техническая ошибка

Произошла непредвиденная ошибка при обработке.

## 🔧 Попробуйте:
1. Перезапустить приложение
2. Проверить API ключ в .env файле
3. Уменьшить размер документа

## 📊 Информация
**Документ:** {len(content)} символов  
**Тип анализа:** {analysis_type}  
**Ошибка:** {error[:100]}...

---
*Обратитесь к разработчику если ошибка повторяется*"""

    def _generate_all_attempts_failed_report(self, content: str, analysis_type: str) -> str:
        """Отчет когда все попытки исчерпаны"""
        return f"""# 📋 {analysis_type.title()} анализ

## 🚫 Не удалось обработать документ

Все попытки подключения к DeepSeek API исчерпаны.

## 🔧 Возможные причины:
- Серверы DeepSeek перегружены
- Проблемы с интернет соединением  
- Технические работы на стороне DeepSeek

## 📊 Статистика документа
**Размер:** {len(content)} символов  
**Тип анализа:** {analysis_type}  
**Попыток:** 3 из 3

## 💡 Рекомендации:
1. **Попробуйте позже** (через 30-60 минут)
2. **Проверьте статус:** https://status.deepseek.com/
3. **Уменьшите документ** если он очень большой

---
*Повторите попытку через некоторое время*"""

# ==========================================
# DEEPSEEK R1 ПРОВАЙДЕР
# ==========================================

class DeepSeekR1Provider(AIProvider):
    """Провайдер для новой версии модели DeepSeek R1 (0528)"""
    
    def __init__(self):
        self.api_key = os.getenv('DEEPSEEK_API_KEY')
        self.base_url = "https://api.deepseek.com/v1/chat/completions"
        self.model_version = "deepseek-r1-0528"
        
        # Конфигурация для разных типов анализа с учетом особенностей новой модели
        self.analysis_configs = {
            'risk': {'max_tokens': 2500, 'temperature': 0.1},
            'business': {'max_tokens': 2000, 'temperature': 0.2},
            'compliance': {'max_tokens': 2200, 'temperature': 0.1},
            'terminology': {'max_tokens': 1500, 'temperature': 0.15},
            'structural': {'max_tokens': 1800, 'temperature': 0.15},
            'comparison': {'max_tokens': 3000, 'temperature': 0.1},
            'basic': {'max_tokens': 2000, 'temperature': 0.2}
        }
        
        # Инициализация логгера
        self._setup_logger()
        
        if not self.api_key:
            self.logger.warning("[!] DEEPSEEK_API_KEY не найден в .env файле")
        else:
            self.logger.info("[+] DeepSeek R1 API готов к использованию")
    
    def _setup_logger(self):
        """Настройка системы логирования"""
        import logging
        
        self.logger = logging.getLogger('DeepSeekR1')
        self.logger.setLevel(logging.INFO)
        
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def analyze_document(self, content: str, analysis_type: str = 'basic') -> str:
        """Анализ документа с использованием новой модели R1"""
        if not self.api_key:
            self.logger.error("API ключ не настроен")
            return self._generate_no_api_report(content, analysis_type)
        
        try:
            # Выбираем промпт и конфигурацию
            prompt = self._get_prompt_for_analysis_type(content, analysis_type)
            config = self.analysis_configs.get(analysis_type, self.analysis_configs['basic'])
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            data = {
                "model": self.model_version,
                "messages": [
                    {"role": "system", "content": AnalysisPrompts.get_system_message()},
                    {"role": "user", "content": prompt}
                ],
                "temperature": config['temperature'],
                "max_tokens": config['max_tokens'],
                "stream": False
            }
            
            return self._make_api_request(data, headers, content, analysis_type)
            
        except Exception as e:
            self.logger.error(f"Ошибка при анализе документа: {str(e)}")
            return self._generate_general_error_report(content, str(e), analysis_type)
    
    def _make_api_request(self, data: Dict, headers: Dict, content: str, analysis_type: str) -> str:
        """Выполнение API запроса с обработкой ошибок и логированием"""
        session = requests.Session()
        max_attempts = 3
        
        for attempt in range(max_attempts):
            try:
                if attempt > 0:
                    self.logger.info(f"Повторная попытка {attempt + 1}/{max_attempts}")
                    time.sleep(2)
                
                self.logger.info(f"Выполняем {analysis_type} анализ через DeepSeek R1 API")
                start_time = time.time()
                
                response = session.post(
                    self.base_url,
                    headers=headers,
                    json=data,
                    timeout=(15, 180)  # Увеличенный таймаут для сложных анализов
                )
                
                elapsed = time.time() - start_time
                self.logger.info(f"DeepSeek R1 ответил за {elapsed:.1f} секунд")
                
                # Обработка ошибок
                if response.status_code == 402:
                    self.logger.error("Ошибка биллинга")
                    return self._generate_billing_error_report(content, analysis_type)
                elif response.status_code == 429:
                    if attempt < max_attempts - 1:
                        time.sleep(5)
                        continue
                    self.logger.error("Превышен лимит запросов")
                    return self._generate_rate_limit_error_report(content, analysis_type)
                elif response.status_code == 503:
                    if attempt < max_attempts - 1:
                        time.sleep(3)
                        continue
                    self.logger.error("Сервер недоступен")
                    return self._generate_server_error_report(content, analysis_type)
                
                response.raise_for_status()
                result = response.json()
                
                if 'choices' not in result or len(result['choices']) == 0:
                    raise Exception("Пустой ответ от API")
                
                self.logger.info(f"[+] {analysis_type.title()} анализ завершен успешно")
                return result['choices'][0]['message']['content']
                
            except requests.exceptions.Timeout:
                self.logger.error(f"Таймаут соединения (попытка {attempt + 1})")
                if attempt < max_attempts - 1:
                    continue
                return self._generate_timeout_error_report(content, analysis_type)
            except Exception as e:
                self.logger.error(f"Ошибка при запросе (попытка {attempt + 1}): {str(e)}")
                if attempt < max_attempts - 1:
                    continue
                return self._generate_general_error_report(content, str(e), analysis_type)
        
        return self._generate_all_attempts_failed_report(content, analysis_type)

    def _get_prompt_for_analysis_type(self, content: str, analysis_type: str) -> str:
        """Возвращает промпт для конкретного типа анализа"""
        prompt_methods = {
            'risk': AnalysisPrompts.get_risk_analysis_prompt,
            'business': AnalysisPrompts.get_business_analysis_prompt,
            'compliance': AnalysisPrompts.get_compliance_analysis_prompt,
            'terminology': AnalysisPrompts.get_terminology_analysis_prompt,
            'structural': AnalysisPrompts.get_structural_analysis_prompt,
            'basic': AnalysisPrompts.get_risk_analysis_prompt
        }
        
        prompt_method = prompt_methods.get(analysis_type, AnalysisPrompts.get_risk_analysis_prompt)
        return prompt_method(content)

    # Наследуем методы генерации отчетов об ошибках от EnhancedDeepSeekProvider
    _generate_no_api_report = EnhancedDeepSeekProvider._generate_no_api_report
    _generate_billing_error_report = EnhancedDeepSeekProvider._generate_billing_error_report
    _generate_timeout_error_report = EnhancedDeepSeekProvider._generate_timeout_error_report
    _generate_rate_limit_error_report = EnhancedDeepSeekProvider._generate_rate_limit_error_report
    _generate_server_error_report = EnhancedDeepSeekProvider._generate_server_error_report
    _generate_general_error_report = EnhancedDeepSeekProvider._generate_general_error_report
    _generate_all_attempts_failed_report = EnhancedDeepSeekProvider._generate_all_attempts_failed_report

# ==========================================
# ФАБРИКА ПРОВАЙДЕРОВ
# ==========================================

class DeepSeekProviderFactory:
    """Фабрика для создания и управления провайдерами DeepSeek"""
    
    PROVIDERS = {
        'legacy': EnhancedDeepSeekProvider,
        'r1-0528': DeepSeekR1Provider
    }
    
    @classmethod
    def create(cls, version: str = 'r1-0528') -> AIProvider:
        """
        Создает провайдер указанной версии
        
        Args:
            version: Версия провайдера ('legacy' или 'r1-0528')
            
        Returns:
            AIProvider: Инстанс провайдера нужной версии
        """
        if version not in cls.PROVIDERS:
            raise ValueError(f"Неподдерживаемая версия: {version}. Доступные версии: {list(cls.PROVIDERS.keys())}")
        
        return cls.PROVIDERS[version]()
    
    @classmethod
    def get_available_versions(cls) -> List[str]:
        """Возвращает список доступных версий провайдеров"""
        return list(cls.PROVIDERS.keys())

# ==========================================
# ОБРАТНАЯ СОВМЕСТИМОСТЬ
# ==========================================

# Для совместимости со старым кодом создаем алиас
DeepSeekProvider = DeepSeekProviderFactory.create('legacy')

# ==========================================
# ТЕСТИРОВАНИЕ
# ==========================================

if __name__ == "__main__":
    print("[*] Тестирование системы анализа...")
    
    # Тестируем оба провайдера
    providers = {
        'legacy': DeepSeekProviderFactory.create('legacy'),
        'r1-0528': DeepSeekProviderFactory.create('r1-0528')
    }

    test_document = """
    ДОГОВОР ПОСТАВКИ №123
    
    1. ПРЕДМЕТ ДОГОВОРА
    Поставщик обязуется поставить товар на сумму 1 000 000 рублей.
    
    2. ЦЕНА И ПОРЯДОК РАСЧЕТОВ
    Общая стоимость составляет один миллион рублей.
    Оплата в течение 30 дней.
    
    3. ОТВЕТСТВЕННОСТЬ
    За просрочку поставки - неустойка 5% в день от стоимости товара.
    """
    
    analysis_types = ['risk', 'business', 'compliance', 'terminology', 'structural']
    
    # Тестируем каждый провайдер
    for version, provider in providers.items():
        print(f"\n[*] Тестирование провайдера {version}")
        
        for analysis_type in analysis_types:
            print(f"\n[*] Тестируем {analysis_type} анализ...")
            result = provider.analyze_document(test_document, analysis_type)
            print(f"[+] {analysis_type} анализ: {len(result)} символов")
    
    print("\n[+] Тестирование всех провайдеров завершено")
