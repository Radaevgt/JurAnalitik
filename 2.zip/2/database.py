import sqlite3
import json
import os
from datetime import datetime
from typing import Optional, List, Dict, Any

class Database:
    """Простой класс для работы с SQLite базой данных"""
    
    def __init__(self, db_path: str = "jurist_app.db"):
        self.db_path = db_path
        self.init_database()
    
    def get_connection(self):
        """Получить соединение с базой данных"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Для доступа к колонкам по имени
        return conn
    
    def init_database(self):
        """Инициализация базы данных и создание таблиц"""
        with self.get_connection() as conn:
            # Таблица пользователей
            conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT,
                    plan TEXT DEFAULT 'FREE',
                    documents_used_this_month INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица сессий
            conn.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    username TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    FOREIGN KEY (username) REFERENCES users (username)
                )
            ''')
            
            # Таблица документов
            conn.execute('''
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    filename TEXT NOT NULL,
                    original_filename TEXT NOT NULL,
                    file_size INTEGER,
                    content_preview TEXT,
                    full_content TEXT,
                    status TEXT DEFAULT 'uploaded',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
            
            # Таблица результатов анализа
            conn.execute('''
                CREATE TABLE IF NOT EXISTS analysis_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id INTEGER NOT NULL,
                    analysis_type TEXT DEFAULT 'basic',
                    results_data TEXT,  -- JSON с результатами
                    ai_provider TEXT DEFAULT 'deepseek',
                    processing_time REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (document_id) REFERENCES documents (id)
                )
            ''')
            
            conn.commit()
            print("✅ База данных инициализирована")

# ==========================================
# ПОЛЬЗОВАТЕЛИ
# ==========================================

class UserManager:
    """Управление пользователями"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def create_user(self, username: str, password: str, email: str = None) -> bool:
        """Создание нового пользователя"""
        try:
            with self.db.get_connection() as conn:
                conn.execute(
                    'INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
                    (username, password, email)
                )
                conn.commit()
                print(f"✅ Пользователь {username} создан")
                return True
        except sqlite3.IntegrityError:
            print(f"❌ Пользователь {username} уже существует")
            return False
        except Exception as e:
            print(f"❌ Ошибка создания пользователя: {e}")
            return False
    
    def authenticate_user(self, username: str, password: str) -> bool:
        """Проверка пароля пользователя"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute(
                    'SELECT password FROM users WHERE username = ?',
                    (username,)
                )
                user = cursor.fetchone()
                
                if user and user['password'] == password:
                    print(f"✅ Пользователь {username} аутентифицирован")
                    return True
                else:
                    print(f"❌ Неверные данные для {username}")
                    return False
        except Exception as e:
            print(f"❌ Ошибка аутентификации: {e}")
            return False
    
    def get_user_by_username(self, username: str) -> Optional[Dict]:
        """Получить данные пользователя по имени"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute(
                    'SELECT * FROM users WHERE username = ?',
                    (username,)
                )
                user = cursor.fetchone()
                return dict(user) if user else None
        except Exception as e:
            print(f"❌ Ошибка получения пользователя: {e}")
            return None

# ==========================================
# СЕССИИ
# ==========================================

class SessionManager:
    """Управление сессиями пользователей"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def create_session(self, username: str, session_id: str) -> bool:
        """Создание новой сессии"""
        try:
            with self.db.get_connection() as conn:
                # Удаляем старые сессии пользователя
                conn.execute('DELETE FROM sessions WHERE username = ?', (username,))
                
                # Создаем новую сессию
                conn.execute(
                    'INSERT INTO sessions (session_id, username) VALUES (?, ?)',
                    (session_id, username)
                )
                conn.commit()
                print(f"✅ Сессия создана для {username}")
                return True
        except Exception as e:
            print(f"❌ Ошибка создания сессии: {e}")
            return False
    
    def get_user_by_session(self, session_id: str) -> Optional[str]:
        """Получить имя пользователя по session_id"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute(
                    'SELECT username FROM sessions WHERE session_id = ?',
                    (session_id,)
                )
                session = cursor.fetchone()
                return session['username'] if session else None
        except Exception as e:
            print(f"❌ Ошибка получения сессии: {e}")
            return None
    
    def delete_session(self, session_id: str) -> bool:
        """Удаление сессии (выход из системы)"""
        try:
            with self.db.get_connection() as conn:
                conn.execute('DELETE FROM sessions WHERE session_id = ?', (session_id,))
                conn.commit()
                print("✅ Сессия удалена")
                return True
        except Exception as e:
            print(f"❌ Ошибка удаления сессии: {e}")
            return False

# ==========================================
# ДОКУМЕНТЫ
# ==========================================

class DocumentManager:
    """Управление документами пользователей"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def save_document(self, user_id: int, filename: str, original_filename: str, 
                     content: str, file_size: int = 0) -> Optional[int]:
        """Сохранение документа в БД"""
        try:
            # Создаем превью контента (первые 500 символов)
            content_preview = content[:500] + "..." if len(content) > 500 else content
            
            with self.db.get_connection() as conn:
                cursor = conn.execute('''
                    INSERT INTO documents 
                    (user_id, filename, original_filename, file_size, content_preview, full_content, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (user_id, filename, original_filename, file_size, content_preview, content, 'processed'))
                
                document_id = cursor.lastrowid
                conn.commit()
                print(f"✅ Документ {original_filename} сохранен (ID: {document_id})")
                return document_id
        except Exception as e:
            print(f"❌ Ошибка сохранения документа: {e}")
            return None
    
    def get_user_documents(self, user_id: int, limit: int = 50) -> List[Dict]:
        """Получить список документов пользователя"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute('''
                    SELECT d.*, COUNT(ar.id) as analysis_count
                    FROM documents d
                    LEFT JOIN analysis_results ar ON d.id = ar.document_id
                    WHERE d.user_id = ?
                    GROUP BY d.id
                    ORDER BY d.created_at DESC
                    LIMIT ?
                ''', (user_id, limit))
                
                documents = [dict(row) for row in cursor.fetchall()]
                print(f"✅ Найдено {len(documents)} документов для пользователя {user_id}")
                return documents
        except Exception as e:
            print(f"❌ Ошибка получения документов: {e}")
            return []
    
    def get_document_by_id(self, document_id: int, user_id: int) -> Optional[Dict]:
        """Получить документ по ID (с проверкой владельца)"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute(
                    'SELECT * FROM documents WHERE id = ? AND user_id = ?',
                    (document_id, user_id)
                )
                document = cursor.fetchone()
                return dict(document) if document else None
        except Exception as e:
            print(f"❌ Ошибка получения документа: {e}")
            return None
    
    def delete_document(self, document_id: int, user_id: int) -> bool:
        """Удаление документа (с проверкой владельца)"""
        try:
            with self.db.get_connection() as conn:
                # Удаляем связанные анализы
                conn.execute('DELETE FROM analysis_results WHERE document_id = ?', (document_id,))
                
                # Удаляем сам документ
                cursor = conn.execute(
                    'DELETE FROM documents WHERE id = ? AND user_id = ?',
                    (document_id, user_id)
                )
                
                if cursor.rowcount > 0:
                    conn.commit()
                    print(f"✅ Документ {document_id} удален")
                    return True
                else:
                    print(f"❌ Документ {document_id} не найден или не принадлежит пользователю")
                    return False
        except Exception as e:
            print(f"❌ Ошибка удаления документа: {e}")
            return False

# ==========================================
# АНАЛИЗЫ
# ==========================================

class AnalysisManager:
    """Управление результатами анализа"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def save_analysis(self, document_id: int, analysis_type: str, 
                     results_data: Dict, ai_provider: str = 'deepseek', 
                     processing_time: float = 0.0) -> Optional[int]:
        """Сохранение результатов анализа"""
        try:
            results_json = json.dumps(results_data, ensure_ascii=False)
            
            with self.db.get_connection() as conn:
                cursor = conn.execute('''
                    INSERT INTO analysis_results 
                    (document_id, analysis_type, results_data, ai_provider, processing_time)
                    VALUES (?, ?, ?, ?, ?)
                ''', (document_id, analysis_type, results_json, ai_provider, processing_time))
                
                analysis_id = cursor.lastrowid
                conn.commit()
                print(f"✅ Анализ сохранен (ID: {analysis_id})")
                return analysis_id
        except Exception as e:
            print(f"❌ Ошибка сохранения анализа: {e}")
            return None
    
    def get_document_analyses(self, document_id: int) -> List[Dict]:
        """Получить все анализы документа"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.execute('''
                    SELECT * FROM analysis_results 
                    WHERE document_id = ? 
                    ORDER BY created_at DESC
                ''', (document_id,))
                
                analyses = []
                for row in cursor.fetchall():
                    analysis = dict(row)
                    # Парсим JSON с результатами
                    try:
                        analysis['results_data'] = json.loads(analysis['results_data'])
                    except:
                        analysis['results_data'] = {}
                    analyses.append(analysis)
                
                return analyses
        except Exception as e:
            print(f"❌ Ошибка получения анализов: {e}")
            return []

# ==========================================
# ГЛАВНЫЙ КЛАСС
# ==========================================

class AppDatabase:
    """Главный класс для работы с базой данных приложения"""
    
    def __init__(self, db_path: str = "jurist_app.db"):
        self.db = Database(db_path)
        self.users = UserManager(self.db)
        self.sessions = SessionManager(self.db)
        self.documents = DocumentManager(self.db)
        self.analyses = AnalysisManager(self.db)
        
        print("🚀 AppDatabase инициализирован")
    
    def get_user_stats(self, username: str) -> Dict:
        """Получить статистику пользователя"""
        user = self.users.get_user_by_username(username)
        if not user:
            return {}
        
        documents = self.documents.get_user_documents(user['id'])
        total_documents = len(documents)
        
        # Считаем общее количество анализов
        total_analyses = 0
        for doc in documents:
            total_analyses += doc.get('analysis_count', 0)
        
        return {
            'username': username,
            'plan': user['plan'],
            'total_documents': total_documents,
            'total_analyses': total_analyses,
            'documents_used_this_month': user['documents_used_this_month']
        }

# ==========================================
# ТЕСТИРОВАНИЕ
# ==========================================

if __name__ == "__main__":
    # Простое тестирование
    print("🧪 Тестирование базы данных...")
    
    # Инициализация
    db = AppDatabase("test_app.db")
    
    # Создание тестового пользователя
    success = db.users.create_user("test_user", "password123", "test@example.com")
    print(f"Создание пользователя: {success}")
    
    # Аутентификация
    auth = db.users.authenticate_user("test_user", "password123")
    print(f"Аутентификация: {auth}")
    
    # Создание сессии
    session_created = db.sessions.create_session("test_user", "test_session_123")
    print(f"Создание сессии: {session_created}")
    
    # Получение пользователя по сессии
    user_from_session = db.sessions.get_user_by_session("test_session_123")
    print(f"Пользователь из сессии: {user_from_session}")
    
    # Статистика
    stats = db.get_user_stats("test_user")
    print(f"Статистика пользователя: {stats}")
    
    print("✅ Тестирование завершено")
    
    # Принудительно закрываем все соединения
    del db
    
    # Удаляем тестовую БД
    import os
    import time
    
    # Ждем немного чтобы все соединения закрылись
    time.sleep(0.5)
    
    try:
        if os.path.exists("test_app.db"):
            os.remove("test_app.db")
            print("🗑️ Тестовая БД удалена")
    except PermissionError:
        print("⚠️ Не удалось удалить тестовую БД (файл заблокирован)")
        print("💡 Это нормально - просто удалите test_app.db вручную")